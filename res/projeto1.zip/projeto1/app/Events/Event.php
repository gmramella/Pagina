<?php

namespace projeto1\Events;

abstract class Event
{
    //
}
