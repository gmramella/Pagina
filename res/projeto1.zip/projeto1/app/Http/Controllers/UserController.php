<?php

namespace projeto1\Http\Controllers;

use Input;
use projeto1\User;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        $nome = 'Giuseppe';

        return view('index', [
            'usuarios' => $users,
            'meuNome' => $nome
        ]);
    }

    public function store()
    {
        $user = new User;
        $user->nome = Input::get('nome');
        $user->cpf = Input::get('cpf');
        $user->email = Input::get('email');
        $user->save();

        return redirect('/')->with('message', 'Usuário salvo com sucesso.');
    }
}
