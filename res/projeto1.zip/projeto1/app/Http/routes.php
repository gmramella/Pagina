<?php

Route::get('/', 'UserController@index');

Route::post('/', 'UserController@store');

Route::get('/criar', function () {
    return view('create');
});
