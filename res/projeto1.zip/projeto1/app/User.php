<?php

namespace projeto1;

use Illuminate\Database\Eloquent\Model;

class User extends Model {

}
