<form action="/" method="post">
  <input type="hidden" name="_token" value="{{csrf_token()}}">
  <div>
    Nome:
    <input type="text" name="nome">
  </div>
  <br>
  <div>
    CPF:
    <input type="text" name="cpf">
  </div>
  <br>
  <div>
    E-mail:
    <input type="text" name="email">
  </div>

  <input type="submit" value="Enviar">
</form>
