{{ Session::get('message')}}
{{ $meuNome}}

<table>
    <tr>
      <th>
        titulo
      </th>
      <th>
        texto
      </th>
    </tr>
    @foreach ($usuarios as $usuario)
    <tr>
      <td>{{$usuario->nome}}</td>
      <td>{{$usuario->cpf}}</td>
      <td>{{$usuario->email}}</td>
    </tr>
    @endforeach
</table>
<a href="/criar">
criar
</a>
