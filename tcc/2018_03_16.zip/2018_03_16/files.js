function File() {
	var delimiter = ",";
	
	var elementsRead = [];
	function readTSV(file, t) {
		var reader = new FileReader();
		reader.readAsText(file);
		reader.onload = function(event) {
		var csvData = event.target.result;
		data = $.csv.toArrays(csvData);
		if (data && data.length > 0) {
		alert('Imported -' + data.length + '- rows successfully!');
		} else {
		alert('No data to import!');
		}
		};
		reader.onerror = function() {
		alert('Unable to read ' + file.fileName);
		};
	}
	this.readElementsTSVs = function () {
		$('#fileInput').click();
		console.log($('#fileInput'));
		var file;
		document.getElementById('fileInput').onchange = function () {
			file = this.value;
			readTSV(file, "object");
		};
		
		// readTSV(file, "object");
		// readTSV("morphisms.tsv", "morphisms");
	}
	
	//https://stackoverflow.com/questions/22550858/how-to-write-csv-file-using-javascript
	function writeTSV(tsvRows, fileName) {
		var a         = document.createElement("a");
		a.href        = "data:attachment/tsv;charset=utf-8," + encodeURIComponent(tsvRows.join("\r\n"));
		a.target      = "_blank";
		a.download    = fileName;
		document.body.appendChild(a);
		a.click();
	}
	function writeObjectsTSV() {
		var objectsAttributes = ["id", "label", "x", "y", "radius", "selected", "visible", "endomorphisms"];
		var objectsHeader = "";
		for (var i = 0; i < objectsAttributes.length - 1; i++) {
			objectsHeader += objectsAttributes[i] + delimiter;
		}
		objectsHeader += objectsAttributes[objectsAttributes.length - 1];
		var objects =	[
							{id: 0, label: "A", x: 100, y: 400, radius: 30, selected: false, visible: true, endomorphisms: "idA"},
							{id: 1, label: "B", x: 400, y: 100, radius: 30, selected: false, visible: true, endomorphisms: "idB"}
						];
		tsvRows = [];
		tsvRows.push(objectsHeader);
		for (var i = 0; i < objects.length; i++) {
			tsvRows.push(objects[i].id+delimiter+objects[i].label+delimiter+objects[i].x+delimiter+objects[i].y+delimiter+objects[i].radius+delimiter+objects[i].selected+delimiter+objects[i].visible+delimiter+objects[i].endomorphisms+"\r\n");
		}
		writeTSV(tsvRows, "objects.tsv");
	}
	function writeMorphismsTSV() {
		var morphismsAttributes = ["id", "label", "source", "target", "width", "type", "isIdEndomorphism", "selected", "visible", "p0", "p1", "p2", "curve", "handle"];
		var morphismsHeader = "";
		for (var i = 0; i < morphismsAttributes.length - 1; i++) {
			morphismsHeader += morphismsAttributes[i] + delimiter;
		}
		morphismsHeader += morphismsAttributes[morphismsAttributes.length - 1];
		var morphisms =	[
							{id: 0, label: "idA", source: 0, target: 0, width: 4, type: "endomorphism", isIdEndomorphism: true, selected: false, visible: true, p0: null, p1: null, p2: null, curve: null, handle: null},
							{id: 1, label: "idB", source: 1, target: 1, width: 4, type: "endomorphism", isIdEndomorphism: true, selected: false, visible: true, p0: null, p1: null, p2: null, curve: null, handle: null},
						];
		tsvRows = [];
		tsvRows.push(morphismsHeader);
		for (var i = 0; i < morphisms.length; i++) {
			tsvRows.push(morphisms[i].id+delimiter+morphisms[i].label+delimiter+morphisms[i].source+delimiter+morphisms[i].target+delimiter+morphisms[i].width+delimiter+morphisms[i].type+delimiter+morphisms[i].isIdEndomorphism+delimiter+morphisms[i].selected+delimiter+morphisms[i].visible+delimiter+morphisms[i].p0+delimiter+morphisms[i].p1+delimiter+morphisms[i].p2+delimiter+morphisms[i].curve+delimiter+morphisms[i].handle+"\r\n");
		}
		writeTSV(tsvRows, "morphisms.tsv");
	}
	this.writeElementsTSVs = function () {
		writeObjectsTSV();
		writeMorphismsTSV();
	}
}