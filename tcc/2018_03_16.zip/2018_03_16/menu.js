function Menu() {
	//Eric Martin's SimpleModal library and jQuery UI did not work when this project was upgraded to OOP
	//http://www.ericmmartin.com/projects/ and https://jqueryui.com/
	
	$("body").prepend('\
		<div id="canvasMenu">\
			<ul id="canvasItems">\
			</ul>\
		</div>\
		<div id="objectMenu">\
			<ul id="objectItems">\
			</ul>\
		</div>\
		<div id="morphismMenu">\
			<ul id="morphismItems">\
			</ul>\
		</div>\
	');
	
	$("#canvasItems").append('<li onclick="menu.openInputDialog(CREATE_OBJECT)"><u>C</u>reate object</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_ALL)">Select <u>a</u>ll</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_OBJECTS)">Select <u>o</u>bjects</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_MORPHISMS)">Select <u>m</u>orphisms</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_ENDOMORPHISMS)">Select <u>e</u>ndomorphisms</li>');
	
	$("#objectItems").append('<li onclick="menu.openInputDialog(CREATE_MORPHISM_TO)">Create morphism <u>t</u>o</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(CREATE_MORPHISM_FROM)">Create morphism <u>f</u>rom</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(READ_OBJECT)"><u>R</u>ead object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(UPDATE_OBJECT)"><u>U</u>pdate object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(DELETE_OBJECT)"><u>D</u>elete object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(SELECT_OBJECT)"><u>S</u>elect object</li>');
	
	$("#morphismItems").append('<li onclick="menu.openInputDialog(CHANGE_TYPE)"><u>C</u>hange type</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(READ_MORPHISM)"><u>R</u>ead morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(UPDATE_MORPHISM)"><u>U</u>pdate morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(DELETE_MORPHISM)"><u>D</u>elete morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(SELECT_MORPHISM)"><u>S</u>elect morphism</li>');
	
	$("body").prepend('\
		<div id="objectInput" style="display:none">\
			<form>\
			<label>id</label><input type="text" name="id" value="id" disabled><br>\
			<label>label</label><input type="text" name="label" value="label" disabled><br>\
			<label>x</label><input type="number" name="x" value="x" disabled><br>\
			<label>y</label><input type="number" name="y" value="y" disabled><br>\
			<label>radius</label><input type="number" name="radius" value="radius" disabled><br>\
			<button id="ok" type="button" onclick="menu.executeInputDialog()">OK</button>\
			<button id="quit" type="button" onclick="menu.closeObjectInputDialog()">QUIT</button>\
			<button id="reset" type="button" onclick="menu.resetInputDialog()">RESET</button>\
			</form>\
		</div>\
		<div id="morphismInput" style="display:none">\
			<form>\
			<label>id</label><input type="text" name="id" value="id" disabled><br>\
			<label>label</label><input type="text" name="label" value="label" disabled><br>\
			<label>source</label><input type="number" name="source" value="source" disabled><br>\
			<label>target</label><input type="number" name="target" value="target" disabled><br>\
			<label>width</label><input type="number" name="width" value="width" disabled><br>\
			<label>type</label>\
			<select name="types">\
				<option value="morphism">Morphism</option>\
				<option value="monomorphism">Monomorphism</option>\
				<option value="epimorphism">Epimorphism</option>\
				<option value="monoepimorphism">Monoepimorphism</option>\
				<option value="isomorphism">Isomorphism</option>\
			</select>\
			<button id="ok" type="button" onclick="menu.executeInputDialog()">OK</button>\
			<button id="quit" type="button" onclick="menu.closeMorphismInputDialog()">QUIT</button>\
			<button id="reset" type="button" onclick="menu.resetInputDialog()">RESET</button>\
			</form>\
		</div>\
	');
	
	/*
	Open input dialog
	*/
	this.openInputDialog = function (opt) {
		if (keyboardMouseStatus === "menu open") {
			keyboardMouseStatus = "input open";
			// console.log("input open");
		} else if (keyboardMouseStatus === "menu open with element(s) selected") {
			keyboardMouseStatus = "input open with element(s) selected";
			console.log("input open with element(s) selected");
		}
		$(document).click();//to close menu
		switch (opt) {
			case CREATE_OBJECT:
				// console.log("Create object");
				inputOpen = true;
				inputCode = CREATE_OBJECT;
				var fields = $("#objectInput").children()[0];
				fields[0].value = objectsCounter;
				fields[1].value = currentObjectLabel();
				fields[2].value = Number($("#canvasMenu").css("left").slice(0, -2));
				fields[3].value = Number($("#canvasMenu").css("top").slice(0, -2));
				fields[4].value = DEFAULT_CIRCLE_RADIUS;
				$("#objectInput").css("left", $("#canvasMenu").css("left"));
				$("#objectInput").css("top", $("#canvasMenu").css("top"));
				$("#objectInput").css("background", DEFAULT_CIRCLE_COLOR);
				$("#objectInput > form > input").css("background", DEFAULT_OBJECT_INPUT_COLOR);
				$("#objectInput > form > input").css("color", "#000000");
				$("#objectInput").show();
				break;
			case SELECT_ALL:
				// console.log("Select all");
				selectAll();
				if (selectedElements.length > 0) {
					keyboardMouseStatus = "idle with element(s) selected";
					// console.log("idle with element(s) selected");
				} else {
					keyboardMouseStatus = "idle";
					// console.log("idle");
				}
				break;
			case SELECT_OBJECTS:
				// console.log("Select objects");
				selectObjects();
				if (selectedElements.length > 0) {
					keyboardMouseStatus = "idle with element(s) selected";
					// console.log("idle with element(s) selected");
				} else {
					keyboardMouseStatus = "idle";
					// console.log("idle");
				}
				break;
			case SELECT_MORPHISMS:
				// console.log("Select morphisms");
				selectMorphisms();
				if (selectedElements.length > 0) {
					keyboardMouseStatus = "idle with element(s) selected";
					// console.log("idle with element(s) selected");
				} else {
					keyboardMouseStatus = "idle";
					// console.log("idle");
				}
				break;
			case SELECT_ENDOMORPHISMS:
				// console.log("Select morphisms");
				selectEndomorphisms();
				if (selectedElements.length > 0) {
					keyboardMouseStatus = "idle with element(s) selected";
					// console.log("idle with element(s) selected");
				} else {
					keyboardMouseStatus = "idle";
					// console.log("idle");
				}
				break;
			case CREATE_MORPHISM_TO:
				// console.log("Create morphism to");
				inputOpen = true;
				inputCode = CREATE_MORPHISM_TO;
				var object = listOfObjectsPressed[0];
				var fields = $("#morphismInput").children()[0];
				fields[0].value = morphismsCounter;
				fields[1].value = currentMorphismLabel();
				fields[2].value = object.getId();
				fields[3].value = object.getId();
				fields[4].value = DEFAULT_CURVE_WIDTH;
				fields[5].options[0].selected = true;
				$("#morphismInput").css("left", $("#objectMenu").css("left"));
				$("#morphismInput").css("top", $("#objectMenu").css("top"));
				$("#morphismInput").css("background", DEFAULT_CURVE_COLOR);
				$("#morphismInput > form > input").css("background", DEFAULT_MORPHISM_INPUT_COLOR);
				$("#morphismInput > form > input").css("color", "#000000");
				$("#morphismInput").show();
				break;
			case CREATE_MORPHISM_FROM:
				// console.log("Create morphism from");
				inputOpen = true;
				inputCode = CREATE_MORPHISM_FROM;
				var object = listOfObjectsPressed[0];
				var fields = $("#morphismInput").children()[0];
				fields[0].value = morphismsCounter;
				fields[1].value = currentMorphismLabel();
				fields[2].value = object.getId();
				fields[3].value = object.getId();
				fields[4].value = DEFAULT_CURVE_WIDTH;
				fields[5].options[0].selected = true;
				$("#morphismInput").css("left", $("#objectMenu").css("left"));
				$("#morphismInput").css("top", $("#objectMenu").css("top"));
				$("#morphismInput").css("background", DEFAULT_CURVE_COLOR);
				$("#morphismInput > form > input").css("background", DEFAULT_MORPHISM_INPUT_COLOR);
				$("#morphismInput > form > input").css("color", "#000000");
				$("#morphismInput").show();
				break;
			case READ_OBJECT:
				//console.log("Read object");
				inputOpen = true;
				inputCode = READ_OBJECT;
				var fields = $("#objectInput").children()[0];
				var object = listOfObjectsPressed[0];
				var allAtributes = object.getAll();
				for (var i = 0; i < 5; i++) {
					fields[i].value = allAtributes[i];
				}
				$("#objectInput").css("left", $("#objectMenu").css("left"));
				$("#objectInput").css("top", $("#objectMenu").css("top"));
				$("#objectInput").css("background", DEFAULT_CIRCLE_COLOR);
				$("#objectInput > form > input").css("background", DEFAULT_OBJECT_INPUT_COLOR);
				$("#objectInput > form > input").css("color", "#000000");
				$("#objectInput").show();
				break;
			case UPDATE_OBJECT:
				// console.log("Update object");
				inputOpen = true;
				inputCode = UPDATE_OBJECT;
				var object = listOfObjectsPressed[0];
				var fields = $("#objectInput").children()[0];
				fields[0].value = object.getId();
				fields[1].value = object.getLabel();
				fields[2].value = object.getX();
				fields[3].value = object.getY();
				fields[4].value = object.getRadius();
				$("#objectInput").css("left", $("#objectMenu").css("left"));
				$("#objectInput").css("top", $("#objectMenu").css("top"));
				$("#objectInput").css("background", DEFAULT_CIRCLE_COLOR);
				$("#objectInput > form > input").css("background", DEFAULT_OBJECT_INPUT_COLOR);
				$("#objectInput > form > input").css("color", "#000000");
				$("#objectInput").show();
				break;
			case DELETE_OBJECT:
				// console.log("Delete object");
				var object = listOfObjectsPressed[0];
				state.createState("deleteObject", object);
				var morphismsArray = object.getMorphisms();
				var endomorphismsArray = object.getEndomorphisms();
				view.hideCircle(object);
				object.setVisible(false);
				for (var i = 0; i < morphismsArray.length; i++) {
					view.hideBezier(morphismsArray[i]);
					morphismsArray[i].setVisible(false);
				}
				for (var i = 0; i < endomorphismsArray.length; i++) {
					view.hideEndomorphism(endomorphismsArray[i]);
					endomorphismsArray[i].setVisible(false);
				}
				keyboardMouseStatus = "idle";
				// console.log("idle");
				break;
			case SELECT_OBJECT:
				// console.log("Select object");
				selectedElements.push({type: "object", element: listOfObjectsPressed[0]});
				view.selectCircle(listOfObjectsPressed[0]);
				listOfObjectsPressed[0].setSelected(true);
				var idEndomorphism = listOfObjectsPressed[0].getEndomorphism(0);
				selectedElements.push({type: "endomorphism", element: idEndomorphism});
				view.selectEndomorphism(idEndomorphism);
				idEndomorphism.setSelected(true);
				keyboardMouseStatus = "idle with element(s) selected";
				// console.log("idle with element(s) selected");
				break;
			case CHANGE_TYPE:
				// console.log("Change type");
				inputOpen = true;
				inputCode = CHANGE_TYPE;
				var morphism = listOfMorphismsPressed[0];
				var fields = $("#morphismInput").children()[0];
				var allAtributes = morphism.getAll();
				for (var i = 0; i < 5; i++) {
					fields[i].value = allAtributes[i];
				}
				for (var i = 0; i < fields[5].options.length; i++) {
					if (morphism.getType() === "morphism") {
						if (fields[5].options[i].value === morphism.getType()) {
							fields[5].options[i].selected = true;
						}
					} else if (morphism.getType() === "endomorphism") {
						if (fields[5].options[i].value === morphism.getType().substring(4)) {
							fields[5].options[i].selected = true;
						}
					}
				}
				$("#morphismInput").css("left", $("#morphismMenu").css("left"));
				$("#morphismInput").css("top", $("#morphismMenu").css("top"));
				$("#morphismInput").css("background", DEFAULT_CURVE_COLOR);
				$("#morphismInput > form > input").css("background", DEFAULT_MORPHISM_INPUT_COLOR);
				$("#morphismInput > form > input").css("color", "#000000");
				$("#morphismInput").show();
				break;
			case READ_MORPHISM:
				// console.log("Read morphism");
				inputOpen = true;
				inputCode = READ_MORPHISM;
				var fields = $("#morphismInput").children()[0];
				var morphism = listOfMorphismsPressed[0];
				var allAtributes = morphism.getAll();
				for (var i = 0; i < 6; i++) {
					fields[i].value = allAtributes[i];
				}
				$("#morphismInput").css("left", $("#morphismMenu").css("left"));
				$("#morphismInput").css("top", $("#morphismMenu").css("top"));
				$("#morphismInput").css("background", DEFAULT_CURVE_COLOR);
				$("#morphismInput > form > input").css("background", DEFAULT_MORPHISM_INPUT_COLOR);
				$("#morphismInput > form > input").css("color", "#000000");
				$("#morphismInput").show();
				break;
			case UPDATE_MORPHISM:
				// console.log("Update morphism");
				inputOpen = true;
				inputCode = UPDATE_MORPHISM;
				var morphism = listOfMorphismsPressed[0];
				var fields = $("#objectInput").children()[0];
				fields[0].value = morphism.getId();
				fields[1].value = morphism.getLabel();
				fields[2].value = morphism.getSource();
				fields[3].value = morphism.getTarget();
				fields[4].value = morphism.getWidth();
				fields[5].value = morphism.getType();
				$("#objectInput").css("left", $("#morphismMenu").css("left"));
				$("#objectInput").css("top", $("#morphismMenu").css("top"));
				$("#objectInput").css("background", DEFAULT_CURVE_COLOR);
				$("#objectInput > form > input").css("background", DEFAULT_MORPHISM_INPUT_COLOR);
				$("#objectInput > form > input").css("color", "#000000");
				$("#objectInput").show();
				break;
			case DELETE_MORPHISM:
				// console.log("Delete morphism");
				var morphism = listOfMorphismsPressed[0];
				state.createState("deleteMorphism", morphism);
				if (morphism.getType() !== "endomorphism") {
					view.hideBezier(morphism);
					morphism.setVisible(false);
				} else {
					view.hideEndomorphism(morphism);
					morphism.setVisible(false);
				}
				keyboardMouseStatus = "idle";
				// console.log("idle");
				break;
			case SELECT_MORPHISM:
				// console.log("Select morphism");
				if (listOfMorphismsPressed[0].getSource() !== listOfMorphismsPressed[0].getTarget()) {
					selectedElements.push({type: "morphism", element: listOfMorphismsPressed[0]});
					view.selectBezier(listOfMorphismsPressed[0]);
				} else {
					selectedElements.push({type: "endomorphism", element: listOfMorphismsPressed[0]});
					view.selectEndomorphism(listOfMorphismsPressed[0]);
				}
				listOfMorphismsPressed[0].setSelected(true);
				keyboardMouseStatus = "idle with element(s) selected";
				// console.log("idle with element(s) selected");
				break;
		}
	}
	
	/*
	Execute input dialog
	*/
	this.executeInputDialog = function() {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "input execute";
			console.log("input execute");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "input execute with element(s) selected";
			console.log("input execute with element(s) selected");
		}
		switch (inputCode) {
			case CREATE_OBJECT:
				inputOpen = false;
				inputCode = -1;
				$("#objectInput").hide();
				var fields = $("#objectInput").children()[0];
				var id = fields[0].value;
				var label = fields[1].value;
				var x = Number(fields[2].value);
				var y = Number(fields[3].value);
				var radius = Number(fields[4].value);
				var position = [x, y];
				view.createCircle(position);
				view.createCircleLabel(position);
				var newObject = new Object(position);
				objects.push(newObject);
				var ptr = view.createIdEndomorphism(newObject, radius);
				view.createIdEndomorphismLabel(ptr.handle, radius);
				var newMorphism = new Morphism(objectsCounter, objectsCounter, "endomorphism", true, ptr);
				morphisms.push(newMorphism);
				newObject.addEndomorphism(newMorphism);
				objectsCounter++;
				morphismsCounter++;
				state.createState("createObject", [newObject, newMorphism]);
				lastCreatedObjectTimestamp = new Date().getTime();
				lastCreatedEndomorphismTimestamp = new Date().getTime();
				console.log("last operation: "+"createObject");
				break;
			case CREATE_MORPHISM_TO:
				inputOpen = false;
				inputCode = -1;
				$("#morphismInput").hide();
				var fields = $("#morphismInput").children()[0];
				var source = getObjectById(Number(fields[2].value));
				var target = getObjectById(Number(fields[3].value));
				var type = fields[5].value;
				var ptr = null;
				if (Number(fields[2].value) !== Number(fields[3].value)) {
					ptr = view.createBezier(source.getPosition(), target.getPosition());
					view.createBezierLabel(ptr.handle);
				} else {
					ptr = view.createEndomorphism(source, target.getRadius(), 270);
					view.createEndomorphismLabel(ptr.handle);
				}
				var newMorphism = new Morphism(source, target, type, false, ptr);
				morphisms.push(newMorphism);
				source.addEndomorphism(newMorphism);
				morphismsCounter++;
				console.log("last operation: "+"createMorphismTo");
				break;
			case CREATE_MORPHISM_FROM:
				inputOpen = false;
				inputCode = -1;
				$("#morphismInput").hide();
				var fields = $("#morphismInput").children()[0];
				var source = getObjectById(Number(fields[2].value));
				var target = getObjectById(Number(fields[3].value));
				var type = fields[5].value;
				var ptr = null;
				if (Number(fields[2].value) !== Number(fields[3].value)) {
					ptr = view.createBezier(source.getPosition(), target.getPosition());
					view.createBezierLabel(ptr.handle);
				} else {
					ptr = view.createEndomorphism(source, target.getRadius(), 270);
					view.createEndomorphismLabel(ptr.handle);
				}
				var newMorphism = new Morphism(source, target, type, false, ptr);
				morphisms.push(newMorphism);
				source.addEndomorphism(newMorphism);
				morphismsCounter++;
				console.log("last operation: "+"createMorphismFrom");
				break;
			case READ_OBJECT:
				inputOpen = false;
				inputCode = -1;
				$("#objectInput").hide();
				console.log("last operation: "+"readObject");
				break;
			case UPDATE_OBJECT:
				inputOpen = false;
				inputCode = -1;
				$("#objectInput").hide();
				var object = listOfObjectsPressed[0];
				var fields = $("#objectInput").children()[0];
				var label = fields[1].value;
				var x = Number(fields[2].value);
				var y = Number(fields[3].value);
				var radius = Number(fields[4].value);
				object.setLabel(label);
				object.setX(x);
				object.setY(y);
				object.setRadius(radius);
				console.log("last operation: "+"updateObject");
				break;
			case CHANGE_TYPE:
				inputOpen = false;
				inputCode = -1;
				$("#morphismInput").hide();
				var morphism = listOfMorphismsPressed[0];
				var fields = $("#morphismInput").children()[0];
				morphism.setType(fields[5].value)
				console.log(morphism.getType());
				console.log("last operation: "+"changeType");
				break;
			case READ_MORPHISM:
				inputOpen = false;
				inputCode = -1;
				$("#morphismInput").hide();
				console.log("last operation: "+"readMorphism");
				break;
			case UPDATE_MORPHISM:
				inputOpen = false;
				inputCode = -1;
				$("#morphismInput").hide();
				var morphism = listOfMorphismsPressed[0];
				var fields = $("#morphismInput").children()[0];
				var label = fields[1].value;
				var source = Number(fields[2].value);
				var target = Number(fields[3].value);
				var width = Number(fields[4].value);
				var type = fields[5].value;
				morphism.setLabel(label);
				morphism.setSource(source);
				morphism.setTarget(target);
				morphism.setWidth(width);
				morphism.setType(type);
				console.log("last operation: "+"updateMorphism");
				break;
		}
		if (keyboardMouseStatus === "input execute") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input execute with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
	}
	
	/*
	Close object input dialog
	*/
	this.closeObjectInputDialog = function () {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
		inputOpen = false;inputCode = -1;$("#objectInput").hide();
	}
	
	/*
	Close morphism input dialog
	*/
	this.closeMorphismInputDialog = function () {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
		inputOpen = false;inputCode = -1;$("#morphismInput").hide();
	}
	
	/*
	Reset input dialog
	*/
	this.resetInputDialog = function() {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "input open";
			console.log("input open");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "input open with element(s) selected";
			console.log("input open with element(s) selected");
		}
		switch (inputCode) {
			case CREATE_OBJECT:
				break;
			case SELECT_ALL:
				break;
			case SELECT_OBJECTS:
				break;
			case SELECT_MORPHISMS:
				break;
			case CREATE_MORPHISM_TO:
				break;
			case CREATE_MORPHISM_FROM:
				break;
			case READ_OBJECT:
				var fields = $("#objectInput").children()[0];
				var object = listOfObjectsPressed[0];
				var allAtributes = object.getAll();
				for (var i = 0; i < 5; i++) {
					fields[i].value = allAtributes[i];
				}
				break;
			case UPDATE_OBJECT:
				break;
			case DELETE_OBJECT:
				break;
			case SELECT_OBJECT:
				break;
			case READ_MORPHISM:
				var fields = $("#morphismInput").children()[0];
				var morphism = listOfMorphismsPressed[0];
				var allAtributes = morphism.getAll();
				for (var i = 0; i < 6; i++) {
					fields[i].value = allAtributes[i];
				}
				break;
			case UPDATE_MORPHISM:
				break;
			case DELETE_MORPHISM:
				break;
			case SELECT_MORPHISM:
				break;
		}
	}
}