/*
doneActions/undoneActions: string in { 
	"createEndomorphism", "createMorphism", "createMorphismFrom", "createMorphismTo", "createObject", 
	"cutSelected", 
	"deleteEndomorphism", "deleteMorphism", "deleteObject", "deleteSelected", 
	"dragEndomorphism", "dragSelected", 
	"pasteSelected",  
	"updateEndomorphism", "updateMorphism", "updateObject"
}
states: list of descriptions
currentStateIndices: natural number or -1, indicating empty list
*/
function State() {
	var doneActions = [];
	var undoneActions = [];
	var states = [];
	var currentStateIndices = -1;
	var savedStates = [];
	
	/*
	Remove undone actions when new action is done
	*/
	function removeUndoneActions() {
		for (var i = currentStateIndices + 1; i < states.length; i++) {
			console.log("removeUndoneActions "+undoneActions[i]);
			switch (undoneActions[i]) {
				case "createEndomorphism":
					console.log(states[i]);
					break;
				case "createMorphism":
					console.log(states[i]);
					// var createdMorphism = states[i].morphisms[0];
					// var morphismId = createdMorphism.getId();
					// removeMorphismById(morphismId);
					// removeMorphismLabelById(morphismId);
					break;
				case "createMorphismFrom":
					break;
				case "createMorphismTo":
					break;
				case "createObject":
					console.log(states[i]);
					// var createdObject = states[i].objects[0];
					// var objectId = createdObject.getId();
					// var idEndomorphismId = createdObject.getEndomorphisms(0).getId();
					// removeMorphismById(idEndomorphismId);
					// removeMorphismLabelById(idEndomorphismId);
					// removeObjectById(objectId);
					// removeObjectLabelById(objectId);
					break;
				case "cutSelected":
					console.log(states[i]);
					break;
				case "deleteMorphism":
					break;
				case "deleteObject":
					break;
				case "deleteSelected":
					console.log(states[i]);
					break;
				case "dragSelected":
					console.log(states[i]);
					break;
				case "pasteSelected":
					console.log(states[i]);
					break;
				case "updateMorphism":
					break;
				case "updateObject":
					break;
			}
		}
		doneActions.splice(currentStateIndices + 1, undoneActions.length);
		states.splice(currentStateIndices + 1, undoneActions.length);
		undoneActions = [];
	}
	
	/*
	Create state with new action
	*/
	this.createState = function(action, elements) {
		removeHiddenElements();
		removeUndoneActions();
		switch (action) {
			case "createEndomorphism":
				doneActions.push("createEndomorphism");
				var description = {endomorphisms: elements[0]};
				states.push(description);
				currentStateIndices++;
				break;
			case "createMorphism":
				doneActions.push("createMorphism");
				var description = {morphisms: elements[0]};
				states.push(description);
				currentStateIndices++;
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				doneActions.push("createObject");
				var description = {objects: elements[0], endomorphisms: elements[1]};
				states.push(description);
				currentStateIndices++;
				break;
			case "cutSelected":
				doneActions.push("cutSelected");
				var description = {objects: [], morphisms: [], endomorphisms: []};
				for (var i = 0; i < elements.length; i++) {
					if (elements[i].type === "object") {
						description.objects.push(elements[i].element);
					} else if (elements[i].type !== "endomorphism") {
						description.morphisms.push(elements[i].element);
					} else if (elements[i].type === "endomorphism") {
						description.endomorphisms.push(elements[i].element);
					}
				}
				states.push(description);
				currentStateIndices++;
				break;
			case "deleteMorphism":
				doneActions.push("deleteMorphism");
				console.log(elements);
				var morphism = elements;
				var description = {objects: [], morphisms: [], endomorphisms: []};
				description.morphisms.push(morphism);
				states.push(description);
				currentStateIndices++;
				break;
			case "deleteObject":
				doneActions.push("deleteObject");
				console.log(elements);
				var object = elements;
				var description = {objects: [], morphisms: [], endomorphisms: []};
				description.objects.push(object);
				var morphismsArray = object.getMorphisms();
				var endomorphismsArray = object.getEndomorphisms();
				for (var i = 0; i < morphismsArray.length; i++) {
					description.morphisms.push(morphismsArray[i]);
				}
				for (var i = 0; i < endomorphismsArray.length; i++) {
					description.endomorphisms.push(endomorphismsArray[i]);
				}
				states.push(description);
				currentStateIndices++;
				break;
			case "deleteSelected":
				doneActions.push("deleteSelected");
				var description = {objects: [], morphisms: [], endomorphisms: []};
				for (var i = 0; i < elements.length; i++) {
					if (elements[i].type === "object") {
						description.objects.push(elements[i].element);
					} else if (elements[i].type !== "endomorphism") {
						description.morphisms.push(elements[i].element);
					} else if (elements[i].type === "endomorphism") {
						description.endomorphisms.push(elements[i].element);
					}
				}
				states.push(description);
				currentStateIndices++;
				break;
			case "dragSelected":
				console.log("dragSelected");
				doneActions.push("dragSelected");
				var description = {objects: [], morphisms: [], endomorphisms: [], objectsPreviousPositions: [], morphismsPreviousPositions: [], endomorphismsPreviousPositions: [], objectsCurrentPositions: [], morphismsCurrentPositions: [], endomorphismsCurrentPositions: []};
				for (var i = 0; i < elements.length; i++) {
					if (elements[i].type === "object") {
						description.objects.push(elements[i].element);
						description.objectsPreviousPositions.push(elements[i].element.getPosition());
					} else if (elements[i].type !== "endomorphism") {
						description.morphisms.push(elements[i].element);
						description.morphismsPreviousPositions.push(elements[i].element.getHandlePosition());
					} else if (elements[i].type === "endomorphism") {
						description.endomorphisms.push(elements[i].element);
						description.endomorphismsPreviousPositions.push(elements[i].element.getHandlePosition());
					}
				}
				states.push(description);
				currentStateIndices++;
				break;
			case "pasteSelected":
				console.log("pasteSelected");
				doneActions.push("pasteSelected");
				var description = {objects: [], morphisms: [], endomorphisms: []};
				for (var i = 0; i < elements.length; i++) {
					if (elements[i].type === "object") {
						description.objects.push(elements[i].element);
					} else if (elements[i].type !== "endomorphism") {
						description.morphisms.push(elements[i].element);
					} else if (elements[i].type === "endomorphism") {
						description.endomorphisms.push(elements[i].element);
					}
				}
				states.push(description);
				currentStateIndices++;
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
	}
	
	/*
	Go to next state on the stack of states
	*/
	this.gotoNextState = function() {
		if ((currentStateIndices + 1) >= states.length) {
			alert(STR_NO_MORE_REDO);
			return;
		}
		doneActions.push(undoneActions.pop());
		switch (doneActions.last()) {
			case "createEndomorphism":
				view.showEndomorphism(states[currentStateIndices + 1].endomorphisms);
				states[currentStateIndices + 1].endomorphisms.setVisible(true);
				var source = getObjectById(states[currentStateIndices + 1].endomorphisms.getSource());
				var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
				var angle = 360 / endomorphismsArray.length;
				for (var i = 0; i < endomorphismsArray.length; i++) {
					var x = source.getX() + Math.degCos(90 + i * angle);
					var y = source.getY() - Math.degSin(90 + i * angle);
					view.updateEndomorphism(endomorphismsArray[i], [x, y]);
					view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
				}
				break;
			case "createMorphism":
				view.showBezier(states[currentStateIndices + 1].morphisms);
				states[currentStateIndices + 1].morphisms.setVisible(true);
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				view.showCircle(states[currentStateIndices + 1].objects);
				states[currentStateIndices + 1].objects.setVisible(true);
				view.showEndomorphism(states[currentStateIndices + 1].endomorphisms);
				states[currentStateIndices + 1].endomorphisms.setVisible(true);
				break;
			case "cutSelected":
				console.log("cutSelected");
				var objs = states[currentStateIndices + 1].objects;
				var morphs = states[currentStateIndices + 1].morphisms;
				var endos = states[currentStateIndices + 1].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.hideCircle(objs[i]);
					objs[i].setVisible(false);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.hideBezier(morphs[i]);
					morphs[i].setVisible(false);
				}
				for (var i = 0; i < endos.length; i++) {
					view.hideEndomorphism(endos[i]);
					endos[i].setVisible(false);
					var source = getObjectById(endos[i].getSource());
					var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
					var angle = 360 / endomorphismsArray.length;
					for (var i = 0; i < endomorphismsArray.length; i++) {
						var x = source.getX() + Math.degCos(90 + i * angle);
						var y = source.getY() - Math.degSin(90 + i * angle);
						view.updateEndomorphism(endomorphismsArray[i], [x, y]);
						view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
					}
				}
				break;
			case "deleteMorphism":
				console.log("deleteMorphism");
				var morph = states[currentStateIndices + 1].morphisms[0];
				if (morph.getType() !== "endomorphism") {
					view.hideBezier(morph);
					morph.setVisible(false);
				} else {
					view.hideEndomorphism(morph);
					morph.setVisible(false);
				}
				break;
			case "deleteObject":
				console.log("deleteObject");
				var obj = states[currentStateIndices + 1].objects[0];
				var morphs = states[currentStateIndices + 1].morphisms;
				var endos = states[currentStateIndices + 1].endomorphisms;
				view.hideCircle(obj);
				obj.setVisible(false);
				for (var i = 0; i < morphs.length; i++) {
					view.hideBezier(morphs[i]);
					morphs[i].setVisible(false);
				}
				var sources = [];
				for (var i = 0; i < endos.length; i++) {
					view.hideEndomorphism(endos[i]);
					endos[i].setVisible(false);
				}
				break;
			case "deleteSelected":
				console.log("deleteSelected");
				var objs = states[currentStateIndices + 1].objects;
				var morphs = states[currentStateIndices + 1].morphisms;
				var endos = states[currentStateIndices + 1].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.hideCircle(objs[i]);
					objs[i].setVisible(false);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.hideBezier(morphs[i]);
					morphs[i].setVisible(false);
				}
				var sources = [];
				for (var i = 0; i < endos.length; i++) {
					view.hideEndomorphism(endos[i]);
					endos[i].setVisible(false);
					sources.push(endos[i].getSource());
				}
				sources = sources.uniques();
				for (var i = 0; i < sources.length; i++) {
					var source = getObjectById(sources[i]);
					var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
					var angle = 360 / endomorphismsArray.length;
					for (var i = 0; i < endomorphismsArray.length; i++) {
						var x = source.getX() + Math.degCos(90 + i * angle);
						var y = source.getY() - Math.degSin(90 + i * angle);
						view.updateEndomorphism(endomorphismsArray[i], [x, y]);
						view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
					}
				}
				break;
			case "dragSelected":
				console.log("dragSelected");
				var objs = states[currentStateIndices + 1].objects;
				var morphs = states[currentStateIndices + 1].morphisms;
				var endos = states[currentStateIndices + 1].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					var objectCurrentPosition = objs[i].getPosition();
					var temp = states[currentStateIndices + 1].objectsCurrentPositions[i];
					states[currentStateIndices + 1].objectsCurrentPositions[i] = states[currentStateIndices + 1].objectsPreviousPositions[i];
					states[currentStateIndices + 1].objectsPreviousPositions[i] = temp;
					var prevPosition = states[currentStateIndices + 1].objectsPreviousPositions[i];
					view.updateCircle(objs[i], prevPosition);
					view.updateCircleLabel(objs[i], prevPosition);
					objs[i].setPosition(prevPosition);
					var objectMorphisms = objs[i].getMorphisms();
					for (var j = 0; j < objectMorphisms.length; j++) {
						var source = getObjectById(objectMorphisms[j].getSource());
						var target = getObjectById(objectMorphisms[j].getTarget());
						var ptr = view.translateBezier(objectMorphisms[j]);
						view.translateBezierLabel(objectMorphisms[j]);
						for (var k = 0; k < objectMorphisms.length; k++) {
							if (objectMorphisms[k] === objectMorphisms[j]) {
								var m = [0.5 * (source.getX() + target.getX()), 0.5 * (source.getY() + target.getY())];
								var realAngleBetweenObjects = Math.realAngle(source.getPosition(), target.getPosition());
								var sign = Math.pow(-1, source.getId() > target.getId());
								// var r = [m[0] - 2 * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
								var r = [m[0] - 2 * sign * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * sign * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
								var ptr = view.updateBezier(objectMorphisms[k], r);
								view.updateBezierLabel(objectMorphisms[k], r);
								objectMorphisms[k].setPoints([ptr.p0, ptr.p1, ptr.p2]);
								objectMorphisms[k].setCurvePath(ptr.curve.attr("d"));
								objectMorphisms[k].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
								break;
							}
						}
					}
					var objectEndomorphisms = objs[i].getEndomorphisms();
					for (var j = 0; j < objectEndomorphisms.length; j++) {
						view.translateEndomorphism(objectEndomorphisms[j], prevPosition, objectCurrentPosition);
						view.translateEndomorphismLabel(objectEndomorphisms[j]);
					}
				}
				break;
			case "pasteSelected":
				console.log("pasteSelected");
				pasteCounter++;
				var objs = states[currentStateIndices + 1].objects;
				var morphs = states[currentStateIndices + 1].morphisms;
				var endos = states[currentStateIndices + 1].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.showCircle(objs[i]);
					objs[i].setVisible(true);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.showBezier(morphs[i]);
					morphs[i].setVisible(true);
				}
				for (var i = 0; i < endos.length; i++) {
					view.showEndomorphism(endos[i]);
					endos[i].setVisible(true);
				}
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
		currentStateIndices++;
	}
	
	/*
	Go to previous state on the stack of states
	*/
	this.gotoPrevState = function() {
		if (currentStateIndices < 0) {
			alert(STR_NO_MORE_UNDO);
			return;
		}
		undoneActions.push(doneActions.pop());
		switch (undoneActions.last()) {
			case "createEndomorphism":
				view.hideEndomorphism(states[currentStateIndices].endomorphisms);
				states[currentStateIndices].endomorphisms.setVisible(false);
				var source = getObjectById(states[currentStateIndices].endomorphisms.getSource());
				var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
				var angle = 360 / endomorphismsArray.length;
				for (var i = 0; i < endomorphismsArray.length; i++) {
					var x = source.getX() + Math.degCos(90 + i * angle);
					var y = source.getY() - Math.degSin(90 + i * angle);
					view.updateEndomorphism(endomorphismsArray[i], [x, y]);
					view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
				}
				break;
			case "createMorphism":
				view.hideBezier(states[currentStateIndices].morphisms);
				states[currentStateIndices].morphisms.setVisible(false);
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				view.hideCircle(states[currentStateIndices].objects);
				states[currentStateIndices].objects.setVisible(false);
				view.hideEndomorphism(states[currentStateIndices].endomorphisms);
				states[currentStateIndices].endomorphisms.setVisible(false);
				break;
			case "cutSelected":
				var objs = states[currentStateIndices].objects;
				var morphs = states[currentStateIndices].morphisms;
				var endos = states[currentStateIndices].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.showCircle(objs[i]);
					objs[i].setVisible(true);
					view.deselectCircle(objs[i]);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.showBezier(morphs[i]);
					morphs[i].setVisible(true);
					view.deselectBezier(morphs[i]);
				}
				for (var i = 0; i < endos.length; i++) {
					view.showEndomorphism(endos[i]);
					endos[i].setVisible(true);
					view.deselectEndomorphism(endos[i]);
					var source = getObjectById(endos[i].getSource());
					var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
					var angle = 360 / endomorphismsArray.length;
					for (var i = 0; i < endomorphismsArray.length; i++) {
						var x = source.getX() + Math.degCos(90 + i * angle);
						var y = source.getY() - Math.degSin(90 + i * angle);
						view.updateEndomorphism(endomorphismsArray[i], [x, y]);
						view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
					}
				}
				break;
			case "deleteMorphism":
				var morph = states[currentStateIndices].morphisms[0];
				if (morph.getType() !== "endomorphism") {
					view.showBezier(morph);
					morph.setVisible(true);
				} else {
					view.showEndomorphism(morph);
					morph.setVisible(true);
				}
				break;
			case "deleteObject":
				var obj = states[currentStateIndices].objects[0];
				var morphs = states[currentStateIndices].morphisms;
				var endos = states[currentStateIndices].endomorphisms;
				view.showCircle(obj);
				obj.setVisible(true);
				for (var i = 0; i < morphs.length; i++) {
					view.showBezier(morphs[i]);
					morphs[i].setVisible(true);
				}
				var sources = [];
				for (var i = 0; i < endos.length; i++) {
					view.showEndomorphism(endos[i]);
					endos[i].setVisible(true);
				}
				break;
			case "deleteSelected":
				var objs = states[currentStateIndices].objects;
				var morphs = states[currentStateIndices].morphisms;
				var endos = states[currentStateIndices].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.showCircle(objs[i]);
					objs[i].setVisible(true);
					view.deselectCircle(objs[i]);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.showBezier(morphs[i]);
					morphs[i].setVisible(true);
					view.deselectBezier(morphs[i]);
				}
				var sources = [];
				for (var i = 0; i < endos.length; i++) {
					view.showEndomorphism(endos[i]);
					endos[i].setVisible(true);
					view.deselectEndomorphism(endos[i]);
					sources.push(endos[i].getSource());
				}
				sources = sources.uniques();
				for (var i = 0; i < sources.length; i++) {
					var source = getObjectById(sources[i]);
					var endomorphismsArray = source.getEndomorphisms().filter(function(e){return e.getVisible();});
					var angle = 360 / endomorphismsArray.length;
					for (var i = 0; i < endomorphismsArray.length; i++) {
						var x = source.getX() + Math.degCos(90 + i * angle);
						var y = source.getY() - Math.degSin(90 + i * angle);
						view.updateEndomorphism(endomorphismsArray[i], [x, y]);
						view.updateEndomorphismLabel(endomorphismsArray[i], [x, y]);
					}
				}
				break;
			case "dragSelected":
				console.log("dragSelected");
				var objs = states[currentStateIndices].objects;
				var morphs = states[currentStateIndices].morphisms;
				var endos = states[currentStateIndices].endomorphisms;
				if (states[currentStateIndices].objectsCurrentPositions.length === 0) {
					for (var i = 0; i < objs.length; i++) {
						var objectCurrentPosition = objs[i].getPosition();
						states[currentStateIndices].objectsCurrentPositions.push(objectCurrentPosition);
						var prevPosition = states[currentStateIndices].objectsPreviousPositions[i];
						console.log(objectCurrentPosition);
						console.log(prevPosition);
						view.updateCircle(objs[i], prevPosition);
						view.updateCircleLabel(objs[i], prevPosition);
						objs[i].setPosition(prevPosition);
						var objectMorphisms = objs[i].getMorphisms();
						for (var j = 0; j < objectMorphisms.length; j++) {
							var source = getObjectById(objectMorphisms[j].getSource());
							var target = getObjectById(objectMorphisms[j].getTarget());
							var ptr = view.translateBezier(objectMorphisms[j]);
							view.translateBezierLabel(objectMorphisms[j]);
							for (var k = 0; k < objectMorphisms.length; k++) {
								if (objectMorphisms[k] === objectMorphisms[j]) {
									var m = [0.5 * (source.getX() + target.getX()), 0.5 * (source.getY() + target.getY())];
									var realAngleBetweenObjects = Math.realAngle(source.getPosition(), target.getPosition());
									var sign = Math.pow(-1, source.getId() > target.getId());
									// var r = [m[0] - 2 * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
									var r = [m[0] - 2 * sign * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * sign * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
									var ptr = view.updateBezier(objectMorphisms[k], r);
									view.updateBezierLabel(objectMorphisms[k], r);
									objectMorphisms[k].setPoints([ptr.p0, ptr.p1, ptr.p2]);
									objectMorphisms[k].setCurvePath(ptr.curve.attr("d"));
									objectMorphisms[k].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
									break;
								}
							}
						}
						var objectEndomorphisms = objs[i].getEndomorphisms();
						for (var j = 0; j < objectEndomorphisms.length; j++) {
							view.translateEndomorphism(objectEndomorphisms[j], prevPosition, objectCurrentPosition);
							view.translateEndomorphismLabel(objectEndomorphisms[j]);
						}
					}
				} else {
					for (var i = 0; i < objs.length; i++) {
						var objectCurrentPosition = objs[i].getPosition();
						var temp = states[currentStateIndices].objectsCurrentPositions[i];
						states[currentStateIndices].objectsCurrentPositions[i] = states[currentStateIndices].objectsPreviousPositions[i];
						states[currentStateIndices].objectsPreviousPositions[i] = temp;
						var prevPosition = states[currentStateIndices].objectsPreviousPositions[i];
						view.updateCircle(objs[i], prevPosition);
						view.updateCircleLabel(objs[i], prevPosition);
						objs[i].setPosition(prevPosition);
						var objectMorphisms = objs[i].getMorphisms();
						for (var j = 0; j < objectMorphisms.length; j++) {
							var source = getObjectById(objectMorphisms[j].getSource());
							var target = getObjectById(objectMorphisms[j].getTarget());
							var ptr = view.translateBezier(objectMorphisms[j]);
							view.translateBezierLabel(objectMorphisms[j]);
							for (var k = 0; k < objectMorphisms.length; k++) {
								if (objectMorphisms[k] === objectMorphisms[j]) {
									var m = [0.5 * (source.getX() + target.getX()), 0.5 * (source.getY() + target.getY())];
									var realAngleBetweenObjects = Math.realAngle(source.getPosition(), target.getPosition());
									var sign = Math.pow(-1, source.getId() > target.getId());
									// var r = [m[0] - 2 * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
									var r = [m[0] - 2 * sign * (m[0] + j * DEFAULT_HANDLE_RADIUS * Math.degCos(realAngleBetweenObjects+90) - m[0]), m[1] + 2 * sign * (m[1] + j * DEFAULT_HANDLE_RADIUS * Math.degSin(realAngleBetweenObjects+90) - m[1])];
									var ptr = view.updateBezier(objectMorphisms[k], r);
									view.updateBezierLabel(objectMorphisms[k], r);
									objectMorphisms[k].setPoints([ptr.p0, ptr.p1, ptr.p2]);
									objectMorphisms[k].setCurvePath(ptr.curve.attr("d"));
									objectMorphisms[k].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
									break;
								}
							}
						}
						var objectEndomorphisms = objs[i].getEndomorphisms();
						for (var j = 0; j < objectEndomorphisms.length; j++) {
							view.translateEndomorphism(objectEndomorphisms[j], prevPosition, objectCurrentPosition);
							view.translateEndomorphismLabel(objectEndomorphisms[j]);
						}
					}
				}
				if (states[currentStateIndices].morphismsCurrentPositions.length === 0) {
					for (var i = 0; i < morphs.length; i++) {
						console.log(morphs[i].getHandlePosition());
						console.log(states[currentStateIndices].morphismsPreviousPositions[i]);
						var morphismCurrentPosition = morphs[i].getHandlePosition();
						states[currentStateIndices].morphismsCurrentPositions.push(morphismCurrentPosition);
						var prevPosition = states[currentStateIndices].morphismsPreviousPositions[i];
						var ptr = view.updateBezier(morphs[i], prevPosition);
						view.updateBezierLabel(morphs[i], prevPosition);
						morphs[i].setPoints([ptr.p0, ptr.p1, ptr.p2]);
						morphs[i].setCurvePath(ptr.curve.attr("d"));
						morphs[i].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
					}
				} else {
					for (var i = 0; i < morphs.length; i++) {
						// var morphismCurrentPosition = morphs[i].getHandlePosition();
						var temp = states[currentStateIndices].morphismsCurrentPositions[i];
						states[currentStateIndices].morphismsCurrentPositions[i] = states[currentStateIndices].morphismsPreviousPositions[i];
						states[currentStateIndices].morphismsPreviousPositions[i] = temp;
						var prevPosition = states[currentStateIndices].morphismsPreviousPositions[i];
						var ptr = view.updateBezier(morphs[i], prevPosition);
						view.updateBezierLabel(morphs[i], prevPosition);
						morphs[i].setPoints([ptr.p0, ptr.p1, ptr.p2]);
						morphs[i].setCurvePath(ptr.curve.attr("d"));
						morphs[i].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
					}
				}
				if (states[currentStateIndices].endomorphismsCurrentPositions.length === 0) {
					for (var i = 0; i < endos.length; i++) {
						var endomorphismCurrentPosition = endos[i].getHandlePosition();
						states[currentStateIndices].endomorphismsCurrentPositions.push(endomorphismCurrentPosition);
						var prevPosition = states[currentStateIndices].endomorphismsPreviousPositions[i];
						var ptr = view.updateEndomorphism(endos[i], prevPosition);
						view.updateEndomorphismLabel(endos[i], prevPosition);
						endos[i].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
					}
				} else {
					for (var i = 0; i < endos.length; i++) {
						// var endomorphismCurrentPosition = endos[i].getHandlePosition();
						var temp = states[currentStateIndices].endomorphismsCurrentPositions[i];
						states[currentStateIndices].endomorphismsCurrentPositions[i] = states[currentStateIndices].endomorphismsPreviousPositions[i];
						states[currentStateIndices].endomorphismsPreviousPositions[i] = temp;
						var prevPosition = states[currentStateIndices].endomorphismsPreviousPositions[i];
						var ptr = view.updateEndomorphism(endos[i], prevPosition);
						view.updateEndomorphismLabel(endos[i], prevPosition);
						endos[i].setHandlePosition([ptr.handle.attr("cx"), ptr.handle.attr("cy")]);
					}
				}
				break;
			case "pasteSelected":
				console.log("pasteSelected");
				pasteCounter--;
				var objs = states[currentStateIndices].objects;
				var morphs = states[currentStateIndices].morphisms;
				var endos = states[currentStateIndices].endomorphisms;
				for (var i = 0; i < objs.length; i++) {
					view.hideCircle(objs[i]);
					objs[i].setVisible(false);
				}
				for (var i = 0; i < morphs.length; i++) {
					view.hideBezier(morphs[i]);
					morphs[i].setVisible(false);
				}
				for (var i = 0; i < endos.length; i++) {
					view.hideEndomorphism(endos[i]);
					endos[i].setVisible(false);
				}
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
		currentStateIndices--;
	}
	
	/*
	Save current state
	*/
	this.saveCurrentState = function() {
		console.log("saveCurrentState");
		if (savedStates.last() !== states.last()) {
			savedStates.push(states.last());
		}
	}
	
	/*
	Delete previous state
	*/
	this.deletePreviousState = function() {
		console.log("deletePreviousState");
		savedStates.pop();
	}
	
	this.getDoneActions = function() {return doneActions;};
	this.getStates = function() {return states;};
}