---
name: Feature template
about: Something totally new to add

---

**Feature description**
A clear and concise description of what you want to happen.

**Additional context**
Add any other context or screenshots about the feature request here.
