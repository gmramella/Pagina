---
name: Refinement template
about: Software beautification

---

**Refinement description**
A clear and concise description of something that should be refined.

**Additional context**
Add any other context or screenshots about the feature request here.
