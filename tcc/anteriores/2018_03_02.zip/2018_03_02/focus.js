/*
Listener that runs when focus is lost
*/
window.addEventListener("blur", function(e) {
	if (!view) alert("View class missing, please refresh the page");
	view.createBlurRectangle();
	focused = false;
	
	if (keyboardMouseStatus !== "menu open") {
		if (keyboardMouseStatus === "object update") {
			keyboardMouseStatus = "idle";
			// console.log("idle");
			view.deselectCircle(listOfObjectsPressed[0]);
		} else if (keyboardMouseStatus === "morphism update") {
			keyboardMouseStatus = "idle";
			// console.log("idle");
			view.deselectBezier(listOfMorphismsPressed[0]);
		} else if (selectedElements.length === 0) {
			keyboardMouseStatus = "idle";
			// console.log("idle");
		} else {
			keyboardMouseStatus = "idle with element(s) selected";
			// console.log("idle with element(s) selected");
		}
	}
	
	leftMousedownOnCanvas = false;
	leftMousedownOnMultiple = false;
	leftMousedownOnObject = false;
	leftMousedownOnMorphism = false;
	
	rightMousedownOnCanvas = false;
	rightMousedownOnMultiple = false;
	rightMousedownOnObject = false;
	rightMousedownOnMorphism = false;
	
	if (selectionRectanglePtr) {
		view.deleteSelectionRectangle();
		selectionRectanglePtr = null;
	}
});

/*
Listener that runs when focus is regained
*/
window.addEventListener("focus", function(e) {
	if (!view) alert("View class missing, please refresh the page");
	view.removeBlurRectangle();
	focused = true;
});