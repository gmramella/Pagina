/*
Attributes used throughout the application
*/

var objectsCounter = 0;
var objects = [];
var objectLabels = [];
function getObjectById(id) {
	for (var i = 0; i < objects.length; i++) {
		if (objects[i].getId() === id) {
			return objects[i];
		}
	}
	return null;
}
function getObjectLabelById(id) {
	var count = 0;
	var found = false;
	for (var i = 0; i < objects.length; i++) {
		if (objects[i].getId() === id) {
			found = true;
			break;
		}
		count++;
	}
	if (found) {
		return objectLabels[count];
	}
	return null;
}
function removeObjectById(id) {
	for (var i = 0; i < objects.length; i++) {
		if (objects[i].getId() === id) {
			objects.splice(i, 1);
			break;
		}
	}
}
function removeObjectLabelById(id) {
	for (var i = 0; i < objectLabels.length; i++) {
		if (objectLabels[i][0] === id) {
			objectLabels.splice(i, 1);
			break;
		}
	}
}
/*
0	A
25	Z
26	AA
51	AZ
52	BA
77	BZ
676	AAA
...
*/
function currentObjectLabel() {
	return String.fromCharCode('A'.charCodeAt(0) + objectsCounter % 26);
}

var morphismsCounter = 0;
var morphisms = [];
var morphismLabels = [];
function getMorphismById(id) {
	for (var i = 0; i < morphisms.length; i++) {
		if (morphisms[i].getId() === id) {
			return morphisms[i];
		}
	}
	return null;
}
function getMorphismLabelById(id) {
	var count = 0;
	var found = false;
	for (var i = 0; i < morphisms.length; i++) {
		if (morphisms[i].getId() === id) {
			found = true;
			break;
		}
		count++;
	}
	if (found) {
		return morphismLabels[count];
	}
	return null;
}
function removeMorphismById(id) {
	for (var i = 0; i < morphisms.length; i++) {
		if (morphisms[i].getId() === id) {
			morphisms.splice(i, 1);
			break;
		}
	}
}
function removeMorphismLabelById(id) {
	for (var i = 0; i < morphismLabels.length; i++) {
		if (morphismLabels[i][0] === id) {
			morphismLabels.splice(i, 1);
			break;
		}
	}
}
/*
0	f
20	z
...
*/
function currentMorphismLabel() {
	return String.fromCharCode('f'.charCodeAt(0) + (morphismsCounter - objectsCounter) % 20);
}
function getMorphismLabelById(id) {
	for (var i = 0; i < morphisms.length; i++) {
		if (morphisms[i].getId() === id) {
			return morphisms[i].getLabel();
		}
	}
	return null;
}
function getMorphismsBySource(source) {
	var list = [];
	for (var i = 0; i < morphisms.length; i++) {
		if (morphisms[i].getSource() === source) {
			list.push(morphisms[i]);
		}
	}
	return list;
}
function getMorphismsBySourceOrTarget(source, target) {
	var list = [];
	for (var i = 0; i < morphisms.length; i++) {
		if ((morphisms[i].getSource() === source && morphisms[i].getTarget() === target) || (morphisms[i].getSource() === target && morphisms[i].getTarget() === source)) {
			list.push(morphisms[i]);
		}
	}
	return list;
}

var altPressed = false;
var altReleased = false;

var ctrlPressed = false;
var ctrlReleased = false;

var shiftPressed = false;
var shiftReleased = false;

var tabPressed = false;
var tabReleased = false;

var view = null;

var focused = true;

var mousedownCoords = null;

var mousemoveCoords = null;
var mousemoveDelta = null;

var mouseupCoords = null;

var collider = null;

var menu = null;

var selectedElements = [];
function deselectAll() {
	if (selectedElements.length > 0) {
		for (var i = 0; i < selectedElements.length; i++) {
			console.log(selectedElements[i]);
		}
	}
}

//Mouse global variables
var startTimes = [null, null];
var endTimes = [null, null];
var starts = [new Date(), new Date()];
var doubleClick = false;
var counter = 0;

var draggingAllowed = false;
var dragging = false;

var listOfObjectsPressed = [];
var listOfMorphismsPressed = [];
var listOfObjectsReleased = [];
var listOfMorphismsReleased = [];

var leftMousedownOnCanvas = false;
var leftMousedownOnMultiple = false;
var leftMousedownOnObject = false;
var leftMousedownOnMorphism = false;

var rightMousedownOnCanvas = false;
var rightMousedownOnMultiple = false;
var rightMousedownOnObject = false;
var rightMousedownOnMorphism = false;

var selectionRectanglePtr = null;
//----------------------

//Menu global variables
var menuOpen = false;
var menuCode = -1;
var inputOpen = false;
var inputCode = -1;
//---------------------

//Data transfer global variables
var copiedElements = [];
//------------------------------
function pasteCopiedElements() {
	console.log("paste copied elements");
}

//State variables
var state = null;
var hiddenElements = [];
//---------------

//Drawing variables
var drawingLastCoords = null;
var tabPressed = false;
var drawingAllowed = false;
//-----------------

//Input (keyboard+mouse) variables
var keyboardMouseStatus = "idle";
//--------------------------------

//Object creation variables
var lastCreatedObjectTimestamp = new Date().getTime();
var lastCreatedEndomorphismTimestamp = new Date().getTime();
//-------------------------