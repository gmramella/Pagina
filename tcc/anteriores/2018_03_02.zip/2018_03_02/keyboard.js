window.addEventListener("keypress", function(e) {
	var evtobj = window.event? event : e;
	if (evtobj.keyCode !== 123) e.preventDefault();
});

window.addEventListener("keydown", function(e) {
	var evtobj = window.event? event : e;
	ctrlPressed = evtobj.ctrlKey;
	shiftPressed = evtobj.shiftKey;
	
	if (evtobj.keyCode === 13) {
		alert(STR_CURRENT_STATE + ": " + keyboardMouseStatus);
	}
	switch (keyboardMouseStatus) {
		case "idle":
			if (ctrlPressed) {
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			} else if (shiftPressed) {
				keyboardMouseStatus = "shift";
				// console.log("shift");
			} else if (evtobj.keyCode === 8) {//backspace
				keyboardMouseStatus = "backspace";
				// console.log("backspace");
				drawing.eraseLastDrawing();
				keyboardMouseStatus = "idle";
				// console.log("idle");
			} else if (evtobj.keyCode === 9) {//tab
				e.preventDefault();
				keyboardMouseStatus = "tab";
				// console.log("tab");
				$("body").css("cursor", "pointer");
			} else if (evtobj.keyCode === 32) {//space
				e.preventDefault();
				keyboardMouseStatus = "space";
				// console.log("space");
				var str = "";
				if (objects.length === 1) {
					str += objects.length + " " + STR_OBJECT + "\r\n";
				} else {
					str += objects.length + " " + STR_OBJECTS + "\r\n";
				}
				for (var i = 0; i < objects.length; i++) {
					str += "id: " + objects[i].getId() + "\r\n";
					str += "label: " + objects[i].getLabel() + "\r\n";
					str += "x: " + objects[i].getX() + "\r\n";
					str += "y: " + objects[i].getY() + "\r\n";
					str += "radius: " + objects[i].getRadius() + "\r\n";
					str += "selected: " + objects[i].getSelected() + "\r\n";
					str += "visible: " + objects[i].getVisible() + "\r\n";
				}
				str += "\r\n";
				if (morphisms.length === 1) {
					str += morphisms.length + " " + STR_MORPHISM + "\r\n";
				} else {
					str += morphisms.length + " " + STR_MORPHISMS + "\r\n";
				}
				for (var i = 0; i < morphisms.length; i++) {
					str += "id: " + morphisms[i].getId() + "\r\n";
					str += "label: " + morphisms[i].getLabel() + "\r\n";
					str += "source: " + morphisms[i].getSource() + "\r\n";
					str += "target: " + morphisms[i].getTarget() + "\r\n";
					str += "width: " + morphisms[i].getWidth() + "\r\n";
					str += "type: " + morphisms[i].getType() + "\r\n";
					str += "selected: " + morphisms[i].getSelected() + "\r\n";
					str += "visible: " + morphisms[i].getVisible() + "\r\n";
				}
				alert(str);
				keyboardMouseStatus = "idle";
				// console.log("idle");
			} else if ((48 <= evtobj.keyCode && evtobj.keyCode <= 57) || (96 <= evtobj.keyCode && evtobj.keyCode <= 105)) {//0 to 9
				keyboardMouseStatus = "0-9";
				// console.log("0-9");
				drawing.changeBrushColor(evtobj.keyCode);
				keyboardMouseStatus = "idle";
				// console.log("idle");
			} else if (evtobj.keyCode === 107 || evtobj.keyCode === 109 || evtobj.keyCode === 173) {//+--
				keyboardMouseStatus = "+-";
				// console.log("+-");
				if (evtobj.keyCode === 107) drawing.increaseBrushSize();
				else drawing.decreaseBrushSize();
				keyboardMouseStatus = "idle";
				// console.log("idle");
			} else if (evtobj.keyCode === 112) {//F1
				keyboardMouseStatus = "f1";
				// console.log("f1");
				window.open("html/help.html", "_blank");
				keyboardMouseStatus = "idle";
				// console.log("idle");
			} else if (evtobj.keyCode === 113) {//F2
				keyboardMouseStatus = "f2";
				// console.log("f2");
				window.open("html/dev.html", "_blank");
				keyboardMouseStatus = "idle";
				// console.log("idle");
			}
			break;
		case "ctrl":
			if (shiftPressed) {
				keyboardMouseStatus = "ctrl+shift";
				// console.log("ctrl+shift");
			} else if (evtobj.keyCode === 32) {
				e.preventDefault();
				keyboardMouseStatus = "ctrl+space";
				// console.log("ctrl+space");
				var str = "";
				if (objects.length === 1) {
					str += objects.length + " " + STR_OBJECT + "\r\n";
				} else {
					str += objects.length + " " + STR_OBJECTS + "\r\n";
				}
				for (var i = 0; i < objects.length; i++) {
					var id = objects[i].getId();
					var object = d3.select("#circle"+id);
					str += "id: " + id + "\r\n";
					str += "cx: " + object.attr("cx") + "\r\n";
					str += "cy: " + object.attr("cy") + "\r\n";
					str += "r: " + object.attr("r") + "\r\n";
					str += "fill: " + object.attr("fill") + "\r\n";
				}
				str += "\r\n";
				if (morphisms.length === 1) {
					str += morphisms.length + " " + STR_MORPHISM + "\r\n";
				} else {
					str += morphisms.length + " " + STR_MORPHISMS + "\r\n";
				}
				for (var i = 0; i < morphisms.length; i++) {
					var id = morphisms[i].getId();
					str += "id: " + id + "\r\n";
					str += "type: " + morphisms[i].getType() + "\r\n";
					if (morphisms[i].getType() !== "endomorphism") {
						var morphism = d3.select(".curve"+id);
						str += "d: " + morphism.attr("d") + "\r\n";
						str += "fill: " + morphism.attr("fill") + "\r\n";
						str += "stroke-linecap: " + morphism.attr("stroke-linecap") + "\r\n";
						str += "stroke: " + morphism.attr("stroke") + "\r\n";
						str += "stroke-width: " + morphism.attr("stroke-width") + "\r\n";
					} else {
						var morphism = d3.select(".line"+id);
						var lines = [];
						lines.push(d3.select("#line"+id+"_"+0));
						lines.push(d3.select("#line"+id+"_"+1));
						lines.push(d3.select("#line"+id+"_"+2));
						lines.push(d3.select("#line"+id+"_"+3));
						lines.push(d3.select("#line"+id+"_"+4));
						var points = [];
						points.push(["["+lines[0].attr("x1"), lines[0].attr("y1")+"]"]);
						points.push(["["+lines[1].attr("x1"), lines[1].attr("y1")+"]"]);
						points.push(["["+lines[2].attr("x1"), lines[2].attr("y1")+"]"]);
						points.push(["["+lines[3].attr("x2"), lines[3].attr("y2")+"]"]);
						points.push(["["+lines[4].attr("x2"), lines[4].attr("y2")+"]"]);
						str += "points: " + points + "\r\n";
						str += "stroke: " + morphism.attr("stroke") + "\r\n";
						str += "stroke-width: " + morphism.attr("stroke-width") + "\r\n";
					}
				}
				alert(str);
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			} else if (evtobj.keyCode === 61) {
				keyboardMouseStatus = "+-";
				// console.log("+-");
				drawing.increaseBrushSize();
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			} else if (evtobj.keyCode === 'A'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+a";
				console.log("ctrl+a");
				console.log("??????????????");
				if (selectedElements.length > 0) {
					keyboardMouseStatus = "ctrl with element(s) selected";
					console.log("ctrl with element(s) selected");
				} else {
					keyboardMouseStatus = "ctrl";
					console.log("ctrl");
				}
			} else if (evtobj.keyCode === 8) {//backspace
				keyboardMouseStatus = "ctrl+backspace";
				// console.log("ctrl+backspace");
				drawing.eraseAllDrawings();
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			} else if (evtobj.keyCode === 'S'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+s";
				// console.log("ctrl+s");
				state.saveCurrentState();
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			} else if (evtobj.keyCode === 'V'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+v";
				console.log("ctrl+v");
				pasteCopiedElements();
				keyboardMouseStatus = "ctrl";
				console.log("ctrl");
			} else if (evtobj.keyCode === 'Y'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+y";
				console.log("ctrl+y");
				state.gotoNextState();
				keyboardMouseStatus = "ctrl";
				console.log("ctrl");
			} else if (evtobj.keyCode === 'Z'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+z";
				console.log("ctrl+z");
				state.gotoPrevState();
				keyboardMouseStatus = "ctrl";
				console.log("ctrl");
			}
			break;
		case "shift":
			if (ctrlPressed) {
				keyboardMouseStatus = "ctrl+shift";
				// console.log("ctrl+shift");
			}
			break;
		case "input open":
			if (evtobj.keyCode === 13) {//enter
				keyboardMouseStatus = "idle";
				console.log("idle");
			} else if (evtobj.keyCode === 27) {//esc
				keyboardMouseStatus = "idle";
				console.log("idle");
			}
			break;
		case "input open with element(s) selected":
			if (evtobj.keyCode === 13) {//enter
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 27) {//esc
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			}
			break;
		case "idle with element(s) selected":
			if (ctrlPressed) {
				keyboardMouseStatus = "ctrl with element(s) selected";
				// console.log("ctrl with element(s) selected");
			} else if (shiftPressed) {
				keyboardMouseStatus = "shift with element(s) selected";
				console.log("shift with element(s) selected");
			} else if (evtobj.keyCode === 8) {//backspace
				keyboardMouseStatus = "backspace with element(s) selected";
				console.log("backspace with element(s) selected");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 9) {//tab
				e.preventDefault();
				keyboardMouseStatus = "tab with element(s) selected";
				console.log("tab with element(s) selected");
			} else if (evtobj.keyCode === 46) {//delete
				keyboardMouseStatus = "selected delete";
				console.log("selected delete");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if ((48 <= evtobj.keyCode && evtobj.keyCode <= 57) || (96 <= evtobj.keyCode && evtobj.keyCode <= 105)) {//0 to 9
				keyboardMouseStatus = "0-9 with element(s) selected";
				console.log("0-9 with element(s) selected");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 107 || evtobj.keyCode === 109 || evtobj.keyCode === 173) {//+--
				keyboardMouseStatus = "+- with element(s) selected";
				console.log("+- with element(s) selected");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 112) {//F1
				keyboardMouseStatus = "f1 with element(s) selected";
				console.log("f1 with element(s) selected");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 113) {//F2
				keyboardMouseStatus = "f2 with element(s) selected";
				console.log("f2 with element(s) selected");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			}
			break;
		case "ctrl with element(s) selected":
			if (shiftPressed) {
				keyboardMouseStatus = "ctrl+shift with element(s) selected";
				console.log("ctrl+shift with element(s) selected");
			} else if (evtobj.keyCode === 61) {
				keyboardMouseStatus = "+-";
				console.log("+-");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl with element(s) selected";
				console.log("ctrl with element(s) selected");
			} else if (evtobj.keyCode === 'A'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+a";
				console.log("ctrl+a");
				console.log("??????????????");
				keyboardMouseStatus = "idle with element(s) selected";
				console.log("idle with element(s) selected");
			} else if (evtobj.keyCode === 8) {//backspace
				keyboardMouseStatus = "ctrl+backspace";
				console.log("ctrl+backspace");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl with element(s) selected";
				console.log("ctrl with element(s) selected");
			} else if (evtobj.keyCode === 'S'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+s";
				console.log("ctrl+s");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl with element(s) selected";
				console.log("ctrl with element(s) selected");
			} else if (evtobj.keyCode === 'V'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+v";
				console.log("ctrl+v");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl";
				console.log("ctrl");
			} else if (evtobj.keyCode === 'X'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+x";
				console.log("ctrl+x");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl";
				console.log("ctrl");
			} else if (evtobj.keyCode === 'Y'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+y";
				console.log("ctrl+y");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl with element(s) selected";
				console.log("ctrl with element(s) selected");
			} else if (evtobj.keyCode === 'Z'.charCodeAt(0)) {
				keyboardMouseStatus = "ctrl+z";
				console.log("ctrl+z");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl with element(s) selected";
				console.log("ctrl with element(s) selected");
			}
			break;
		case "shift with element(s) selected":
			if (ctrlPressed) {
				keyboardMouseStatus = "ctrl+shift with element(s) selected";
				console.log("ctrl+shift with element(s) selected");
			}
			break;
		case "ctrl+shift with element(s) selected":
			if (evtobj.keyCode === 'A'.charCodeAt(0)) {
				keyboardMouseStatus = "deselect all";
				console.log("deselect all");
				console.log("??????????????");
				keyboardMouseStatus = "ctrl+shift";
				console.log("ctrl+shift");
			}
			break;
	}
	
	// if (menuOpen) {
		// if (evtobj.keyCode === 27) {//ESC
			// $(document).click();
		// }
		// if (menuCode === CANVAS_MENU) {
			// switch (evtobj.keyCode) {
				// case SHORTCUT_CREATE_OBJECT.charCodeAt(0):
					// menu.openInputDialog(CREATE_OBJECT);
					// break;
				// case SHORTCUT_SELECT_ALL.charCodeAt(0):
					// menu.openInputDialog(SELECT_ALL);
					// break;
				// case SHORTCUT_SELECT_OBJECTS.charCodeAt(0):
					// menu.openInputDialog(SELECT_OBJECTS);
					// break;
				// case SHORTCUT_SELECT_MORPHISMS.charCodeAt(0):
					// menu.openInputDialog(SELECT_MORPHISMS);
					// break;
				// }
		// } else if (menuCode === OBJECT_MENU) {
			// switch (evtobj.keyCode) {
				// case SHORTCUT_CREATE_MORPHISM_TO.charCodeAt(0):
					// menu.openInputDialog(CREATE_MORPHISM_TO);
					// break;
				// case SHORTCUT_CREATE_MORPHISM_FROM.charCodeAt(0):
					// menu.openInputDialog(CREATE_MORPHISM_FROM);
					// break;
				// case SHORTCUT_READ_OBJECT.charCodeAt(0):
					// menu.openInputDialog(READ_OBJECT);
					// break;
				// case SHORTCUT_UPDATE_OBJECT.charCodeAt(0):
					// menu.openInputDialog(UPDATE_OBJECT);
					// break;
				// case SHORTCUT_DELETE_OBJECT.charCodeAt(0):
					// menu.openInputDialog(DELETE_OBJECT);
					// break;
				// case SHORTCUT_SELECT_OBJECT.charCodeAt(0):
					// menu.openInputDialog(SELECT_OBJECT);
					// break;
			// }
		// } else if (menuCode === MORPHISM_MENU) {
			// switch (evtobj.keyCode) {
				// case SHORTCUT_READ_MORPHISM.charCodeAt(0):
					// menu.openInputDialog(READ_MORPHISM);
					// break;
				// case SHORTCUT_UPDATE_MORPHISM.charCodeAt(0):
					// menu.openInputDialog(UPDATE_MORPHISM);
					// break;
				// case SHORTCUT_DELETE_MORPHISM.charCodeAt(0):
					// menu.openInputDialog(DELETE_MORPHISM);
					// break;
				// case SHORTCUT_SELECT_MORPHISM.charCodeAt(0):
					// menu.openInputDialog(SELECT_MORPHISM);
					// break;
			// }
		// }
	// } else if (inputOpen) {
		// if (evtobj.keyCode === 13) {//ENTER
			// menu.executeInput();
		// } else if (evtobj.keyCode === 27) {//ESC
			// inputOpen = false;
			// inputCode = -1;
			// $("#objectInput").hide();
			// $("#morphismInput").hide();
		// }
	// } else {
		// if ((48 <= evtobj.keyCode && evtobj.keyCode <= 57) || (96 <= evtobj.keyCode && evtobj.keyCode <= 105)) {//0 to 9
			// drawing.changeBrushColor(evtobj.keyCode);
		// } else if ((evtobj.keyCode === 61 && ctrlPressed) || evtobj.keyCode === 107 || evtobj.keyCode === 173 || evtobj.keyCode === 109) {//+/-
			// if (evtobj.keyCode === 173 || evtobj.keyCode === 109) {
				// e.preventDefault();
				// drawing.decreaseBrushSize();
			// } else if ((evtobj.keyCode === 61 && ctrlPressed) || evtobj.keyCode === 107) {
				// e.preventDefault();
				// drawing.increaseBrushSize();
			// }
		// } else {
			// switch (evtobj.keyCode) {
				// case 8://backspace
					// e.preventDefault();
					// if (ctrlPressed) {
						// drawing.eraseAllDrawings();
					// } else {
						// drawing.eraseLastDrawing();
					// }
					// break;
				// case 9://tab
					// e.preventDefault();
					// tabPressed = true;
					// break;
				// case 32://space
					// e.preventDefault();
					// if (objects.length === 1) console.log(objects.length + " " + STR_OBJECT); else console.log(objects.length + " " + STR_OBJECTS);
					// objects.forEach(function(c, i) {objects[i].description();});
					// if (morphisms.length === 1) console.log(morphisms.length + " " + STR_MORPHISM); else console.log(morphisms.length + " " + STR_MORPHISMS);
					// morphisms.forEach(function(c, i) {morphisms[i].description();});
					// break;
				// case 46://delete
					// console.log("last operation: "+"deleteSelected");
					// //state.createState("deleteSelected");
					// break;
				// case 'A'.charCodeAt(0):
					// if (ctrlPressed && shiftPressed) {//deselect all
						// e.preventDefault();
						// if (selectedElements.length > 0) {
							// for (var i = 0; i < selectedElements.length; i++) {
								// if (selectedElements[i].type === "object") {
									// view.deselectObject(selectedElements[i].element);
								// } else if (selectedElements[i].type === "morphism") {
									// view.deselectMorphism(selectedElements[i].element);
								// } else if (selectedElements[i].type === "endomorphism") {
									// view.deselectMorphism(selectedElements[i].element);
								// }
							// }
							// selectedElements = [];
						// }
					// } else if (ctrlPressed) {//select all
						// if (selectedElements.length < objects.length + morphisms.length) {
							// selectedElements = [];
							// for (var i = 0; i < objects.length; i++) {
								// selectedElements.push({type: "object", element: objects[i]});
								// view.selectObject(objects[i]);
							// }
							// for (var i = 0; i < morphisms.length; i++) {
								// var id = morphisms[i].getId();
								// if (morphisms[i].getType() !== "endomorphism") {
									// selectedElements.push({type: "morphism", element: morphisms[i]});
									// view.selectMorphism(morphisms[i]);
								// } else {
									// selectedElements.push({type: "endomorphism", element: morphisms[i]});
									// view.selectMorphism(morphisms[i]);
								// }
							// }
						// }
					// }
					// break;
				// case 'C'.charCodeAt(0):
					// if (ctrlPressed) {//pasteElements selected
						// //view.removeHiddenElements();
						// copiedElements = selectedElements.slice();
					// }
					// break;
				// case 'S'.charCodeAt(0):
					// if (ctrlPressed) {//save (what?)
						// e.preventDefault();
						// alert("CTRL+S");
					// }
					// break;
				// case 'V'.charCodeAt(0):
					// if (ctrlPressed) {//paste selected (where?)
						// //view.removeHiddenElements();
						// var pasteElements = copiedElements.slice();
						// for (var i = 0; i < pasteElements.length; i++) {
							// if (pasteElements[i].type === "object") {
								// // var x = pasteElements[i].element.getX() + SELECTED_CIRCLE_RADIUS;
								// // var y = pasteElements[i].element.getY() + SELECTED_CIRCLE_RADIUS;
								// // pasteElements[i].element.setPosition([x, y]);
								// // var newObject = new Object(x, y);
								// // objects.push(newObject);
								// // d3.select(".layer3").append("circle").attr("class", "circle").attr("id", "circle"+objectsCounter).attr("cx", x).attr("cy", y).attr("r", DEFAULT_CIRCLE_RADIUS).attr("fill", DEFAULT_CIRCLE_COLOR);
								// // var text = currentObjectLabel();
								// // var circleLabelPtr = d3.select(".layer3").append("text").attr("class", "circlelabel").attr("id", "circlelabel"+objectsCounter).text(text).attr("x", x).attr("y", y+8).attr("font-family", DEFAULT_CIRCLE_LABEL_FONT_NAME).attr("font-size", DEFAULT_CIRCLE_LABEL_FONT_SIZE).attr("fill", DEFAULT_CIRCLE_LABEL_COLOR);
								// // circleLabelPtr.attr("x", circleLabelPtr.attr("x")-document.getElementById("circlelabel"+objectsCounter).getComputedTextLength()/2);//align center
								// // objectLabels.push([objectsCounter, currentObjectLabel()]);
								// // objectsCounter++;
							// } else if (pasteElements[i].type === "morphism") {
								// console.log(pasteElements[i].element);
							// } else if (pasteElements[i].type === "endomorphism") {
								// console.log(pasteElements[i].element);
								// // var p = getObjectById(pasteElements[i].element.getSource()).getPosition();
								// // var r = getObjectById(pasteElements[i].element.getSource()).getRadius();
								// // var angle;
								// // var d = [r * Math.cos(Math.degToRad(angle)),				-r * Math.sin(Math.degToRad(angle))];
								// // var points = [];
								// // points.push([p[0],											p[1]]);
								// // points.push([r * Math.cos(Math.degToRad(angle + 30)),		-r * Math.sin(Math.degToRad(angle + 30))]);
								// // points.push([r * Math.cos(Math.degToRad(angle - 30)),		-r * Math.sin(Math.degToRad(angle - 30))]);
								// // points.push([r * Math.cos(Math.degToRad(angle)) / 2,		-r * Math.sin(Math.degToRad(angle)) / 2]);
								// // points.push([r * Math.cos(Math.degToRad(angle - 90)) / 2,	-r * Math.sin(Math.degToRad(angle - 90)) / 2]);
								// // points[0][0] += d[0];points[0][1] += d[1];
								// // for (var i = 1; i < points.length; i++) {
									// // points[i][0] += points[0][0];points[i][1] += points[0][1];
								// // }
								
								// // d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[1][0]).attr("y2", points[1][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
								// // d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("x1", points[1][0]).attr("y1", points[1][1]).attr("x2", points[2][0]).attr("y2", points[2][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
								// // d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("x1", points[2][0]).attr("y1", points[2][1]).attr("x2", points[0][0]).attr("y2", points[0][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
								
								// // d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[3][0]).attr("y2", points[3][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
								// // d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[4][0]).attr("y2", points[4][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
								// // //.attr("class", "class1").attr("class", "class2") will not add 2 classes
							// }
						// }
						// //deselecionar todos
						// hiddenElements = [];
						// console.log("last operation: "+"pasteSelected");
					// }
					// break;
				// case 'X'.charCodeAt(0):
					// if (ctrlPressed) {//cut selected
						// copiedElements = selectedElements.slice();
						// hiddenElements = selectedElements.slice();
						// for (var i = 0; i < copiedElements.length; i++) {
							// if (copiedElements[i].type === "object") {
								// view.hideObject(copiedElements[i].element);
							// } else if (copiedElements[i].type === "morphism") {
								// view.hideMorphism(copiedElements[i].element);
							// } else if (copiedElements[i].type === "endomorphism") {
								// view.hideMorphism(copiedElements[i].element);
							// }
						// }
						// selectedElements = [];
						// console.log("last operation: "+"cutSelected");
					// }
					// break;
				// case 'Y'.charCodeAt(0):
					// if (ctrlPressed) {//redo last action
						// //state.gotoNextState();
					// }
					// break;
				// case 'Z'.charCodeAt(0):
					// if (ctrlPressed) {//undo last action
						// //state.gotoPrevState();
					// }
					// break;
				// case 112://F1
					// window.open("html/help.html", "_blank").focus();
					// break;
				// case 113://F2
					// window.open("html/dev.html", "_blank").focus();
					// break;
			// }
		// }
	// }
});

window.addEventListener("keyup", function(e) {
	var evtobj = window.event? event : e;
	ctrlReleased = ctrlPressed && !evtobj.ctrlKey;
	shiftReleased = shiftPressed && !evtobj.shiftKey;
	
	switch (keyboardMouseStatus) {
		case "ctrl":
			if (ctrlReleased) {
				keyboardMouseStatus = "idle";
				// console.log("idle");
			}
			break;
		case "shift":
			if (shiftReleased) {
				keyboardMouseStatus = "idle";
				// console.log("idle");
			}
			break;
		case "ctrl+shift":
			if (ctrlReleased) {
				keyboardMouseStatus = "shift";
				// console.log("shift");
			} else if (shiftReleased) {
				keyboardMouseStatus = "ctrl";
				// console.log("ctrl");
			}
			break;
		case "tab":
			if (evtobj.keyCode === 9) {//tab
				keyboardMouseStatus = "idle";
				// console.log("idle");
				$("body").css("cursor", "default");
			}
			break;
		case "ctrl with element(s) selected":
			if (ctrlReleased) {
				keyboardMouseStatus = "idle with element(s) selected";
				// console.log("idle with element(s) selected");
			}
			break;
	}
});