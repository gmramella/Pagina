function Menu() {
	//Eric Martin's SimpleModal library and jQuery UI did not work when this project was upgraded to OOP
	//http://www.ericmmartin.com/projects/ and https://jqueryui.com/
	
	$("body").prepend('\
		<div id="canvasMenu">\
			<ul id="canvasItems">\
			</ul>\
		</div>\
		<div id="objectMenu">\
			<ul id="objectItems">\
			</ul>\
		</div>\
		<div id="morphismMenu">\
			<ul id="morphismItems">\
			</ul>\
		</div>\
	');
	
	$("#canvasItems").append('<li onclick="menu.openInputDialog(CREATE_OBJECT)"><u>C</u>reate object</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_ALL)">Select <u>a</u>ll</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_OBJECTS)">Select <u>o</u>bjects</li>');
	$("#canvasItems").append('<li onclick="menu.openInputDialog(SELECT_MORPHISMS)">Select <u>m</u>orphisms</li>');
	
	$("#objectItems").append('<li onclick="menu.openInputDialog(CREATE_MORPHISM_TO)">Create morphism <u>t</u>o</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(CREATE_MORPHISM_FROM)">Create morphism <u>f</u>rom</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(READ_OBJECT)"><u>R</u>ead object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(UPDATE_OBJECT)"><u>U</u>pdate object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(DELETE_OBJECT)"><u>D</u>elete object</li>');
	$("#objectItems").append('<li onclick="menu.openInputDialog(SELECT_OBJECT)"><u>S</u>elect object</li>');
	
	$("#morphismItems > li").remove();
	$("#morphismItems").append('<li onclick="menu.openInputDialog(READ_MORPHISM)"><u>R</u>ead morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(UPDATE_MORPHISM)"><u>U</u>pdate morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(DELETE_MORPHISM)"><u>D</u>elete morphism</li>');
	$("#morphismItems").append('<li onclick="menu.openInputDialog(SELECT_MORPHISM)"><u>S</u>elect morphism</li>');
	
	$("body").prepend('\
		<div id="objectInput" style="display:none">\
			<form>\
			<label>id</label><input type="number" name="id" value="id" disabled><br>\
			<label>label</label><input type="text" name="label" value="label" disabled><br>\
			<label>x</label><input type="number" name="x" value="x" disabled><br>\
			<label>y</label><input type="number" name="y" value="y" disabled><br>\
			<label>radius</label><input type="number" name="radius" value="radius" disabled><br>\
			<button id="ok" type="button" onclick="menu.executeInputDialog()">OK</button>\
			<button id="quit" type="button" onclick="menu.closeObjectInputDialog()">QUIT</button>\
			<button id="reset" type="button" onclick="menu.resetInputDialog()">RESET</button>\
			</form>\
		</div>\
		<div id="morphismInput" style="display:none">\
			<form>\
			<label>id</label><input type="number" name="id" value="id" disabled><br>\
			<label>label</label><input type="text" name="label" value="label" disabled><br>\
			<label>source</label><input type="number" name="source" value="source" disabled><br>\
			<label>target</label><input type="number" name="target" value="target" disabled><br>\
			<label>width</label><input type="number" name="width" value="width" disabled><br>\
			<label>type</label><input type="number" name="type" value="type" disabled><br>\
			<button id="ok" type="button" onclick="menu.executeInputDialog()">OK</button>\
			<button id="quit" type="button" onclick="menu.closeMorphismInputDialog()">QUIT</button>\
			<button id="reset" type="button" onclick="menu.resetInputDialog()">RESET</button>\
			</form>\
		</div>\
	');
	
	/*
	Open input dialog
	*/
	this.openInputDialog = function (opt) {
		if (keyboardMouseStatus === "menu open") {
			keyboardMouseStatus = "input open";
			console.log("input open");
		} else if (keyboardMouseStatus === "menu open with element(s) selected") {
			keyboardMouseStatus = "input open with element(s) selected";
			console.log("input open with element(s) selected");
		}
		$(document).click();
		switch (opt) {
			case CREATE_OBJECT:
				alert("Create object");
				break;
			case SELECT_ALL:
				alert("Select all");
				break;
			case SELECT_OBJECTS:
				alert("Select objects");
				break;
			case SELECT_MORPHISMS:
				alert("Select morphisms");
				break;
			case CREATE_MORPHISM_TO:
				alert("Create morphism to");
				break;
			case CREATE_MORPHISM_FROM:
				alert("Create morphism from");
				break;
			case READ_OBJECT:
				inputOpen = true;
				inputCode = READ_OBJECT;
				var fields = $("#objectInput").children()[0];
				var selectedObject = listOfObjectsPressed[0];
				var allAtributes = selectedObject.getAll();
				for (var i = 0; i < 5; i++) {
					fields[i].value = allAtributes[i];
				}
				$("#objectInput").css("left", $("#objectMenu").css("left"));
				$("#objectInput").css("top", $("#objectMenu").css("top"));
				$("#objectInput").css("background", DEFAULT_CIRCLE_COLOR);
				$("#objectInput > form > input").css("background", DEFAULT_OBJECT_INPUT_COLOR);
				$("#objectInput > form > input").css("color", "#000000");
				$("#objectInput").show();
				//alert("Read object");
				break;
			case UPDATE_OBJECT:
				alert("Update object");
				break;
			case DELETE_OBJECT:
				alert("Delete object");
				break;
			case SELECT_OBJECT:
				alert("Select object");
				break;
			case READ_MORPHISM:
				alert("Read morphism");
				break;
			case UPDATE_MORPHISM:
				alert("Update morphism");
				break;
			case DELETE_MORPHISM:
				alert("Delete morphism");
				break;
			case SELECT_MORPHISM:
				alert("Select morphism");
				break;
		}
	}
	
	/*
	Execute input dialog
	*/
	this.executeInputDialog = function() {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "input execute";
			console.log("input execute");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "input execute with element(s) selected";
			console.log("input execute with element(s) selected");
		}
		switch (inputCode) {
			case CREATE_OBJECT:
				console.log("last operation: "+"createObject");
				break;
			case SELECT_ALL:
				console.log("last operation: "+"selectAll");
				break;
			case SELECT_OBJECTS:
				console.log("last operation: "+"selectObjects");
				break;
			case SELECT_MORPHISMS:
				console.log("last operation: "+"selectMorphisms");
				break;
			case CREATE_MORPHISM_TO:
				console.log("last operation: "+"createMorphismTo");
				break;
			case CREATE_MORPHISM_FROM:
				console.log("last operation: "+"createMorphismFrom");
				break;
			case READ_OBJECT:
				inputOpen = false;
				inputCode = -1;
				$("#objectInput").hide();
				//$("#morphismInput").hide();
				console.log("last operation: "+"createObject");
				break;
			case UPDATE_OBJECT:
				console.log("last operation: "+"updateObject");
				break;
			case DELETE_OBJECT:
				console.log("last operation: "+"deleteObject");
				break;
			case SELECT_OBJECT:
				break;
			case READ_MORPHISM:
				console.log("last operation: "+"createObject");
				break;
			case UPDATE_MORPHISM:
				console.log("last operation: "+"updateMorphism");
				break;
			case DELETE_MORPHISM:
				console.log("last operation: "+"deleteMorphism");
				break;
			case SELECT_MORPHISM:
				break;
		}
		if (keyboardMouseStatus === "input execute") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input execute with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
	}
	
	/*
	Close object input dialog
	*/
	this.closeObjectInputDialog = function () {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
		inputOpen = false;inputCode = -1;$("#objectInput").hide();
	}
	
	/*
	Close morphism input dialog
	*/
	this.closeMorphismInputDialog = function () {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "idle";
			console.log("idle");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "idle with element(s) selected";
			console.log("idle with element(s) selected");
		}
		inputOpen = false;inputCode = -1;$("#morphismInput").hide();
	}
	
	/*
	Reset input dialog
	*/
	this.resetInputDialog = function() {
		if (keyboardMouseStatus === "input open") {
			keyboardMouseStatus = "input open";
			console.log("input open");
		} else if (keyboardMouseStatus === "input open with element(s) selected") {
			keyboardMouseStatus = "input open with element(s) selected";
			console.log("input open with element(s) selected");
		}
		switch (inputCode) {
			case CREATE_OBJECT:
				break;
			case SELECT_ALL:
				break;
			case SELECT_OBJECTS:
				break;
			case SELECT_MORPHISMS:
				break;
			case CREATE_MORPHISM_TO:
				break;
			case CREATE_MORPHISM_FROM:
				break;
			case READ_OBJECT:
				var fields = $("#objectInput").children()[0];
				var selectedObject = listOfObjectsPressed[0];
				var allAtributes = selectedObject.getAll();
				for (var i = 0; i < 5; i++) {
					fields[i].value = allAtributes[i];
				}
				break;
			case UPDATE_OBJECT:
				break;
			case DELETE_OBJECT:
				break;
			case SELECT_OBJECT:
				break;
			case READ_MORPHISM:
				break;
			case UPDATE_MORPHISM:
				break;
			case DELETE_MORPHISM:
				break;
			case SELECT_MORPHISM:
				break;
		}
	}
}