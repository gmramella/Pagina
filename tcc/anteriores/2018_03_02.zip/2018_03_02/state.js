/*
doneActions/undoneActions: string in { 
	"createEndomorphism", "createMorphism", "createMorphismFrom", "createMorphismTo", "createObject", 
	"cutSelected", 
	"deleteMorphism", "deleteObject", "deleteSelected"
	"dragMorphism", "dragObject", 
	"pasteSelected", 
	"redoLastAction", 
	"undoLastAction", 
	"updateMorphism", "updateObject"
}
states: list of descriptions
currentStateIndices: natural number or -1, indicating empty list
*/
function State() {
	var doneActions = [];
	var undoneActions = [];
	var states = [];
	var currentStateIndices = -1;
	var savedStates = [];
	
	/*
	Remove undone actions when new action is done
	*/
	function removeUndoneActions() {
		for (var i = currentStateIndices + 1; i < states.length; i++) {
			switch (undoneActions[i]) {
				case "createEndomorphism":
					break;
				case "createMorphism":
					var createdMorphism = states[i].morphisms[0];
					var morphismId = createdMorphism.getId();
					removeMorphismById(morphismId);
					removeMorphismLabelById(morphismId);
					break;
				case "createMorphismFrom":
					break;
				case "createMorphismTo":
					break;
				case "createObject":
					var createdObject = states[i].objects[0];
					var objectId = createdObject.getId();
					var idEndomorphismId = createdObject.getEndomorphisms()[0].getId();
					removeMorphismById(idEndomorphismId);
					removeMorphismLabelById(idEndomorphismId);
					removeObjectById(objectId);
					removeObjectLabelById(objectId);
					break;
				case "cutSelected":
					break;
				case "deleteMorphism":
					break;
				case "deleteObject":
					break;
				case "deleteSelected":
					break;
				case "dragMorphism":
					break;
				case "dragObject":
					break;
				case "pasteSelected":
					break;
				case "redoLastAction":
					break;
				case "undoLastAction":
					break;
				case "updateMorphism":
					break;
				case "updateObject":
					break;
			}
		}
		states.splice(currentStateIndices + 1, undoneActions.length);
		undoneActions = [];
	}
	
	/*
	Create state with new action
	*/
	this.createState = function(action) {
		switch (action) {
			case "createEndomorphism":
				break;
			case "createMorphism":
				this.removeHiddenElements();
				if ((currentStateIndices+1) !== states.length) {
					removeUndoneActions();
				} else if (hiddenElements.length > 0) {
					view.removeHiddenElements();
				}
				doneActions.push("createMorphism");
				var description = {objects: [], objectLabels: [], morphisms: [morphisms[morphismsCounter - 1]], morphismLabels: [morphismLabels[morphismsCounter - 1]], selectedElements: []};
				states.push(description);
				currentStateIndices++;
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				this.removeHiddenElements();
				if ((currentStateIndices+1) !== states.length) {
					removeUndoneActions();
				} else if (hiddenElements.length > 0) {
					view.removeHiddenElements();
				}
				doneActions.push("createObject");
				var description = {objects: objects[objectsCounter - 1], objectLabels: objectLabels[objectsCounter - 1], morphisms: [], morphismLabels: [], selectedElements: []};
				states.push(description);
				currentStateIndices++;
				break;
			case "cutSelected":
				break;
			case "deleteMorphism":
				break;
			case "deleteObject":
				break;
			case "deleteSelected":
				if ((currentStateIndices+1) !== states.length) {
					removeUndoneActions();
				} else if (hiddenElements.length > 0) {
					view.removeHiddenElements();
				}
				doneActions.push("deleteSelected");
				console.log(selectedElements);
				var objects = [];
				var objectLabels = [];
				var morphisms = [];
				var morphismLabels = [];
				for (var i = 0; i < selectedElements.length; i++) {
					if (selectedElements[i].type === "object") {
						view.hideObject(selectedElements[i].element);
					} else if (selectedElements[i].type === "morphism") {
						view.hideMorphism(selectedElements[i].element);
					} else if (selectedElements[i].type === "endomorphism") {
						view.hideMorphism(selectedElements[i].element);
					}
				}
				var description = {objects: objects, objectLabels: objectLabels, morphisms: morphisms, morphismLabels: morphismLabels, selectedElements: null};
				states.push(description);
				currentStateIndices++;
				break;
			case "dragMorphism":
				break;
			case "dragObject":
				break;
			case "pasteSelected":
				break;
			case "redoLastAction":
				break;
			case "undoLastAction":
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
	}
	
	/*
	Go to next state on the stack of states
	*/
	this.gotoNextState = function() {
		if ((currentStateIndices + 1) >= states.length) {
			alert(STR_NO_MORE_REDO);
			return;
		}
		doneActions.push(undoneActions.pop());
		switch (doneActions.last()) {
			case "createEndomorphism":
				break;
			case "createMorphism":
				view.showMorphism(states[currentStateIndices + 1].morphisms[0]);
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				view.showObject(states[currentStateIndices + 1].objects[0]);
				break;
			case "cutSelected":
				break;
			case "deleteMorphism":
				break;
			case "deleteObject":
				break;
			case "deleteSelected":
				break;
			case "dragMorphism":
				break;
			case "dragObject":
				break;
			case "pasteSelected":
				break;
			case "redoLastAction":
				break;
			case "undoLastAction":
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
		currentStateIndices++;
	}
	
	/*
	Go to previous state on the stack of states
	*/
	this.gotoPrevState = function() {
		if (currentStateIndices < 0) {
			alert(STR_NO_MORE_UNDO);
			return;
		}
		undoneActions.push(doneActions.pop());
		switch (undoneActions[undoneActions.length - 1]) {
			case "createEndomorphism":
				break;
			case "createMorphism":
				view.hideMorphism(states[currentStateIndices].morphisms[0]);
				break;
			case "createMorphismFrom":
				break;
			case "createMorphismTo":
				break;
			case "createObject":
				view.hideObject(states[currentStateIndices].objects[0]);
				break;
			case "cutSelected":
				break;
			case "deleteMorphism":
				break;
			case "deleteObject":
				break;
			case "deleteSelected":
				break;
			case "dragMorphism":
				break;
			case "dragObject":
				break;
			case "pasteSelected":
				break;
			case "redoLastAction":
				break;
			case "undoLastAction":
				break;
			case "updateMorphism":
				break;
			case "updateObject":
				break;
		}
		currentStateIndices--;
	}
	
	this.saveCurrentState = function() {
		savedStates.push(states.last());
		// console.log(savedStates.last());
	}
}