function View() {
	this.canvasWidth = Math.floor(0.99 * (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth));
	this.canvasHeight = Math.floor(0.96 * (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight));
	
	//Canvas methods
	/*
	Create canvas with 99% and 96% of the canvas' width and height, respectively
	and different layers
		layer 0: border rectangle and blur rectangle
		layer 1: selection rectangle
		layer 2: morphisms
		layer 3: objects
		layer 4: morphisms' handles
		layer 5: free drawing
		layer 6: debugging grid
	and a border
	*/
	this.createCanvas = function() {
		var canvasPtr = d3.select("body").append("svg").attr("id", "canvas").attr("width", this.canvasWidth).attr("height", this.canvasHeight);
		//https://www.dashingd3js.com/svg-group-element-and-d3js
		//https://stackoverflow.com/questions/31383045/appending-to-group-not-working-in-d3-js
		canvasPtr.append("g").attr("class", "layer6").append("g").attr("class", "layer5").append("g").attr("class", "layer4").append("g").attr("class", "layer3").append("g").attr("class", "layer2").append("g").attr("class", "layer1").append("g").attr("class", "layer0");
		d3.select(".layer0").append("rect").attr("id", "borderRectangle").attr("x", 0).attr("y", 0).attr("width", this.canvasWidth).attr("height", this.canvasHeight).attr("stroke", "#000000").attr("fill", "none");
		return canvasPtr;
	};
	this.canvas = this.createCanvas();
	
	this.createGrid = function() {
		var d = 20;
		for (var i=0;i<(this.canvasHeight-d)/d;i++) {
			d3.select(".layer6").append("line").attr("x1", 0).attr("y1", d*i).attr("x2", this.canvasWidth-d).attr("y2", d*i).attr("stroke", "black").attr("stroke-width", 1);
		}
		for (var i=0;i<(this.canvasWidth-d)/d;i++) {
			d3.select(".layer6").append("line").attr("x1", d*i).attr("y1", 0).attr("x2", d*i).attr("y2", this.canvasHeight-d).attr("stroke", "black").attr("stroke-width", 1);
		}
		for (var i=0;i<(this.canvasWidth-d)/d;i++) {
			var ptr = d3.select(".layer6").append("text").attr("id", "circlelabel1"+i).text(d*i).attr("x", d*i).attr("y", this.canvasHeight).attr("font-family", "sans-serif").attr("font-size", 8).attr("fill", "black");
			ptr.attr("x", ptr.attr("x")-document.getElementById("circlelabel1"+i).getComputedTextLength()/2);//align center
		}
		for (var i=0;i<(this.canvasHeight-d)/d;i++) {
			var ptr = d3.select(".layer6").append("text").attr("id", "circlelabel2"+i).text(d*i).attr("x", this.canvasWidth-d/2).attr("y", d*i).attr("font-family", "sans-serif").attr("font-size", 8).attr("fill", "black");
			ptr.attr("x", ptr.attr("x")-document.getElementById("circlelabel2"+i).getComputedTextLength()/2);//align center
		}
		d3.select(".layer6").append("circle").attr("id", "circlelabel3").attr("cx", 100).attr("cy", 400).attr("r", 10).attr("fill", "black").attr("fill-opacity", 0.2);
		d3.select(".layer6").append("circle").attr("id", "circlelabel3").attr("cx", 400).attr("cy", 100).attr("r", 10).attr("fill", "black").attr("fill-opacity", 0.2);
	}
	this.createGrid();
	//--------------
	
	//Blur rectangle methods
	/*
	Create blur rectangle when the application is not focused
	*/
	this.createBlurRectangle = function() {
		d3.select(".layer0").append("rect").attr("id", "blurRectangle").attr("x", 0).attr("y", 0).attr("width", this.canvasWidth).attr("height", this.canvasHeight).attr("fill", "#808080");
	};
	
	/*
	Remove blur rectangle when the application is focused
	*/
	this.removeBlurRectangle = function() {
		d3.select("#blurRectangle").attr("fill", "white").remove();
	};
	//----------------------
	
	//Selection rectangle methods
	/*
	Create a selection rectangle to select elements with mouse drag
	*/
	this.createSelectionRectangle = function(p) {
		var points = "";
		points+=p[0]+","+p[1]+" ";
		points+=p[0]+","+p[1]+" ";
		points+=p[0]+","+p[1]+" ";
		points+=p[0]+","+p[1];
		d3.select(".layer1").append("polygon").attr("class", "rect").attr("id", "selectionRectangle").attr("points", points).attr("stroke", DEFAULT_RECT_STROKE).attr("stroke-width", DEFAULT_RECT_WIDTH).attr("fill", DEFAULT_RECT_FILL);
	}
	
	/*
	Update the selection rectangle when mouse changes coords
	*/
	this.updateSelectionRectangle = function(p1, p2) {
		var points = "";
		points+=p1[0]+","+p1[1]+" ";
		points+=(p2[0])+","+p1[1]+" ";
		points+=(p2[0])+","+(p2[1])+" ";
		points+=p1[0]+","+(p2[1]);
		d3.select("#selectionRectangle").attr("points", points);
	}
	
	/*
	Delete the selection rectangle on mouseup
	*/
	this.deleteSelectionRectangle = function() {
		d3.select("#selectionRectangle").remove();
	}
	//---------------------------
	
	//Create methods
	/*
	Create circle at point p
	*/
	this.createCircle = function(p) {
		var x = p[0];
		var y = p[1];
		d3.select(".layer3").append("circle").attr("class", "circle").attr("id", "circle"+objectsCounter).attr("cx", x).attr("cy", y).attr("r", DEFAULT_CIRCLE_RADIUS).attr("fill", DEFAULT_CIRCLE_COLOR);
	};
	
	/*
	Create morphism arrow: ->
	*/
	function createMorphismArrow(p0, p1, p2) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var arrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				arrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtArrowStart = Math.realAngle([x(arrowStart), y(arrowStart)], [x(arrowStart+0.0001), y(arrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(arrowStart)+Math.degCos(b1)*l;
		var y3 = y(arrowStart)-Math.degSin(b1)*l;
		var x4 = x(arrowStart)+Math.degCos(b2)*l;
		var y4 = y(arrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+1).attr("x1", x(arrowStart)).attr("y1", y(arrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", "blue").attr("stroke-width", 4);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+2).attr("x1", x(arrowStart)).attr("y1", y(arrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", "blue").attr("stroke-width", 4);
	}
	
	/*
	Create monomorphism arrow: ->>
	*/
	function createMonomorphismArrow(p0, p1, p2) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		var secondArrowStart = firstArrowStart - 0.02;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
	}
	
	/*
	Create epimorphism arrow: >->
	*/
	function createEpimorphismArrow(p0, p1, p2) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the second circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		//Find point where the curve intersects the first circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
	}
	
	/*
	Create mono+epimorphism arrow: >->>
	*/
	function createMonoepimorphismArrow(p0, p1, p2) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the second circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		//Find point where the curve intersects the first circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var thirdArrowStart = Math.partialArcLengthFromPoint(x, y, firstArrowStart, -l*Math.degCos(a));
		var tangentAngleAtThirdArrowStart = Math.realAngle([x(thirdArrowStart), y(thirdArrowStart)], [x(thirdArrowStart+0.0001), y(thirdArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtThirdArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtThirdArrowStart-(180-a)+360)%360;
		
		var x3 = x(thirdArrowStart)+Math.degCos(b1)*l;
		var y3 = y(thirdArrowStart)-Math.degSin(b1)*l;
		var x4 = x(thirdArrowStart)+Math.degCos(b2)*l;
		var y4 = y(thirdArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+5).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+6).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
	}
	
	/*
	Create isomorphism arrow: >-\\
	*/
	function createIsomorphismArrow(p0, p1, p2) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the second circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		//Find point where the curve intersects the first circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var thirdArrowStart = Math.partialArcLengthFromPoint(x, y, firstArrowStart, -l*Math.degCos(a));
		var tangentAngleAtThirdArrowStart = Math.realAngle([x(thirdArrowStart), y(thirdArrowStart)], [x(thirdArrowStart+0.0001), y(thirdArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtThirdArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtThirdArrowStart-(180-a)+360)%360;
		
		var x4 = x(thirdArrowStart)+Math.degCos(90+b2)*l;
		var y4 = y(thirdArrowStart)-Math.degSin(90+b2)*l;
		
		d3.select(".layer2").append("line").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+6).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
	}
	
	/*
	Create bezier from circle centered at p1 with radius r1 to circle centered at p2 with radius r2
	*/
	this.createBezier = function(p1, p2, r1, r2, length) {
		var x1 = p1[0];
		var y1 = p1[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		var realAngleBetweenObjects = Math.realAngle([x1, y1], [x2, y2]);
		var w = -length * BEZIER_MULTIPLIER * Math.min(this.canvasWidth, this.canvasHeight);
		var m = [0.5 * (x1 + x2), 0.5 * (y1 + y2)];
		var b = Math.degToRad(90 + realAngleBetweenObjects);
		var l = [w * Math.cos(b), w * Math.sin(b)];
		var r = [m[0] + l[0], m[1] - l[1]];
		
		var path = "M " + x1 + " " + y1 + " Q " + r[0] + " " + r[1] + " " + x2 + " " + y2;
		var t = 0.5;
		var c = [Math.round((1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * r[0] + t * t * x2), Math.round((1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * r[1] + t * t * y2)];
		var curvePtr = d3.select(".layer2").append("path").attr("class", "curve"+" "+"curve"+morphismsCounter).attr("id", "curve"+morphismsCounter+"_"+0).attr("d", path).attr("fill", "transparent").attr("stroke-linecap", "round").attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		var handlePtr = d3.select(".layer4").append("circle").attr("class", "curvehandle").attr("id", "curvehandle"+morphismsCounter).attr("cx", c[0]).attr("cy", c[1]).attr("r", DEFAULT_HANDLE_RADIUS).attr("fill", DEFAULT_HANDLE_COLOR);
		
		var p0 = [x1, y1];
		var p1 = r;
		var p2 = [x2, y2];
		
		createMorphismArrow(p0, p1, p2);
		// createMonomorphismArrow(p0, p1, p2);
		// createEpimorphismArrow(p0, p1, p2);
		// createMonoepimorphismArrow(p0, p1, p2);
		// createIsomorphismArrow(p0, p1, p2);
		
		return {p0: p0, p1: p1, p2: p2, curve: curvePtr, handle: handlePtr};
	};
	
	/*
	Create endomorphism at point p
	*/
	this.createEndomorphism = function(object, r, angle) {
		var d = [r * Math.cos(Math.degToRad(angle)),				-r * Math.sin(Math.degToRad(angle))];
		var points = [];
		points.push(object.getPosition());
		points.push([r * Math.cos(Math.degToRad(angle + 30)),		-r * Math.sin(Math.degToRad(angle + 30))]);
		points.push([r * Math.cos(Math.degToRad(angle - 30)),		-r * Math.sin(Math.degToRad(angle - 30))]);
		points.push([r * Math.cos(Math.degToRad(angle)) / 2,		-r * Math.sin(Math.degToRad(angle)) / 2]);
		points.push([r * Math.cos(Math.degToRad(angle - 90)) / 2,	-r * Math.sin(Math.degToRad(angle - 90)) / 2]);
		points[0][0] += d[0];points[0][1] += d[1];
		for (var i = 1; i < points.length; i++) {
			points[i][0] += points[0][0];points[i][1] += points[0][1];
		}
		
		d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("id", "line"+morphismsCounter+"_"+0).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[1][0]).attr("y2", points[1][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("id", "line"+morphismsCounter+"_"+1).attr("x1", points[1][0]).attr("y1", points[1][1]).attr("x2", points[2][0]).attr("y2", points[2][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("id", "line"+morphismsCounter+"_"+2).attr("x1", points[2][0]).attr("y1", points[2][1]).attr("x2", points[0][0]).attr("y2", points[0][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		
		d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("id", "line"+morphismsCounter+"_"+3).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[3][0]).attr("y2", points[3][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		d3.select(".layer2").append("line").attr("class", "line"+" "+"line"+morphismsCounter).attr("id", "line"+morphismsCounter+"_"+4).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[4][0]).attr("y2", points[4][1]).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		//.attr("class", "class1").attr("class", "class2") will not add 2 classes
		
		var c = [Math.round((points[1][0] + points[2][0])) / 2, Math.round((points[1][1] + points[2][1])) / 2];
		var handlePtr = d3.select(".layer4").append("circle").attr("class", "curvehandle").attr("id", "curvehandle"+morphismsCounter).attr("cx", c[0]).attr("cy", c[1]).attr("r", DEFAULT_HANDLE_RADIUS).attr("fill", DEFAULT_HANDLE_COLOR);
		
		return {handle: handlePtr};
	}
	
	/*
	Create id endomorphism at point p
	*/
	this.createIdEndomorphism = function(object, r) {
		return this.createEndomorphism(object, r, 90);
	}
	
	/*
	Create circle label at point p
	*/
	this.createCircleLabel = function(p) {
		var x = p[0];
		var y = p[1];
		var text = currentObjectLabel();
		var circleLabelPtr = d3.select(".layer3").append("text").attr("class", "circlelabel").attr("id", "circlelabel"+objectsCounter).text(text).attr("x", x).attr("y", y+8).attr("font-family", DEFAULT_CIRCLE_LABEL_FONT_NAME).attr("font-size", DEFAULT_CIRCLE_LABEL_FONT_SIZE).attr("fill", DEFAULT_CIRCLE_LABEL_COLOR);
		circleLabelPtr.attr("x", circleLabelPtr.attr("x")-document.getElementById("circlelabel"+objectsCounter).getComputedTextLength()/2);//align center
	};
	
	/*
	Create bezier label
	*/
	this.createBezierLabel = function(handle) {
		var x = handle.attr("cx");
		var y = handle.attr("cy");
		var text = currentMorphismLabel();
		var curveLabelPtr = d3.select(".layer4").append("text").attr("class", "curvelabel").attr("id", "curvelabel" + morphismsCounter).text(text).attr("x", x).attr("y", y).attr("font-family", DEFAULT_CURVE_LABEL_FONT_NAME).attr("font-size", DEFAULT_CURVE_LABEL_FONT_SIZE).attr("fill", DEFAULT_CURVE_LABEL_COLOR);
		curveLabelPtr.attr("x", curveLabelPtr.attr("x") - document.getElementById("curvelabel" + morphismsCounter).getComputedTextLength()/2);//align center
		curveLabelPtr.attr("y", Number(curveLabelPtr.attr("y")) + document.getElementById("curvelabel" + morphismsCounter).getBBox().height/4);//align center
	};
	
	/*
	Create endomorphism label
	*/
	this.createEndomorphismLabel = function(handle, r, angle) {
		var x = handle.attr("cx");
		var y = handle.attr("cy");
		var text = currentMorphismLabel();
		var endomorphismLabelptr = d3.select(".layer4").append("text").attr("class", "linelabel").attr("id", "linelabel" + morphismsCounter).text(text).attr("x", x).attr("y", y).attr("font-family", DEFAULT_ENDOMORPHISM_LABEL_FONT_NAME).attr("font-size", DEFAULT_ENDOMORPHISM_LABEL_FONT_SIZE).attr("fill", DEFAULT_ENDOMORPHISM_LABEL_COLOR);
		endomorphismLabelptr.attr("x", endomorphismLabelptr.attr("x") - document.getElementById("linelabel" + morphismsCounter).getComputedTextLength()/2);//align center
		endomorphismLabelptr.attr("y", Number(endomorphismLabelptr.attr("y")) + document.getElementById("linelabel" + morphismsCounter).getBBox().height/4);//align center
	}
	
	/*
	Create id endomorphism label
	*/
	this.createIdEndomorphismLabel = function(handle, r) {
		var x = handle.attr("cx");
		var y = handle.attr("cy");
		var text = "id"+objects.last().getLabel();
		var endomorphismLabelptr = d3.select(".layer4").append("text").attr("class", "linelabel").attr("id", "linelabel" + morphismsCounter).text(text).attr("x", x).attr("y", y).attr("font-family", DEFAULT_ENDOMORPHISM_LABEL_FONT_NAME).attr("font-size", DEFAULT_ENDOMORPHISM_LABEL_FONT_SIZE).attr("fill", DEFAULT_ENDOMORPHISM_LABEL_COLOR);
		endomorphismLabelptr.attr("x", endomorphismLabelptr.attr("x") - document.getElementById("linelabel" + morphismsCounter).getComputedTextLength()/2);//align center
		endomorphismLabelptr.attr("y", Number(endomorphismLabelptr.attr("y")) + document.getElementById("linelabel" + morphismsCounter).getBBox().height/4);//align center
	}
	//--------------
	
	//Update methods
	/*
	Update circle
	*/
	this.updateCircle = function(object, p) {
		var id = object.getId();
		var x = p[0];
		var y = p[1];
		object.setX(x);
		object.setY(y);
		d3.select("#circle"+id).attr("cx", x).attr("cy", y);
	}
	
	/*
	Update morphism arrow: ->
	*/
	function updateMorphismArrow(p0, p1, p2, id) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var arrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				arrowStart = i/n;
				break;
			}
		}
		var tangentAngleAtArrowStart = Math.realAngle([x(arrowStart), y(arrowStart)], [x(arrowStart+0.0001), y(arrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(arrowStart)+Math.degCos(b1)*l;
		var y3 = y(arrowStart)-Math.degSin(b1)*l;
		var x4 = x(arrowStart)+Math.degCos(b2)*l;
		var y4 = y(arrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+1).attr("x1", x(arrowStart)).attr("y1", y(arrowStart)).attr("x2", x3).attr("y2", y3);
		d3.select("#curve"+id+"_"+2).attr("x1", x(arrowStart)).attr("y1", y(arrowStart)).attr("x2", x4).attr("y2", y4);
	}
	
	/*
	Update monomorphism arrow: ->>
	*/
	function updateMonomorphismArrow(p0, p1, p2, id) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		
		var l = ARROW_HEAD_LENGTH;
		
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		var secondArrowStart = firstArrowStart - 0.02;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		var l = ARROW_HEAD_LENGTH;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
	}
	
	/*
	Update epimorphism arrow: >->
	*/
	function updateEpimorphismArrow(p0, p1, p2, id) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		
		var l = ARROW_HEAD_LENGTH;
		
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
	}
	
	/*
	Update mono+epimorphism arrow: >->>
	*/
	function updateMonoepimorphismArrow(p0, p1, p2, id) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		
		var l = ARROW_HEAD_LENGTH;
		
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		var x4 = x(firstArrowStart)+Math.degCos(b2)*l;
		var y4 = y(firstArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+2).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var thirdArrowStart = Math.partialArcLengthFromPoint(x, y, firstArrowStart, -l*Math.degCos(a));
		var tangentAngleAtThirdArrowStart = Math.realAngle([x(thirdArrowStart), y(thirdArrowStart)], [x(thirdArrowStart+0.0001), y(thirdArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtThirdArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtThirdArrowStart-(180-a)+360)%360;
		
		var x3 = x(thirdArrowStart)+Math.degCos(b1)*l;
		var y3 = y(thirdArrowStart)-Math.degSin(b1)*l;
		var x4 = x(thirdArrowStart)+Math.degCos(b2)*l;
		var y4 = y(thirdArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+5).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+6).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
	}
	
	/*
	Update isomorphism arrow: >-\\
	*/
	function updateIsomorphismArrow(p0, p1, p2, id) {
		var x1 = p0[0];
		var y1 = p0[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		function x(u) {return (1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];}
		function y(u) {return (1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];}
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var firstArrowStart = null;
		for (var i = n-1; i >= 0; i--) {
			var ra = Math.realAngle([x(i/n), y(i/n)], [x(1), y(1)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(1) - DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(1) + DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				firstArrowStart = i/n;
				break;
			}
		}
		
		var l = ARROW_HEAD_LENGTH;
		
		var tangentAngleAtFirstArrowStart = Math.realAngle([x(firstArrowStart), y(firstArrowStart)], [x(firstArrowStart+0.0001), y(firstArrowStart+0.0001)]);
		
		var a = ARROW_HEAD_ANGLE;
		var b1 = (tangentAngleAtFirstArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtFirstArrowStart-(180-a)+360)%360;
		
		var x3 = x(firstArrowStart)+Math.degCos(b1)*l;
		var y3 = y(firstArrowStart)-Math.degSin(b1)*l;
		
		d3.select("#curve"+id+"_"+1).attr("x1", x(firstArrowStart)).attr("y1", y(firstArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		//Find point where the curve intersects the circle
		var n = BEZIER_POINTS;
		var prec = BEZIER_PRECISION;
		var secondArrowStart = null;
		for (var i = 0; i < n; i++) {
			var ra = Math.realAngle([x(0), y(0)], [x(i/n), y(i/n)]);
			//p is the point of the circle with angle atan(m)
			var p = {x: x(0) + DEFAULT_CIRCLE_RADIUS * Math.degCos(ra), y: y(0) - DEFAULT_CIRCLE_RADIUS * Math.degSin(ra)};
			//q is the point in the curve
			var q = {x: x(i/n), y: y(i/n)};
			//if p and q are close enough:
			if ((p.x-prec <= q.x && p.x+prec >= q.x) && (p.y-prec <= q.y && p.y+prec >= q.y)) {
				secondArrowStart = i/n;
				break;
			}
		}
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var point = Math.partialArcLengthFromPoint(x, y, secondArrowStart, l*Math.degCos(a));
		secondArrowStart = point;
		var tangentAngleAtSecondArrowStart = Math.realAngle([x(secondArrowStart), y(secondArrowStart)], [x(secondArrowStart+0.0001), y(secondArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtSecondArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtSecondArrowStart-(180-a)+360)%360;
		
		var x3 = x(secondArrowStart)+Math.degCos(b1)*l;
		var y3 = y(secondArrowStart)-Math.degSin(b1)*l;
		var x4 = x(secondArrowStart)+Math.degCos(b2)*l;
		var y4 = y(secondArrowStart)-Math.degSin(b2)*l;
		
		d3.select("#curve"+id+"_"+3).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x3).attr("y2", y3).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		d3.select("#curve"+id+"_"+4).attr("x1", x(secondArrowStart)).attr("y1", y(secondArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
		
		var a = ARROW_HEAD_ANGLE;
		var l = ARROW_HEAD_LENGTH;
		var thirdArrowStart = Math.partialArcLengthFromPoint(x, y, firstArrowStart, -l*Math.degCos(a));
		var tangentAngleAtThirdArrowStart = Math.realAngle([x(thirdArrowStart), y(thirdArrowStart)], [x(thirdArrowStart+0.0001), y(thirdArrowStart+0.0001)]);
		
		var b1 = (tangentAngleAtThirdArrowStart+(180-a)+360)%360;
		var b2 = (tangentAngleAtThirdArrowStart-(180-a)+360)%360;
		
		var x4 = x(thirdArrowStart)+Math.degCos(90+b2)*l;
		var y4 = y(thirdArrowStart)-Math.degSin(90+b2)*l;
		
		d3.select("#curve"+id+"_"+6).attr("x1", x(thirdArrowStart)).attr("y1", y(thirdArrowStart)).attr("x2", x4).attr("y2", y4).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
	}
	
	/*
	Update bezier
	*/
	this.updateBezier = function(morphism, p) {
		var id = morphism.getId();
		var source = getObjectById(morphism.getSource());
		var target = getObjectById(morphism.getTarget());
		var p1 = source.getPosition();
		var p2 = target.getPosition();
		var r1 = source.getRadius();
		var r2 = target.getRadius();
		var x1 = p1[0];
		var y1 = p1[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		var realAngleBetweenObjects = Math.realAngle([x1, y1], [x2, y2]);
		var m = [0.5 * (x1 + x2), 0.5 * (y1 + y2)];
		var r = [m[0] + 2 * (p[0] - m[0]), m[1] + 2 * (p[1] - m[1])];
		
		var path = "M " + x1 + " " + y1 + " Q " + r[0] + " " + r[1] + " " + x2 + " " + y2;
		var t = 0.5;
		var c = [(1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * r[0] + t * t * x2, (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * r[1] + t * t * y2];
		var curvePtr = d3.select(".curve"+id).attr("d", path);
		var handlePtr = d3.select("#curvehandle"+id).attr("cx", c[0]).attr("cy", c[1]);
		
		var p0 = [x1, y1];
		var p1 = r;
		var p2 = [x2, y2];
		
		updateMorphismArrow(p0, p1, p2, id);
		// updateMonomorphismArrow(p0, p1, p2, id);
		// updateEpimorphismArrow(p0, p1, p2, id);
		// updateMonoepimorphismArrow(p0, p1, p2, id);
		// updateIsomorphismArrow(p0, p1, p2, id);
		
		return {p0: [x1, y1], p1: r, p2: [x2, y2], curve: curvePtr, handle: handlePtr};
	}
	
	/*
	Update endomorphism
	*/
	this.updateEndomorphism = function(morphism, p) {
		var id = morphism.getId();
		var object = getObjectById(morphism.getSource());
		
		var ra = Math.realAngle(object.getPosition(), p);
		var r = Math.distance(object.getPosition(), [Number(morphism.getHandle().attr("cx")), Number(morphism.getHandle().attr("cy"))]);
		var x = object.getX() + r * Math.degCos(ra);
		var y = object.getY() - r * Math.degSin(ra);
		var handlePtr = d3.select("#curvehandle" + id).attr("cx", x).attr("cy", y);
		
		var r = object.getRadius();
		var angle = ra;
		var d = [r * Math.cos(Math.degToRad(angle)),				-r * Math.sin(Math.degToRad(angle))];
		var points = [];
		points.push(object.getPosition());
		points.push([r * Math.cos(Math.degToRad(angle + 30)),		-r * Math.sin(Math.degToRad(angle + 30))]);
		points.push([r * Math.cos(Math.degToRad(angle - 30)),		-r * Math.sin(Math.degToRad(angle - 30))]);
		points.push([r * Math.cos(Math.degToRad(angle)) / 2,		-r * Math.sin(Math.degToRad(angle)) / 2]);
		points.push([r * Math.cos(Math.degToRad(angle - 90)) / 2,	-r * Math.sin(Math.degToRad(angle - 90)) / 2]);
		points[0][0] += d[0];points[0][1] += d[1];
		for (var i = 1; i < points.length; i++) {
			points[i][0] += points[0][0];points[i][1] += points[0][1];
		}
		
		d3.select("#line" + id + "_" + 0).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[1][0]).attr("y2", points[1][1]);
		d3.select("#line" + id + "_" + 1).attr("x1", points[1][0]).attr("y1", points[1][1]).attr("x2", points[2][0]).attr("y2", points[2][1]);
		d3.select("#line" + id + "_" + 2).attr("x1", points[2][0]).attr("y1", points[2][1]).attr("x2", points[0][0]).attr("y2", points[0][1]);
		
		d3.select("#line" + id + "_" + 3).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[3][0]).attr("y2", points[3][1]);
		d3.select("#line" + id + "_" + 4).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[4][0]).attr("y2", points[4][1]);
		//.attr("class", "class1").attr("class", "class2") will not add 2 classes
		
		return {handle: handlePtr};
	}
	
	/*
	Update id endomorphism
	*/
	this.updateIdEndomorphism = function(morphism, p, r) {
		this.updateEndomorphism(morphism, p, r, 90);
	}
	
	/*
	Translate endomorphism
	*/
	this.translateEndomorphism = function(morphism, delta) {
		var id = morphism.getId();
		
		var points = [];
		points.push([Number(d3.select("#line" + id + "_" + 0).attr("x1")) + delta[0], Number(d3.select("#line" + id + "_" + 0).attr("y1")) + delta[1]]);
		points.push([Number(d3.select("#line" + id + "_" + 1).attr("x1")) + delta[0], Number(d3.select("#line" + id + "_" + 1).attr("y1")) + delta[1]]);
		points.push([Number(d3.select("#line" + id + "_" + 2).attr("x1")) + delta[0], Number(d3.select("#line" + id + "_" + 2).attr("y1")) + delta[1]]);
		points.push([Number(d3.select("#line" + id + "_" + 3).attr("x2")) + delta[0], Number(d3.select("#line" + id + "_" + 3).attr("y2")) + delta[1]]);
		points.push([Number(d3.select("#line" + id + "_" + 4).attr("x2")) + delta[0], Number(d3.select("#line" + id + "_" + 4).attr("y2")) + delta[1]]);
		
		d3.select("#line" + id + "_" + 0).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[1][0]).attr("y2", points[1][1]);
		d3.select("#line" + id + "_" + 1).attr("x1", points[1][0]).attr("y1", points[1][1]).attr("x2", points[2][0]).attr("y2", points[2][1]);
		d3.select("#line" + id + "_" + 2).attr("x1", points[2][0]).attr("y1", points[2][1]).attr("x2", points[0][0]).attr("y2", points[0][1]);
		
		d3.select("#line" + id + "_" + 3).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[3][0]).attr("y2", points[3][1]);
		d3.select("#line" + id + "_" + 4).attr("x1", points[0][0]).attr("y1", points[0][1]).attr("x2", points[4][0]).attr("y2", points[4][1]);
		//.attr("class", "class1").attr("class", "class2") will not add 2 classes
		
		var x = Number(d3.select("#curvehandle"+id).attr("cx")) + delta[0];
		var y = Number(d3.select("#curvehandle"+id).attr("cy")) + delta[1];
		var handlePtr = d3.select("#curvehandle" + id).attr("cx", x).attr("cy", y);
		
		return {handle: handlePtr};
	}
	
	/*
	Update circle label
	*/
	this.updateCircleLabel = function(object, p) {
		var id = object.getId();
		var x = p[0];
		var y = p[1];
		object.setX(x);
		object.setY(y);
		var circleLabelPtr = d3.select("#circlelabel"+id).attr("x", x).attr("y", y+8);
		circleLabelPtr.attr("x", circleLabelPtr.attr("x")-document.getElementById("circlelabel"+id).getComputedTextLength()/2);//align center
	}
	/*
	Update bezier label
	*/
	this.updateBezierLabel = function(morphism, p) {
		var id = morphism.getId();
		var source = getObjectById(morphism.getSource());
		var target = getObjectById(morphism.getTarget());
		var p1 = source.getPosition();
		var p2 = target.getPosition();
		var r1 = source.getRadius();
		var r2 = target.getRadius();
		var x1 = p1[0];
		var y1 = p1[1];
		var x2 = p2[0];
		var y2 = p2[1];
		
		var m = ((y2-y1)/(x2-x1));
		var realCosSign1 = null;var realSinSign1 = null;var realCosSign2 = null;var realSinSign2 = null;
		var realAngleBetweenObjects = Math.realAngle([x1, y1], [x2, y2]);
		if(realAngleBetweenObjects === 0)										{realCosSign1 = 1;realSinSign1 = 0;realCosSign2 = -1;realSinSign2 = 0;}
		else if(realAngleBetweenObjects >   0 && realAngleBetweenObjects <  90)	{realCosSign1 = 1;realSinSign1 = 1;realCosSign2 = -1;realSinSign2 = -1;}
		else if(realAngleBetweenObjects === 90)									{realCosSign1 = 0;realSinSign1 = 1;realCosSign2 = 0;realSinSign2 = -1;}
		else if(realAngleBetweenObjects >  90 && realAngleBetweenObjects < 180)	{realCosSign1 = -1;realSinSign1 = -1;realCosSign2 = 1;realSinSign2 = 1;}
		else if(realAngleBetweenObjects === 180)									{realCosSign1 = -1;realSinSign1 = 0;realCosSign2 = 1;realSinSign2 = 0;}
		else if(realAngleBetweenObjects > 180 && realAngleBetweenObjects < 270)	{realCosSign1 = -1;realSinSign1 = -1;realCosSign2 = 1;realSinSign2 = 1;}
		else if(realAngleBetweenObjects === 270)									{realCosSign1 = 0;realSinSign1 = 1;realCosSign2 = 0;realSinSign2 = -1;}
		else if(realAngleBetweenObjects > 270 && realAngleBetweenObjects < 360)	{realCosSign1 = 1;realSinSign1 = 1;realCosSign2 = -1;realSinSign2 = -1;}
		
		var m = [0.5 * (x1 + x2), 0.5 * (y1 + y2)];
		var r = [m[0] + 2 * (p[0] - m[0]), m[1] + 2 * (p[1] - m[1])];
		var t = 0.5;
		var c = [(1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * r[0] + t * t * x2, (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * r[1] + t * t * y2];
		d3.select("#curvelabel"+id).attr("x", c[0]-4).attr("y", c[1]+4);
	}
	
	/*
	Update endomorphism label
	*/
	this.updateEndomorphismLabel = function(morphism, p) {
		var id = morphism.getId();
		var object = getObjectById(morphism.getSource());
		var ra = Math.realAngle(object.getPosition(), p);
		var r = Math.distance(object.getPosition(), [Number(morphism.getHandle().attr("cx")), Number(morphism.getHandle().attr("cy"))]);
		var x = object.getX() + r * Math.degCos(ra);
		var y = object.getY() - r * Math.degSin(ra);
		var endomorphismLabelptr = d3.select("#linelabel" + id).attr("x", x).attr("y", y);
		endomorphismLabelptr.attr("x", endomorphismLabelptr.attr("x") - document.getElementById("linelabel" + id).getComputedTextLength()/2);//align center
		endomorphismLabelptr.attr("y", Number(endomorphismLabelptr.attr("y")) + document.getElementById("linelabel" + id).getBBox().height/4);//align center
	}
	
	/*
	Update id endomorphism label
	*/
	this.updateIdEndomorphismLabel = function(morphism, p, r) {
		var id = morphism.getId();
		var x = p[0];
		var y = p[1];
		var angle = Math.realAngle(p, [morphism.getHandle().attr("x"), morphism.getHandle().attr("x")]);
		var endomorphismLabelptr = d3.select("#linelabel" + id).attr("x", x + r * Math.cos(Math.degToRad(90 + angle))).attr("y", y - 2 * r * Math.sin(Math.degToRad(90 + angle)));
		endomorphismLabelptr.attr("x", endomorphismLabelptr.attr("x") - document.getElementById("linelabel" + id).getComputedTextLength()/2);//align center
		endomorphismLabelptr.attr("y", Number(endomorphismLabelptr.attr("y")) + document.getElementById("linelabel" + id).getBBox().height/4);//align center
	}
	
	/*
	Translate endomorphism's label by delta
	*/
	this.translateEndomorphismLabel = function(morphism, delta) {
		var id = morphism.getId();
		var x = Number(morphism.getHandlePosition()[0]) + delta[0];
		var y = Number(morphism.getHandlePosition()[1]) + delta[1];
		console.log("pos "+Number(morphism.getHandlePosition()[0])+" "+Number(morphism.getHandlePosition()[1])+" delta "+delta[0]+" "+delta[1]+" res "+x+" "+y);
		var endomorphismLabelptr = d3.select("#linelabel" + id).attr("x", x).attr("y", y);
		endomorphismLabelptr.attr("x", endomorphismLabelptr.attr("x") - document.getElementById("linelabel" + id).getComputedTextLength()/2);//align center
		endomorphismLabelptr.attr("y", Number(endomorphismLabelptr.attr("y")) + document.getElementById("linelabel" + id).getBBox().height/4);//align center
	}
	//--------------
	
	//Select methods
	/*
	Select circle
	*/
	this.selectCircle = function(object) {
		var id = object.getId();
		d3.select("#circlelabel" + id).attr("font-family", SELECTED_CIRCLE_LABEL_FONT_NAME).attr("font-size", SELECTED_CIRCLE_LABEL_FONT_SIZE).attr("fill", SELECTED_CIRCLE_LABEL_COLOR);
		d3.select("#circle" + id).attr("r", SELECTED_CIRCLE_RADIUS).attr("fill", SELECTED_CIRCLE_COLOR);
		var idEndomorphismId = object.getEndomorphisms()[0].getId();
		d3.select("#linelabel" + idEndomorphismId).attr("fill", SELECTED_ENDOMORPHISM_LABEL_COLOR);
		d3.selectAll(".line" + idEndomorphismId).attr("stroke", SELECTED_ENDOMORPHISM_COLOR);
		d3.select("#curvehandle" + idEndomorphismId).attr("r", SELECTED_HANDLE_RADIUS).attr("fill", SELECTED_HANDLE_COLOR);
	};
	
	/*
	Select bezier
	*/
	this.selectBezier = function(morphism) {
		var id = morphism.getId();
		d3.select("#curvelabel" + id).attr("font-family", SELECTED_CURVE_LABEL_FONT_NAME).attr("font-size", SELECTED_CURVE_LABEL_FONT_SIZE).attr("fill", SELECTED_CURVE_LABEL_COLOR);
		d3.select("#curvehandle" + id).attr("r", SELECTED_HANDLE_RADIUS).attr("fill", SELECTED_HANDLE_COLOR);
		d3.selectAll(".curve" + id).attr("stroke", SELECTED_LINE_COLOR).attr("stroke-width", SELECTED_LINE_WIDTH);
	};
	
	/*
	Select endomorphism
	*/
	this.selectEndomorphism = function(morphism) {
		var id = morphism.getId();
		d3.selectAll(".line" + id).attr("stroke", SELECTED_ENDOMORPHISM_COLOR).attr("stroke-width", SELECTED_ENDOMORPHISM_WIDTH);
		d3.select("#linelabel" + id).attr("font-family", SELECTED_ENDOMORPHISM_LABEL_FONT_NAME).attr("font-size", SELECTED_ENDOMORPHISM_LABEL_FONT_SIZE).attr("fill", SELECTED_ENDOMORPHISM_LABEL_COLOR);
		d3.select("#curvehandle" + id).attr("r", SELECTED_HANDLE_RADIUS).attr("fill", SELECTED_HANDLE_COLOR);
	}
	
	// selectIdEndomorphism
	//--------------
	
	//Deselect methods
	/*
	Deselect circle
	*/
	this.deselectCircle = function(object) {
		var id = object.getId();
		d3.select("#circlelabel" + id).attr("fill", DEFAULT_CIRCLE_LABEL_COLOR);
		d3.select("#circle" + id).attr("fill", DEFAULT_CIRCLE_COLOR);
		var idEndomorphismId = object.getEndomorphisms()[0].getId();
		d3.select("#linelabel" + idEndomorphismId).attr("fill", DEFAULT_ENDOMORPHISM_LABEL_COLOR);
		d3.selectAll(".line" + idEndomorphismId).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR);
		d3.select("#curvehandle" + idEndomorphismId).attr("r", DEFAULT_HANDLE_RADIUS).attr("fill", DEFAULT_HANDLE_COLOR);
	};
	
	/*
	Deselect bezier
	*/
	this.deselectBezier = function(morphism) {
		var id = morphism.getId();
		d3.select("#curvelabel" + id).attr("fill", DEFAULT_CURVE_LABEL_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
		d3.select("#curvehandle" + id).attr("r", DEFAULT_HANDLE_RADIUS).attr("fill", DEFAULT_HANDLE_COLOR);
		d3.selectAll(".curve" + id).attr("stroke", DEFAULT_LINE_COLOR).attr("stroke-width", DEFAULT_LINE_WIDTH);
	};
	
	/*
	Deselect endomorphism
	*/
	this.deselectEndomorphism = function(morphism) {
		var id = morphism.getId();
		d3.selectAll(".line" + id).attr("stroke", DEFAULT_ENDOMORPHISM_COLOR).attr("stroke-width", DEFAULT_ENDOMORPHISM_WIDTH);
		d3.select("#curvehandle" + id).attr("r", DEFAULT_HANDLE_RADIUS).attr("fill", DEFAULT_HANDLE_COLOR);
	}
	
	// deselectIdEndomorphism
	//----------------
	
	//Delete methods
	/*
	Delete circle
	*/
	this.deleteCircle = function(id) {
		d3.select("#circle" + id).remove();
	}
	
	/*
	Delete circle label
	*/
	this.deleteCircleLabel = function(id) {
		d3.select("#circlelabel" + id).remove();
	}
	
	/*
	Delete endomorphism
	*/
	this.deleteEndomorphism = function(id) {
		d3.selectAll(".line" + id).remove();
		d3.selectAll("#curvehandle" + id).remove();
	}
	
	/*
	Delete endomorphism label
	*/
	this.deleteEndomorphismLabel = function(id) {
		d3.select("#linelabel" + id).remove();
	}
	//--------------
	
	//Hide methods
	/*
	Hide circle
	*/
	this.hideCircle = function(object) {
		var circleId = object.getId();
		d3.select("#circlelabel" + circleId).style("visibility", "hidden");
		d3.select("#circle" + circleId).style("visibility", "hidden");
		var idEndomorphismId = object.getEndomorphisms()[0].getId();
		d3.select("#linelabel" + idEndomorphismId).style("visibility", "hidden");
		d3.selectAll(".line" + idEndomorphismId).style("visibility", "hidden");
	};
	/*
	hide bezier
	*/
	this.hideBezier = function(morphism) {
		var bezierId = morphism.getId();
		d3.select("#curvelabel" + bezierId).style("visibility", "hidden");
		d3.select("#curvehandle" + bezierId).style("visibility", "hidden");
		d3.selectAll(".curve" + bezierId).style("visibility", "hidden");
	};
	// hideEndomorphism
	// // hideIdEndomorphism	console.log("Não pode")
	//------------
	
	//Show methods
	/*
	Show circle
	*/
	this.showCircle = function(object) {
		var circleId = object.getId();
		d3.select("#circlelabel" + circleId).style("visibility", "visible");
		d3.select("#circle" + circleId).style("visibility", "visible");
		var idEndomorphismId = object.getEndomorphisms()[0].getId();
		d3.select("#linelabel" + idEndomorphismId).style("visibility", "visible");
		d3.selectAll(".line" + idEndomorphismId).style("visibility", "visible");
	};
	/*
	show bezier
	*/
	this.showBezier = function(morphism) {
		var bezierId = morphism.getId();
		d3.select("#curvelabel" + bezierId).style("visibility", "visible");
		d3.select("#curvehandle" + bezierId).style("visibility", "visible");
		d3.selectAll(".curve" + bezierId).style("visibility", "visible");
	};
	// showEndomorphism
	// // showIdEndomorphism	console.log("Não pode")
	//------------
	
	//Auxiliary methods
	this.removeHiddenElements = function() {
		for (var i = 0; i < hiddenElements.length; i++) {
			if (hiddenElements[i].type === "object") {
				var objectId = hiddenElements[i].element.getId();
				removeObjectById(objectId);
				removeObjectLabelById(objectId);
			} else if (hiddenElements[i].type === "morphism") {
				var morphismId = hiddenElements[i].element.getId();
				removeMorphismById(morphismId);
				removeMorphismLabelById(morphismId);
			} else if (hiddenElements[i].type === "endomorphism") {
				var endomorphismId = hiddenElements[i].element.getId();
				removeMorphismById(endomorphismId);
				removeMorphismLabelById(endomorphismId);
			}
		}
		hiddenElements = [];
	}
	
	/*
	Check if circle is fully inside area between p1 and p2
	*/
	function isCircleFullyInsideArea(x, y, r, p1, p2) {
		return ((x - r) >= Math.min(p1[0], p2[0]) && (x + r) <= Math.max(p1[0], p2[0]) && (y - r) >= Math.min(p1[1], p2[1]) && (y + r) <= Math.max(p1[1], p2[1]));
	}
	
	/*
	Get a list of all circles fully inside area between p1 and p2
	*/
	this.getAllCirclesFullyInsideArea = function(p1, p2) {
		var list = [];
		d3.selectAll(".circle").each(function(d, i) {
			var el = d3.select(this);
			var cx = Number(el.attr("cx"));
			var cy = Number(el.attr("cy"));
			var r = Number(el.attr("r"));
			if (isCircleFullyInsideArea(cx, cy, r, p1, p2)) {
				list.push(el);
			}
		})
		return list;
	};
	
	/*
	Get a list of all bezier handles fully inside area between p1 and p2
	*/
	this.getAllBezierHandlesFullyInsideArea = function(p1, p2) {
		var list = [];
		d3.selectAll(".curvehandle").each(function(d, i) {
			var el = d3.select(this);
			var cx = Number(el.attr("cx"));
			var cy = Number(el.attr("cy"));
			var r = Number(el.attr("r"));
			if (isCircleFullyInsideArea(cx, cy, r, p1, p2)) {
				list.push(el);
			}
		})
		return list;
	};
	//-----------------
}