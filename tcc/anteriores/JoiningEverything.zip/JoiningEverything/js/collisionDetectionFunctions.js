//Check if a point (x,y) is inside a node (circle) with center coordinates (cx,cy) and radius r
function pointInsideANode(x, y, cx, cy, r) {
	var distancesquared = (x - cx) * (x - cx) + (y - cy) * (y - cy);
	return distancesquared <= r * r;
}

//Check if a point (x,y) is inside any node (circle) in nodes array
function pointInsideAnyNode(x, y) {
	for(var i = 0; i < nodes.length; i++) {
		if(pointInCircle(x, y, nodes[i][0], nodes[i][1], nodes[i][2])) {
			return i;
		}
	}
	return -1;
}