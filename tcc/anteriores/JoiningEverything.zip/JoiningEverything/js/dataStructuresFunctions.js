//Print Nodes and Edges Arrays fields
function printNodes() {
	var output = "";
	for (var i = 0; i < nodes.length; i++) {
		output = output+"["+"id"+" : "+nodes[i][0]+" "+"label"+" : "+nodes[i][1]+" "+"x"+" : "+" "+nodes[i][2]+" "+"y"+" : "+" "+nodes[i][3]+" "+"radius"+" : "+" "+nodes[i][4]+" "+"fill"+" : "+" "+nodes[i][5]+"]"+"\n";
	}
	return output;
}
		
function printEdges() {
	var output = "";
	for (var i = 0; i < edges.length; i++) {
		output = output+"["+"id"+" : "+edges[i][0]+" "+"label"+" : "+edges[i][1]+" "+"selected"+" : "+" "+edges[i][2]+" "+"source"+" : "+" "+edges[i][3]+" "+"target"+" : "+" "+edges[i][4]+" "+"width"+" : "+" "+edges[i][5]+" "+"stroke_width"+" : "+" "+edges[i][6]+"]"+"\n";
	}
	return output;
}