var nodes = [];
var edges = [];

//Returns first null position in an array or its length
function firstEmpty(arr) {
	if(arr.length == 0) {
		return 0;
	} else {
		for(var i=0; i<arr.length; i++) {
			if(arr[i] == null) {
				return i;
			}
		}
		return arr.length;
	}
}
//-------------------------------------------------------------------------------------------------------------------

//Source: https://www.youtube.com/watch?v=8jvoTV54nXw
//Canvas functions----------------------------------------------------------------------------------------------------
//Add a canvas (svg) to the document
function addCanvas(width, height) {
	var output = d3.select("body").append("svg").attr("width", width).attr("height", height);
	return output;
}
//-------------------------------------------------------------------------------------------------------------------

//Circle functions----------------------------------------------------------------------------------------------------
//Add a node to a canvas
function addNode(canvas, x, y, radius, fill) {
	var label = prompt("Node label");
	if (label != null) {
		canvas.append("circle").attr("id", first_empty(nodes)).attr("cx", x).attr("cy", y).attr("r", radius).attr("fill", fill);
		nodes.push([id, label, x, y, radius, fill]);
	}
}
//-------------------------------------------------------------------------------------------------------------------

//Line functions----------------------------------------------------------------------------------------------------
//Add an edge to a canvas
function addLine(canvas, x1, y1, x2, y2, stroke, stroke_width) {
	var label = prompt("Edge label");
	if (label != null) {
		var selected = false;
		var source = null;
		var target = null;
		canvas.append("line").attr("id", firstEmpty(edges)).attr("x1", source.cx).attr("y1", source.cy).attr("x2", target.cx).attr("y2", target.cy).attr("stroke", stroke).attr("stroke-width", stroke_width);
		edges.push([id, label, selected, source, target, width, stroke_width]);
	}
}
//-------------------------------------------------------------------------------------------------------------------

//Rect functions----------------------------------------------------------------------------------------------------
//Add a rectangle to a canvas
function addRect(canvas, width, height) {
	var output = canvas.append("rect").attr("id", "rect1").attr("width", width).attr("height", height);
	return output;
}
//-------------------------------------------------------------------------------------------------------------------

//Label functions
//Add a label to a canvas
function addLabel(canvas, text, x, y, font_size) {
	var newText = document.createElementNS(svgNS, "text");
	newText.setAttributeNS(null, "x", x);     
	newText.setAttributeNS(null, "y", y); 
	newText.setAttributeNS(null, "font-size", "100");
}

//Add a label to a node
function addLabel(nodeId, text, font_size) {
	var node = getNodeById(nodeId);
	var newText = document.createElementNS(svgNS, "text");
	newText.setAttributeNS(null, "x", node.cx);     
	newText.setAttributeNS(null, "y", node.cy); 
	newText.setAttributeNS(null, "font-size", "100");
}

//Add a label to an edge
function addLabel(edgeId, text, font_size) {
	var edge = getEdgeById(edgeId);
	var newText = document.createElementNS(svgNS, "text");
	newText.setAttributeNS(null, "x", x);     
	newText.setAttributeNS(null, "y", y); 
	newText.setAttributeNS(null, "font-size", "100");
	//newText.setAttributeNS(null, "transform", "rotate(45 45 45)");
}
//-------------------------------------------------------------------------------------------------------------------

//Removal functions
function removeElement(id) {
	d3.select("#"+id).remove();
}
//-------------------------------------------------------------------------------------------------------------------

//Graph drawing functions
function drawExampleGraph(canvas) {
	add_line(canvas, "50", "50", "250", "50", "yellow", "1");
	add_line(canvas, "250", "50", "450", "50", "yellow", "1");

	add_circle(canvas, "50", "50", "5", "red");
	add_circle(canvas, "250", "50", "5", "green");
	add_circle(canvas, "450", "50", "5", "blue");
}
//-------------------------------------------------------------------------------------------------------------------

//On-click-and-detect node/edge add/removal
//Code based on: http://stackoverflow.com/questions/16792841/detect-if-user-clicks-inside-a-circle
$(document).ready(function() {
	var svg = d3.select('svg');

	function getRandom(min, max) {
		return Math.floor(Math.random() * (max - min) + min);
	}
    
	function drawCircle(x, y, size) {
		svg.append("circle").attr('class', 'click-circle').attr("cx", x).attr("cy", y).attr("r", size).attr("fill", "red");
	}
        
	// x,y is the point to test
	// cx, cy is circle center, and radius is circle radius
	function pointInCircle(x, y, cx, cy, radius) {
		var distancesquared = (x - cx) * (x - cx) + (y - cy) * (y - cy);
		return distancesquared <= radius * radius;
	}

	function pointInSomeCircle() {
		for (var i = 0; i < nodes.length; i++) {
			if(pointOnCircle(coords[0], coords[1], nodes[i].cx, nodes[i].cy, nodes[i].r)) {
				return i;
			}
		}
		return -1;
	}

	function pointInLine(x, y, x1, y1, x2, y2, stroke_width) {
		return ((x >= x1 && x <= x2) && (y >= (y - stroke_width) && y <= (y+stroke_width)));
	}

	function pointInSomeLine() {
		for (var i = 0; i < edges.length; i++) {
			if(pointInLine(coords[0], coords[1], edges[i].x1, edges[i].y1, edges[i].x2, edges[i].y2, edges[i].stroke_width)) {
				return i;
			}
		}
		return -1;
	}
    
	svg.on('click', function() {
		var coords = d3.mouse(this);
		//alert(coords);
		var res1 = -1;//pointInSomeCircle();
		var res2 = -1;//pointInSomeLine();
		if(res1 == -1 && res2 == -1) {
		//	if(release != press) {
		//		add_line(canvas, x1, y1, x2, y2, stroke, stroke_width);
		//	} else {
				add_circle(canvas, coords[0], coords[1], "5", "red");
		//	}
		} else {
		//	if(res1 != -1) {
		//		remove("n0");
		//	} else {
		//		remove("e0");
		//	}
		}
	});	
});
//-------------------------------------------------------------------------------------------------------------------