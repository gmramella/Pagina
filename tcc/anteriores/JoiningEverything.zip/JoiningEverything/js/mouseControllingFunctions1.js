//Node or edge creation and node removal

var coords1, coords2;

var svg = d3.select("body").append("svg").attr("width", 1500).attr("height", 768);
svg.on("mousedown", function() {
	coords1=d3.mouse(this);
});
svg.on("mouseup", function() {
	coords2=d3.mouse(this);
	if(coords1[0]!=coords2[0] || coords1[1]!=coords2[1]) {
		svg.append("line").attr("x1", coords1[0]).attr("y1", coords1[1]).attr("x2", coords2[0]).attr("y2", coords2[1]).attr("stroke", "black").attr("stroke-width", "5").attr("id", "linha");
	} else {
		svg.append("circle").attr("cx", coords1[0]).attr("cy", coords1[1]).attr("r", "5").attr("fill", "red").attr("id", "circulo");
	}
});
svg.call(drag);

var drag = d3.behavior.drag().origin(function(d) {return d;}).on("dragstart", dragstarted).on("drag", dragged).on("dragend", dragended);               
		 
function dragstarted(d) {
	d3.event.sourceEvent.stopPropagation();
	d3.select(this).classed("dragging", true);
}

function dragged(d) {
	d3.select(this).attr("x", d.x = d3.event.x).attr("y", d.y = d3.event.y);
}

function dragended(d) {
	d3.select(this).classed("dragging", false);
}