function setEdgeAsSelected(edgeId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][0] == nodeId) {
			if(lastSelectedObjectType == "edge") {
				unsetEdgeAsSelected(lastSelectedObjectId);
			}
			if(lastSelectedObjectType == "node") {
				unsetNodeAsSelected(lastSelectedObjectId);
			}
			edges[i][2] = true;
			lastSelectedObjectId = i;
			lastSelectedObjectType = "edge";
		}
	}
}

function setNodeAsSelected(nodeId) {
	for(var i=0;i<nodes.length;i++) {
		if(nodes[i][0] == nodeId) {
			if(lastSelectedObjectType == "edge") {
				unsetEdgeAsSelected(lastSelectedObjectId);
			}
			if(lastSelectedObjectType == "node") {
				unsetNodeAsSelected(lastSelectedObjectId);
			}
			nodes[i][2] = true;
			lastSelectedObjectId = i;
			lastSelectedObjectType = "node";
		}
	}
}

function unsetEdgeAsSelected(lastSelectedObjectId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][0] == lastSelectedObjectId) {
			edges[i][2] = false;
			lastSelectedObjectId = null;
			lastSelectedObjectType = null;
			break;
		}
	}
}

function unsetEdgeAsSelected(lastSelectedObjectId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][0] == lastSelectedObjectId) {
			edges[i][2] = false;
			lastSelectedObjectId = null;
			lastSelectedObjectType = null;
			break;
		}
	}
}

function removeFromEdgesArray(edgeId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][0] == edgeId) {
			edges.splice(i, 1);
			break;
		}
	}
}

function removeFromNodesArray(nodeId) {
	for(var i=0;i<nodes.length;i++) {
		if(nodes[i][0] == nodeId) {
			nodes.splice(i, 1);
			break;
		}
	}
}