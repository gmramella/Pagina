var nodes = [{id:2, x:3, y:4},{id:1, x:3, y:4},{id:3, x:3, y:4}];

var n1={id:1,x:34,y:70};
var n2={id:2,x:37,y:70};
var n3={id:4,x:31,y:70};
var ns = [n1,n2,n3];

var e1={id:1,src:1,tgt:2};
var e2={id:2,src:2,tgt:2};
var e3={id:3,src:2,tgt:3};
var es = [e1,e2,e3]; 

var graph1 = {
	nodes:ns, 
	edges:es, 
	newNode:4, 
	newEdge:4,
	createNode : function (a,b) {
		var n = {id:this.newNode, x:a, y:b};
		this.newNode = this.newNode+1;
		var ns = this.nodes;
		ns.push(n);
		return this;
	}
};

function new_graph(ns,es) {
	var g = {
		nodes:ns,
		edges:es,
		newNode: foo(ns), // 
		newEdge: bar(es), 
		createNode : function (a,b) {
			var n = {id:this.newNode, x:a, y:b};
			this.newNode = this.newNode+1;
			var ns = this.nodes;
			ns.push(n);
			return this;
		};
	return g;
} 

var graph2 = graph1.createNode(2,3); 

alert( graph1.createNode(2,3).newNode );