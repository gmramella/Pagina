//Check if a point (x,y) is inside a node (circle) with center coordinates (cx,cy) and radius r
function pointInNode(x, y, cx, cy, r) {
	var distancesquared = ((x - cx) * (x - cx)) + ((y - cy) * (y - cy));
	return distancesquared <= r * r;
}

//Check if a point (x,y) is inside any node (circle) in nodes array
function pointInSomeNode(nodes, x, y) {
	for (var i = 0; i < nodes.length; i++) {
		if(pointInNode(x, y, nodes[i][3], nodes[i][4], nodes[i][5])) {
			return i;
		}
	}
	return -1;
}

//Check if a point (x,y) is inside an edge (line) with end points (x1,y1) and (x2,y2)
function pointInEdge(x, y, x1, y1, x2, y2, width) {
	var fx = y1+((y2-y1)/(x2-x1))*(x-x1);
	return (x >= x1 && x <= x2 && y >= (fx - width) && y <= (fx + width));
}

//Check if a point (x,y) is inside any edge (line) in edges array
function pointInSomeEdge(nodes, edges, x, y) {
	for (var i = 0; i < edges.length; i++) {
		if(pointInEdge(x, y, nodes[edges[i][3]][3], nodes[edges[i][3]][4], nodes[edges[i][4]][3], nodes[edges[i][4]][4], edges[i][5])) {
			return i;
		}
	}
	return -1;
}

//Check if a node (x,y) with radius r is inside a region (rect) with end points (x1,y1) and (x2,y2)
function nodeInRegion(x, y, r, x1, y1, x2, y2) {
	return ((x-r) >= x1 && (x+r) <= x2 && (y-r) >= y1 && (y+r) <= y2);
}

//Get all nodes inside a region (rect) with end points (x1,y1) and (x2,y2)
function allNodesInRegion(nodes, x1, y1, x2, y2) {
	var output = [];
	for (var i = 0; i < nodes.length; i++) {
		if(nodeInRegion(nodes[i][3], nodes[i][4], nodes[i][5], x1, y1, x2, y2)) {
			output.push(nodes[i]);
		}
	}
	return output;
}