//Check if a point (x,y) is inside a node (circle) with center coordinates (cx,cy) and radius r
function pointInNode(x, y, cx, cy, r) {
	var distancesquared = ((x - cx) * (x - cx)) + ((y - cy) * (y - cy));
	return distancesquared <= r * r;
}

//Check if a point (x,y) is inside any node (circle) in nodes array
function pointInSomeNode(nodes, x, y) {
	for (var i = 0; i < nodes.length; i++) {
		if(pointInNode(x, y, nodes[i][3], nodes[i][4], nodes[i][5])) {
			return i;
		}
	}
	return -1;
}

//Check if a point (x,y) is inside an edge (line) with end points (x1,y1) and (x2,y2)
function pointInEdge(x, y, x1, y1, x2, y2, width) {
	if (x == x1 && x1 == x2) return true;
	var fx = y1+((y2-y1)/(x2-x1))*(x-x1);
	return (x >= Math.min(x1, x2) && x <= Math.max(x1, x2) && y >= (fx - width) && y <= (fx + width));
}

//Check if a point (x,y) is inside any edge (line) in edges array
function pointInSomeEdge(nodes, edges, x, y) {
	for (var i = 0; i < edges.length; i++) {
		if(pointInEdge(x, y, nodes[edges[i][3]][3], nodes[edges[i][3]][4], nodes[edges[i][4]][3], nodes[edges[i][4]][4], edges[i][5])) {
			return i;
		}
	}
	return -1;
}

//Check if a node (x,y) with radius r is inside a region (rect) with end points (x1,y1) and (x2,y2)
function nodeInRegion(x, y, r, x1, y1, x2, y2) {
	return ((x-r) >= Math.min(x1, x2) && (x+r) <= Math.max(x1, x2) && (y-r) >= Math.min(y1, y2) && (y+r) <= Math.max(y1, y2));
}

//Get all nodes inside a region (rect) with end points (x1,y1) and (x2,y2)
function allNodesInRegion(nodes, x1, y1, x2, y2) {
	var output = [];
	for (var i = 0; i < nodes.length; i++) {
		if(nodeInRegion(nodes[i][3], nodes[i][4], nodes[i][5], x1, y1, x2, y2)) {
			output.push(nodes[i]);
		}
	}
	return output;
}

//Check if an edge (s,t) is completely inside a region (rect) with end points (x1,y1) and (x2,y2)
function edgeInRegion(s, t, x1, y1, x2, y2) {
	return ((Math.min(x1, x2) <= s[0] && s[0] <= Math.max(x1, x2)) && (Math.min(x1, x2) <= t[0] && t[0] <= Math.max(x1, x2)) && (Math.min(y1, y2) <= s[1] && s[1] <= Math.max(y1, y2)) && (Math.min(y1, y2) <= t[1] && t[1] <= Math.max(y1, y2)));
}

//Get all edges inside a region (rect) with end points (x1,y1) and (x2,y2)
function allEdgesInRegion(nodes, edges, x1, y1, x2, y2) {
	var output = [];
	for (var i = 0; i < edges.length; i++) {
		if(edgeInRegion([nodes[edges[i][3]][3], nodes[edges[i][3]][4]], [nodes[edges[i][4]][3], nodes[edges[i][4]][4]], x1, y1, x2, y2)) {
			output.push(edges[i]);
		}
	}
	return output;
}