function KeyDown(e) {
	var evtobj = window.event? event : e;
	switch (evtobj.keyCode) {
		case 32:
			alert("Edges: " + edges + "\r\nEdgesCounter: " + edgesCounter + "\r\nEdgeLabels: " + edgeLabels + "\r\nNodes: " + nodes + "\r\nNodesCounter: " + nodesCounter + "\r\nNodeLabels: " + nodeLabels + "\r\nRects: " + rects + "\r\nRectsCounter: " + rectsCounter + "\r\nRectLabels: " + rectLabels);
			break;
		case 65://Update target
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 68://Delete
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 69://Create edge
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 70://Create edge from
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 78://Create node
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 79://Update source
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 82://Read/Create rect
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 83://Select
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 84://Create edge to
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 85://Update
			switch (rightButtonMenuCode) {
				case -1:
					break;
				case 0:
					
					break;
				case 1:
					
					break;
				case 2:
					
					break;
			}
			break;
		case 90:
			if (evtobj.ctrlKey) {
				if (lastCreatedObjectType.length > 0) {
					if (lastCreatedObjectType[lastCreatedObjectType.length - 1] == "edge") {
						//d3.select("#edge"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						d3.selectAll(".edge"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						d3.select("#edgelabel"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						edges.pop();
						edgeLabels.pop();
						lastCreatedObjectType.pop();
						lastCreatedObjectId.pop();
						edgesCounter--;
					} else if (lastCreatedObjectType[lastCreatedObjectType.length - 1] == "node") {
						d3.select("#node"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						d3.select("#nodelabel"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						nodes.pop();
						nodeLabels.pop();
						lastCreatedObjectType.pop();
						lastCreatedObjectId.pop();
						nodesCounter--;
					} else if (lastCreatedObjectType[lastCreatedObjectType.length - 1] == "rect") {
						d3.select("#rect"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						d3.select("#rectlabel"+lastCreatedObjectId[lastCreatedObjectId.length - 1].toString()).remove();
						rects.pop();
						rectLabels.pop();
						lastCreatedObjectType.pop();
						lastCreatedObjectId.pop();
						rectsCounter--;
					}
				} else {
					alert("Canvas vazio");
				}
			}
			break;
	}
}
document.addEventListener("keydown", KeyDown);