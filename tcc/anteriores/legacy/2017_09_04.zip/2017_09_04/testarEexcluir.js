mousedownAndMouseupCode*=2;//left mousedown over some node
mousedownAndMouseupCode*=3;//left mousedown over some edge
mousedownAndMouseupCode*=5;//left mousedown over the svg

mousedownAndMouseupCode*=7;//middle mousedown over some node
mousedownAndMouseupCode*=11;//middle mousedown over some edge
mousedownAndMouseupCode*=13;//middle mousedown over the svg

mousedownAndMouseupCode*=17;//right mousedown over some node
mousedownAndMouseupCode*=19;//right mousedown over some edge
mousedownAndMouseupCode*=23;//right mousedown over the svg

mousedownAndMouseupCode*=29;//left mouseup over some node
mousedownAndMouseupCode*=31;//left mouseup over some edge
mousedownAndMouseupCode*=37;//left mouseup over the svg

mousedownAndMouseupCode*=41;//middle mousedown over some node
mousedownAndMouseupCode*=43;//middle mousedown over some edge
mousedownAndMouseupCode*=47;//middle mousedown over the svg

mousedownAndMouseupCode*=53;//right mouseup over some node
mousedownAndMouseupCode*=59;//right mouseup over some edge
mousedownAndMouseupCode*=61;//right mouseup over the svg

switch(mousedownAndMouseupCode) {
case 2*29://left mousedown over some node AND left mouseup over some node
break;
case 2*31://left mousedown over some node AND left mouseup over some edge
break;
case 2*37://left mousedown over some node AND left mouseup over the svg
break;
case 3*29://left mousedown over some edge AND left mouseup over some node
break;
case 3*31://left mousedown over some edge AND left mouseup over some edge
break;
case 3*37://left mousedown over some edge AND left mouseup over the svg
break;
case 5*29://left mousedown over the svg AND left mouseup over some node
break;
case 5*31://left mousedown over the svg AND left mouseup over some edge
break;
case 5*37://left mousedown over the svg AND left mouseup over the svg
break;

case 7*41://middle mousedown over some node AND middle mouseup over some node
break;
case 7*43://middle mousedown over some node AND middle mouseup over some edge
break;
case 7*47://middle mousedown over some node AND middle mouseup over the svg
break;
case 11*41://middle mousedown over some edge AND middle mouseup over some node
break;
case 11*43://middle mousedown over some edge AND middle mouseup over some edge
break;
case 11*47://middle mousedown over some edge AND middle mouseup over the svg
break;
case 13*41://middle mousedown over the svg AND middle mouseup over some node
break;
case 13*43://middle mousedown over the svg AND middle mouseup over some edge
break;
case 13*47://middle mousedown over the svg AND middle mouseup over the svg
break;

case 17*53://right mousedown over some node AND right mouseup over some node
break;
case 17*59://right mousedown over some node AND right mouseup over some edge
break;
case 17*61://right mousedown over some node AND right mouseup over the svg
break;
case 19*53://right mousedown over some edge AND right mouseup over some node
break;
case 19*59://right mousedown over some edge AND right mouseup over some edge
break;
case 19*61://right mousedown over some edge AND right mouseup over the svg
break;
case 23*53://right mousedown over the svg AND right mouseup over some node
break;
case 23*59://right mousedown over the svg AND right mouseup over some edge
break;
case 23*61://right mousedown over the svg AND right mouseup over the svg
break;
}

