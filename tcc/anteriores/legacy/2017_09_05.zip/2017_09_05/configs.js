var defaultAutomorphismColor = "yellow";
var selectedAutomorphismColor = "green";
var defaultAutomorphismWidth = 8;

var defaultAutomorphismLabelFontName = "sans-serif";
var defaultAutomorphismLabelFontSize = "20px";
var defaultAutomorphismLabelColor = "black";

var defaultEdgeColor = "yellow";
var selectedEdgeColor = "green";
var defaultEdgeWidth = 8;

var defaultEdgeLabelFontName = "sans-serif";
var defaultEdgeLabelFontSize = "20px";
var defaultEdgeLabelColor = "black";

var defaultNodeColor = "red";
var selectedNodeColor = "blue";
var defaultNodeRadius = 50;

var defaultNodeLabelFontName = "sans-serif";
var defaultNodeLabelFontSize = "20px";
var defaultNodeLabelColor = "black";

var defaultRectColor = "blue";
var defaultRectWidth = 2;

var defaultRectLabelFontName = "sans-serif";
var defaultRectLabelFontSize = "20px";
var defaultRectLabelColor = "black";