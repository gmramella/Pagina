function setEdgeAsSelected(edgeId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][1] == nodeId) {
			if(lastSelectedObjectType == "edge") {
				unsetEdgeAsSelected(lastSelectedObjectId);
			}
			if(lastSelectedObjectType == "node") {
				unsetNodeAsSelected(lastSelectedObjectId);
			}
			edges[i][2] = true;
			lastSelectedObjectId = i;
			lastSelectedObjectType = "edge";
		}
	}
}

function setNodeAsSelected(nodeId) {
	for(var i=0;i<nodes.length;i++) {
		if(nodes[i][1] == nodeId) {
			if(lastSelectedObjectType == "edge") {
				unsetEdgeAsSelected(lastSelectedObjectId);
			}
			if(lastSelectedObjectType == "node") {
				unsetNodeAsSelected(lastSelectedObjectId);
			}
			nodes[i][2] = true;
			lastSelectedObjectId = i;
			lastSelectedObjectType = "node";
		}
	}
}

function unsetNodeAsSelected(lastSelectedObjectId) {
	for(var i=0;i<nodes.length;i++) {
		if(nodes[i][1] == lastSelectedObjectId) {
			nodes[i][2] = false;
			lastSelectedObjectId = null;
			lastSelectedObjectType = null;
			break;
		}
	}
}

function unsetEdgeAsSelected(lastSelectedObjectId) {
	for(var i=0;i<edges.length;i++) {
		if(edges[i][1] == lastSelectedObjectId) {
			edges[i][2] = false;
			lastSelectedObjectId = null;
			lastSelectedObjectType = null;
			break;
		}
	}
}

function removeFromArrayById(id, arr) {
	for(var i=0;i<arr.length;i++) {
		if(arr[i][0] == id) {
			arr.splice(i, 1);
			break;
		}
	}
}