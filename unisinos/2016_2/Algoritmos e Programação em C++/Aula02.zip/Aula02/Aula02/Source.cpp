#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int a;
	a = getchar();
	printf("%c - %d",a,a);
	system("pause");
	return 0;
}