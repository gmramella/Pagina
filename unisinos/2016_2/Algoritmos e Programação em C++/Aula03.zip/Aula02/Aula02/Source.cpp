#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void problema01() {
	//Imprimir no terminal o seu primeiro nome.
	char nome[9];
	printf("Seu nome: ");
	scanf("%s", &nome);
	printf("Seu nome eh %s\r\n", nome);
}

void problema02() {
	//Imprimir a sua idade no terminal, Utilizando uma vari�vel do tipo int
	int idade;
	printf("Qual sua idade? ");
	scanf("%d", &idade);
	printf("Voce tem %d anos\r\n", idade);
}

void problema03() {
	//Imprimir o pre�o do p�o de queijo vendido no Alem�o no terminal, Utilizando uma vari�vel do tipo float
	float preco;
	printf("Preco: ");
	scanf("%f", &preco);
	printf("Custa R$ %.2f\r\n", preco);
}

void problema04() {
	//Desenhar a seguinte forma no terminal
	printf("********\r\n********\r\n********\r\n********\r\n");
}

void problema05() {
	//Solicitar ao usu�rio o dia do seu nascimento
	int dia;
	printf("Dia: ");
	scanf("%d", &dia);
	printf("Nasceu em %d\r\n", dia);
}

void problema06() {
	//Solicitar ao usu�rio o dia e m�s do seu nascimento
	int dia, mes;
	printf("Dia e mes: ");
	scanf("%d/%d", &dia, &mes);
	printf("Nasceu em %.2d/%.2d\r\n", dia, mes);
}

void problema07() {
	//Solicitar ao usu�rio o dia, m�s e ano do seu nascimento
	int dia, mes, ano;
	printf("Data: ");
	scanf("%d/%d/%d", &dia, &mes, &ano);
	printf("Nasceu em %.2d/%.2d/%.4d\r\n", dia, mes, ano);
}

void problema08() {
	//Recebe um char e imprima na tela o int referente a ele
	char a;
	printf("Char: ");
	a = getchar();
	printf("%d\r\n", a);
}

void problema09() {
	//Implementar um programa que solicite dois n�meros ao usu�rio e exiba na tela a soma destes dois n�meros
	int a, b, c;
	printf("Numeros: ");
	scanf("%d %d", &a, &b);
	c = a + b;
	printf("Soma: %d\r\n", c);
}

void problema10() {
	//Implementar um programa que solicite dois n�meros ao usu�rio e exiba na tela a subtra��o destes dois n�meros
	int a, b, c;
	printf("Numeros: ");
	scanf("%d %d", &a, &b);
	c = a - b;
	printf("Subtracao: %d\r\n", c);
}

void problema11() {
	//Implementar um programa que solicite dois n�meros ao usu�rio e exiba na tela a multiplica��o destes dois n�meros
	int a, b, c;
	printf("Numeros: ");
	scanf("%d %d", &a, &b);
	c = a * b;
	printf("Multiplicacao: %d\r\n", c);
}

void problema12() {
	//Implementar um programa que solicite um n�mero ao usu�rio. Sendo este n�mero uma temperatura em graus Celsius, fa�a um programa para converter esta temperatura em graus Fahrenheit e exiba o resultado na tela
	float celsius, fahrenheit;
	printf("Celsius: ");
	scanf("%f", &celsius);
	fahrenheit = 1.8*celsius + 32;
	printf("Fahrenheit %.2f\r\n", fahrenheit);
}

void problema13() {
	//Implementar um programa que solicite um n�mero ao usu�rio. Sendo este n�mero uma temperatura em graus Fahrenheit, fa�a um programa para converter esta temperatura em graus Celsius e exiba o resultado na tela
	float celsius, fahrenheit;
	printf("Fahrenheit: ");
	scanf("%f", &fahrenheit);
	celsius = (fahrenheit - 32) / 1.8;
	printf("Celsius %.2f\r\n", celsius);
}

void problema14() {
	//Implementar um programa que solicite dois n�meros ao usu�rio e exiba na tela a divis�o destes dois n�meros
	float a, b, c;
	printf("Numeros: ");
	scanf("%f %f", &a, &b);
	c = a / b;
	printf("Divisao %f\r\n", c);
}

void problema15() {
	//Implementar um programa que solicite um n�mero ao usu�rio. Sendo este n�mero uma velocidade em km/h, fa�a um programa para converter esta velocidade em m/s e exiba o resultado na tela
	float a, b;
	printf("km/h: ");
	scanf("%f", &a);
	b = a / 3.6;
	printf("m/s: %f\r\n", b);
}

void problema16() {
	//Desenvolva um programa que solicite ao usu�rio o raio de um circulo e exiba a �rea deste circulo na tela
	float raio, area;
	printf("Raio: ");
	scanf("%f", &raio);
	area = 3.14 * raio * raio;
	printf("Area: %f\r\n", area);
}

void problema17() {
	//Desenvolva um programa que solicite ao usu�rio a altura e a largura de um ret�ngulo e exiba a �rea deste ret�ngulo na tela
	float altura, largura, area;
	printf("Altura: ");
	scanf("%f", &altura);
	getc(stdin);
	printf("Largura: ");
	scanf("%f", &largura);
	area = altura * largura;
	printf("Area: %f\r\n", area);
}

void problema18() {
	//Desenvolva um programa que solicite ao usu�rio a altura e a largura de um tri�ngulo ret�ngulo e exiba a �rea deste tri�ngulo ret�ngulo na tela
	float altura, largura, area;
	printf("Altura: ");
	scanf("%f", &altura);
	getc(stdin);
	printf("Largura: ");
	scanf("%f", &largura);
	area = altura * largura / 2;
	printf("Area: %f\r\n", area);
}

void problema19() {
	//Desenvolva um programa que solicite dois n�meros ao usu�rio e que exiba o resultado do primeiro n�mero elevado ao segundo, ou seja, pot�ncia
	float a, b, c;
	printf("Base: ");
	scanf("%f", &a);
	getc(stdin);
	printf("Expoente: ");
	scanf("%f", &b);
	c = pow(a, b);
	printf("c: %f\r\n", c);
}

void problema20() {
	//Desenvolva um programa que solicita dois n�meros ao usu�rio. Este n�meros s�o os catetos de um tri�ngulo ret�ngulo, sendo assim, apresente ao usu�rio o valor da hipotenusa deste tri�ngulo ret�ngulo
	float a, b, c;
	printf("Cateto1: ");
	scanf("%f", &a);
	getc(stdin);
	printf("Cateto2: ");
	scanf("%f", &b);
	c = sqrt(a*a + b*b);
	printf("Hipotenusa: %f\r\n", c);
}

int main() {
	//AlgProg-02-Operacoes-IO.pdf
	problema01();
	problema02();
	problema03();
	problema04();
	problema05();
	problema06();
	problema07();
	//Precisa de fflush entre o 07 e o 08
	problema08();
	problema09();
	problema10();
	problema11();
	problema12();
	problema13();
	problema14();
	problema15();

	//AlgProg-Ativ-Math.pdf
	problema16();
	problema17();
	problema18();
	problema19();
	problema20();

	system("pause");
	return 0;
}