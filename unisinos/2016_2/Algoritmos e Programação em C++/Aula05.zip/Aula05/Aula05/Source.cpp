#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>

//1. Desenvolva um programa que solicite ao usu�rio o raio de um circulo e exiba a �rea deste circulo na tela.
void exercicio01() {
	double raio, area;
	printf("Raio: ");
	scanf("%lf", &raio);
	area = 3.14159265358979323846 * raio * raio;
	printf("Area: %lf\r\n", area);
}
//2. Desenvolva um programa que solicite ao usu�rio a altura e a largura de um ret�ngulo e exiba a �rea deste ret�ngulo na tela
void exercicio02() {
	double altura, largura, area;
	printf("Altura e largura: ");
	scanf("%lf %lf", &altura, &largura);
	area = altura * largura;
	printf("Area: %lf\r\n", area);
}
//3. Desenvolva um programa que solicite ao usu�rio a altura e a largura de um tri�ngulo ret�ngulo e exiba a �rea deste tri�ngulo ret�ngulo na tela
void exercicio03() {
	double altura, largura, area;
	printf("Altura e largura: ");
	scanf("%lf %lf", &altura, &largura);
	area = altura * largura / 2;
	printf("Area: %lf\r\n", area);
}
//4. Desenvolva um programa que solicite dois n�meros ao usu�rio e que exiba o resultado do primeiro n�mero elevado ao segundo, ou seja, pot�ncia
void exercicio04() {
	double base, expoente, total;
	printf("Base e expoente: ");
	scanf("%lf %lf", &base, &expoente);
	total = pow(base, expoente);
	printf("Total: %lf\r\n", total);
}
//5. Desenvolva um programa que solicite dois n�meros ao usu�rio. Estes n�meros s�o os catetos de um tri�ngulo ret�ngulo, sendo assim, apresente ao usu�rio o valor da hipotenusa deste tri�ngulo ret�ngulo.
void exercicio05() {
	double cateto1, cateto2, hipotenusa;
	printf("Catetos: ");
	scanf("%lf %lf", &cateto1, &cateto2);
	hipotenusa = sqrt((cateto1*cateto1)+(cateto2*cateto2));
	printf("Hipotenusa: %lf\r\n", hipotenusa);
}
//6. Desenvolva um programa que solicite os tamanhos dos dois catetos de um triangulo ret�ngulo e apresente o per�metro do triangulo ret�ngulo.
void exercicio06() {
	double cateto1, cateto2, hipotenusa, perimetro;
	printf("Catetos: ");
	scanf("%lf %lf", &cateto1, &cateto2);
	hipotenusa = sqrt((cateto1*cateto1) + (cateto2*cateto2));
	perimetro = cateto1 + cateto2 + hipotenusa;
	printf("Perimetro: %lf\r\n", perimetro);
}
//7. Desenvolva um programa que solicite os tamanhos dos lados de um triangulo e informe o tipo deste triangulo com rela��o aos seus lados, ou seja, se ele � um triangulo equil�tero, is�sceles ou escaleno. 
void exercicio07() {
	double cateto1, cateto2, hipotenusa;
	printf("3 lados: ");
	scanf("%lf %lf %lf", &cateto1, &cateto2, &hipotenusa);
	if ((cateto1 + cateto2 > hipotenusa) && (cateto1 + hipotenusa > cateto2) && (cateto1 + cateto2 > hipotenusa)) {
		if (cateto1 == cateto2 && cateto1 == hipotenusa) {
			printf("Tipo: equilatero\r\n");
		}
		else if (cateto1 == cateto2 || cateto1 == hipotenusa || cateto2 == hipotenusa) {
			printf("Tipo: isosceles\r\n");
		}
		else {
			printf("Tipo: escaleno\r\n");
		}
	}
	else {
		printf("Tipo: nao eh triangulo\r\n");
	}
}

//1. Desenvolva um programa que seja capaz de solicitar ao usu�rio dois n�meros e apresente a soma destes dois n�meros.
void exercicio08() {
	double num1, num2, soma;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	soma = num1 + num2;
	printf("Soma: %lf\r\n", soma);
}

//2. Desenvolva um programa que seja capaz de solicitar ao usu�rio dois n�meros e apresente a subtra��o destes dois n�meros.
void exercicio09() {
	double num1, num2, subtracao;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	subtracao = num1 - num2;
	printf("Subtracao: %lf\r\n", subtracao);
}

//3. Desenvolva um programa que seja capaz de solicitar ao usu�rio dois n�meros e apresente a divis�o destes dois n�meros.
void exercicio10() {
	double num1, num2, divisao;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	if (num2 != 0.0) {
		divisao = num1 / num2;
		printf("Divisao: %lf\r\n", divisao);
	}
	else {
		printf("Divisao por zero\r\n");
	}
}

//4. Desenvolva um programa que seja capaz de solicitar ao usu�rio dois n�meros e apresente a multiplica��o destes dois n�meros
void exercicio11() {
	double num1, num2, multiplicacao;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	multiplicacao = num1 * num2;
	printf("Multiplicacao: %lf\r\n", multiplicacao);
}

//5. Desenvolva um programa que seja capaz de solicitar ao usu�rio dois n�meros e uma opera��o. O resultado do c�lculo deve ser apresentado ao usu�rio
void exercicio12() {
	double num1, num2, resultado;
	char operacao;
	printf("Numero operacao numero (+,-,*,/): ");
	scanf("%lf %c %lf", &num1, &operacao, &num2);
	if (operacao == '+' || operacao == '-' || operacao == '*' || operacao == '/') {
		if (operacao == '+') {
			resultado = num1 + num2;
			printf("Soma: %lf\r\n", resultado);
		}
		else if (operacao == '-') {
			resultado = num1 - num2;
			printf("Subtracao: %lf\r\n", resultado);
		}
		else if (operacao == '*') {
			resultado = num1 * num2;
			printf("Multiplicacao: %lf\r\n", resultado);
		}
		else {
			if (num2 != 0.0) {
				resultado = num1 / num2;
				printf("Divisao: %lf\r\n", resultado);
			}
			else {
				printf("Divisao por zero\r\n");
			}
		}
	}
	else {
		printf("Operacao invalida\r\n");
	}
}

//6. Desenvolva um programa que solicite dois n�meros ao usu�rio e apresente o maior n�mero dentre os informados.
void exercicio13() {
	double num1, num2;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	if (num1 > num2) {
		printf("Maior: %lf\r\n", num1);
	}
	else if (num1 < num2) {
		printf("Maior: %lf\r\n", num2);
	}
	else {
		printf("Maior: %lf %f\r\n", num1, num2);
	}
}

//7. Desenvolva um programa que solicite ao usu�rio dois n�meros e apresente uma das seguintes mensagens
//		�O primeiro n�mero � maior�, caso o primeiro n�mero informado seja o maior dentre os informados;
//		�O segundo n�mero � o maior�, caso o segundo n�mero informado seja o maior dentre os informados;
//		�Os n�meros s�o iguais�, caso os dois n�meros informados sejam iguais.
void exercicio14() {
	double num1, num2;
	printf("2 numeros: ");
	scanf("%lf %lf", &num1, &num2);
	if (num1 > num2) {
		printf("O primeiro numero eh maior\r\n");
	}
	else if (num1 < num2) {
		printf("O segundo numero eh maior\r\n");
	}
	else {
		printf("Os numeros sao iguais\r\n");
	}
}

//8. Desenvolva um programa que solicite ao usu�rio 3 n�meros inteiros e um n�mero real (float). Calcule e mostre: 
//		O produto do dobro do primeiro com metade do segundo.
//		A soma do triplo do primeiro com o terceiro.
//		O terceiro elevado ao cubo.
void exercicio15() {
	int num1, num2, num3;
	float num4;
	printf("3 numeros inteiros e 1 numero real: ");
	scanf("%d %d %d %f", &num1, &num2, &num3, &num4);
	printf("num1*num2 = %d\r\n", num1*num2);
	printf("3*num1+num3 = %d\r\n", 3 * num1 + num3);
	printf("num3*num3*num3 = %d\r\n", num3*num3*num3);
}

//9. Tendo como dados de entrada a altura e o sexo de uma pessoa, construa um algoritmo que calcule seu peso ideal, utilizando as seguintes f�rmulas: 
//		Para homens: (72.7*h) � 58 (h = altura)
//		Para mulheres: (62.1*h) - 44.7 (h = altura)
//		Ap�s calcular o peso ideal para a pessoa, solicite o seu peso e informe se ela est� dentro, acima ou abaixo do peso.
void exercicio16() {
	double altura, ideal, peso;
	char sexo;
	printf("Altura (em m) e sexo (m ou f): ");
	scanf("%lf %c", &altura, &sexo);
	if (sexo == 'm' || sexo == 'f') {
		if (sexo == 'm') {
			ideal = (72.7*altura) - 58;
		}
		else {
			ideal = (62.1*altura) - 44.7;
		}
	}
	else {
		printf("Sexo invalido\r\n");
	}
	printf("Peso (em kg): ");
	scanf("%lf", &peso);
	if (peso > ideal) {
		printf("Acima do peso\r\n");
	}
	else if (peso < ideal) {
		printf("Abaixo do peso\r\n");
	}
	else {
		printf("Dentro do peso\r\n");
	}
}

//10. Desenvolva um programa que pergunte ao usu�rio quanto ele ganha por hora e o n�mero de horas trabalhadas no m�s. Calcule e mostre o total do seu sal�rio no referido m�s, sabendo-se que s�o descontados 11 % para o Imposto de Renda (IR), 8 % para o INSS e 5 % para o sindicato, fa�a um programa que nos d�:
//		Sal�rio bruto.
//		Quanto pagou ao INSS.
//		Quanto pagou ao sindicato.
//		O sal�rio l�quido.
//		Calcule os descontos e o sal�rio l�quido, conforme a tabela abaixo: 
//			Sal�rio Bruto - IR(11 % ) - INSS(8 % ) - Sindicato(5 % ) = Sal�rio Liquido
//Obs.: Sal�rio Bruto - Descontos = Sal�rio L�quido. 
void exercicio17() {
	double porHora, bruto, ir, inss, sindicato, liquido;
	int horasTrabalhadas;
	printf("Quanta ganha por hora e horas trabalhadas no mes: ");
	scanf("%lf %d", &porHora, &horasTrabalhadas);
	bruto = porHora * horasTrabalhadas;
	ir = 0.11 * bruto;
	inss = 0.08 * bruto;
	sindicato = 0.05 * bruto;
	liquido = 0.76 * bruto;
	printf("Salario bruto: %lf\r\n", bruto);
	printf("Imposto de Renda: %lf\r\n", ir);
	printf("INSS: %lf\r\n", inss);
	printf("Sindicato: %lf\r\n", sindicato);
	printf("Salario liquido: %lf\r\n", liquido);
}

//11. Desenvolva um programa que solicite 10 n�meros ao usu�rio e calcule a soma destes n�meros. Apresente o resultado ao usu�rio.
void exercicio18() {
	double soma = 0;
	int i;
	for (i=0;i<10;i++) {
		printf("Numero: ");
		double temp;
		scanf("%lf", &temp);
		soma += temp;
	}
	printf("Soma: %lf\r\n", soma);
}

//12. Desenvolva um programa que solicite 10 n�meros ao usu�rio e apresente o maior n�mero informado.
void exercicio19() {
	double maior;
	printf("Numero: ");
	scanf("%lf", &maior);
	int i;
	for (i = 1; i<10; i++) {
		printf("Numero: ");
		double temp;
		scanf("%lf", &temp);
		if (temp > maior) {
			maior = temp;
		}
	}
	printf("Maior: %lf\r\n", maior);
}

//13. Desenvolva um programa que solicite 10 n�meros ao usu�rio e apresente o menor n�mero informado.
void exercicio20() {
	double menor;
	printf("Numero: ");
	scanf("%lf", &menor);
	int i;
	for (i = 1; i<10; i++) {
		printf("Numero: ");
		double temp;
		scanf("%lf", &temp);
		if (temp < menor) {
			menor = temp;
		}
	}
	printf("Menor: %lf\r\n", menor);
}

//14. Desenvolva um programa que solicite ao usu�rio base e expoente. Com estes n�meros, calcule a pot�ncia e informe o resultado ao usu�rio. IMPORTANTE: para este exerc�cio, n�o � permitido o uso da fun��o pow existem na biblioteca math.h. Utilize um la�o para realizar o c�lculo.
void exercicio21() {
	double base;
	int expoente;
	printf("1 numero real e 1 numero natural: ");
	scanf("%lf %d", &base, &expoente);
	if (expoente >= 0) {
		if (expoente == 0) {
			printf("Exponenciacao: %lf\r\n", 1.0);
		}
		else {
			double exponenciacao = 1;
			while (expoente > 0) {
				exponenciacao *= base;
				expoente--;
			}
			printf("Exponenciacao: %lf\r\n", exponenciacao);
		}
	}
	else {
		printf("Expoente invalido\r\n");
	}
}

//15. Desenvolva um programa que solicite ao usu�rio um n�mero inteiro. Calcule o fatorial deste n�mero e apresente-o ao usu�rio.
void exercicio22() {
	int num;
	printf("1 numero natural ateh 22: ");
	scanf("%d", &num);
	if (num >= 0) {
		if (num < 2) {
			printf("Fatorial: %d", 1);
		}
		else {
			double fatorial = 1;
			while (num > 1) {
				fatorial *= num;
				num--;
			}
			printf("Fatorial: %.0lf", fatorial);
		}
	}
	else {
		printf("Numero invalido");
	}
}

int main() {
	//AlgProg-Ativ-Math.pdf
	//exercicio01();
	//exercicio02();
	//exercicio03();
	//exercicio04();
	//exercicio05();
	//exercicio06();
	//exercicio07();

	//AlgProg - Lista1.pdf
	//exercicio08();
	//exercicio09();
	//exercicio10();
	//exercicio11();
	//exercicio12();
	//exercicio13();
	//exercicio14();
	//exercicio15();
	//exercicio16();
	//exercicio17();
	//exercicio18();
	//exercicio19();
	//exercicio20();
	//exercicio21();
	exercicio22();

	_getch();
	return 0;
}