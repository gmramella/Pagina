#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>

void imprimirMenu() {
	system("cls");
	printf("01. Ajuda\r\n");
	printf("02. Informar nota dos exercicios do Grau A\r\n");
	printf("03. Informar nota do trabalho do Grau A\r\n");
	printf("04. Informar nota da prova do Grau A\r\n");
	printf("05. Informar nota dos exercicios do Grau B\r\n");
	printf("06. Informar nota do trabalho do Grau B\r\n");
	printf("07. Informar nota da prova do Grau B\r\n");
	printf("08. Mostrar nota do Grau A\r\n");
	printf("09. Mostrar nota do Grau B\r\n");
	printf("10. Mostrar nota do Grau Final\r\n");
	printf("11. Informar substituicao de Grau\r\n");
	printf("12. Informar nota Grau C\r\n");
	printf("13. Mostrar nota Grau C\r\n");
	printf("14. Sair\r\n");
}

void f01() {
	system("cls");
	printf("Ajuda\r\n");
	printf("Tem que escrever um numero entre 1 e 14\r\n");
	_getch();
}

void f02(float *exercicios1) {
	system("cls");
	printf("Informar nota dos exercicios do Grau A\r\n");
	scanf("%f", exercicios1);
	getc(stdin);
}

void f03(float *trabalho1) {
	system("cls");
	printf("Informar nota do trabalho do Grau A\r\n");
	scanf("%f", trabalho1);
	getc(stdin);
}

void f04(float *prova1) {
	system("cls");
	printf("Informar nota da prova do Grau A\r\n");
	scanf("%f", prova1);
	getc(stdin);
}

void f05(float *exercicios2) {
	system("cls");
	printf("Informar nota dos exercicios do Grau B\r\n");
	scanf("%f", exercicios2);
	getc(stdin);
}

void f06(float *trabalho2) {
	system("cls");
	printf("Informar nota do trabalho do Grau B\r\n");
	scanf("%f", trabalho2);
	getc(stdin);
}

void f07(float *prova2) {
	system("cls");
	printf("Informar nota da prova do Grau B\r\n");
	scanf("%f", prova2);
	getc(stdin);
}

void f08(float exercicios1, float trabalho1, float prova1, float *media1) {
	system("cls");
	if (exercicios1 != -1 && trabalho1 != -1 && prova1 != -1) {
		*media1 = (exercicios1 + trabalho1 + prova1) / 3;
		printf("A nota do Grau A eh %f\r\n", *media1);
		system("pause");
	}
	else {
		printf("Tah faltando alguma nota\r\n");
		system("pause");
	}
}

void f09(float exercicios2, float trabalho2, float prova2, float *media2) {
	system("cls");
	if (exercicios2 != -1 && trabalho2 != -1 && prova2 != -1) {
		*media2 = (exercicios2 + trabalho2 + prova2) / 3;
		printf("A nota do Grau B eh %f\r\n", *media2);
		system("pause");
	}
	else {
		printf("Tah faltando alguma nota\r\n");
		system("pause");
	}
}

float foo(float a, float b) {
	return a * b;
}

void f10(float exercicios1, float trabalho1, float prova1, float *media1, float exercicios2, float trabalho2, float prova2, float *media2, int substituicao, float prova3, float *notaFinal) {
	system("cls");
	*media1 = (exercicios1 + trabalho1 + prova1) / 3;
	*media2 = (exercicios2 + trabalho2 + prova2) / 3;
	if (substituicao != 0) {
		if (prova3 == -1) {
			printf("Falta a nota do grau C\r\n");
		}
		else {
			*notaFinal = prova3;
			printf("A nota do grau final eh %f\r\n", *notaFinal);
		}
	}
	else {
		if (exercicios1 == -1 || trabalho1 == -1 || prova1 == -1 || exercicios2 == -1 || trabalho2 == -1 || prova2 == -1) {
			printf("Falta alguma nota\r\n");
		}
		else {
			*notaFinal = (*media1 + 2 * *media2) / 3;
			printf("A nota do grau final eh %f\r\n", *notaFinal);
		}
	}
	system("pause");
}

void f11(int substituicao) {
	char confirmarSubstituir;
	system("cls");
	printf("Deseja substituir algum grau? (a,b,n)\r\n");
	scanf("%c", &confirmarSubstituir);
	getc(stdin);
	while (confirmarSubstituir != 'a' && confirmarSubstituir != 'b' && confirmarSubstituir != 'n') {
		system("cls");
		printf("Deseja substituir algum grau? (a,b,n)\r\n");
		scanf("%c", &confirmarSubstituir);
		getc(stdin);
	}
	if (confirmarSubstituir == 'a') {
		if (substituicao != 0) {
			char confirmarSubstituir;
			system("cls");
			printf("Ja pediu substituicao antes... tem certeza? (s/n)\r\n");
			scanf("%c", &confirmarSubstituir);
			getc(stdin);
			while (confirmarSubstituir != 's' && confirmarSubstituir != 'n') {
				system("cls");
				printf("Ja pediu substituicao antes... tem certeza? (s/n)\r\n");
				scanf("%c", &confirmarSubstituir);
				getc(stdin);
			}
		}
		else {
			substituicao = 1;
		}
	}
	else if (confirmarSubstituir == 'b') {
		if (substituicao != 0) {
			char confirmarSubstituir;
			system("cls");
			printf("Ja pediu substituicao antes... tem certeza? (s/n)\r\n");
			scanf("%c", &confirmarSubstituir);
			getc(stdin);
			while (confirmarSubstituir != 's' && confirmarSubstituir != 'n') {
				system("cls");
				printf("Ja pediu substituicao antes... tem certeza? (s/n)\r\n");
				scanf("%c", &confirmarSubstituir);
				getc(stdin);
			}
		}
		else {
			substituicao = 2;
		}
	}
	else {

	}
}

void f12(int substituicao, float *prova3) {
	system("cls");
	if (substituicao != 0) {
		printf("Informar nota do Grau C\r\n");
		scanf("%f", prova3);
		getc(stdin);
	}
	else {
		printf("Voce nao solicitou substituicao\r\n");
		system("pause");
	}
	
}

void f13(int substituicao, float prova3) {
	system("cls");
	if (substituicao != 0) {
		if (prova3 != -1) {
			printf("A nota do Grau C eh %f\r\n", prova3);
			system("pause");
		}
		else {
			printf("Tah faltando a nota do grau C\r\n");
			system("pause");
		}
	}
	else {
		printf("Voce nao solicitou substituicao\r\n");
		system("pause");
	}
}

void f14(int *sair) {
	char confirmarSair;
	system("cls");
	printf("Sair? (s/n)\r\n");
	scanf("%c", &confirmarSair);
	getc(stdin);
	while (confirmarSair != 's' && confirmarSair != 'n') {
		system("cls");
		printf("Sair? (s/n)\r\n");
		scanf("%c", &confirmarSair);
		getc(stdin);
	}
	*sair = (confirmarSair == 's');
}

int main() {
	int opcao = -1;
	float exercicios1 = -1;
	float trabalho1 = -1;
	float prova1 = -1;
	float exercicios2 = -1;
	float trabalho2 = -1;
	float prova2 = -1;
	float media1 = -1;
	float media2 = -1;
	float prova3 = -1;
	float notaFinal = -1;
	int substituicao = 0;
	int sair = 0;

	do {
		imprimirMenu();
		scanf("%d", &opcao);
		getc(stdin);
		switch (opcao) {
			case 1:
				f01();
				break;
			case 2:
				f02(&exercicios1);
				break;
			case 3:
				f03(&trabalho1);
				break;
			case 4:
				f04(&prova1);
				break;
			case 5:
				f05(&exercicios2);
				break;
			case 6:
				f06(&trabalho2);
				break;
			case 7:
				f07(&prova2);
				break;
			case 8:
				f08(exercicios1, trabalho1, prova1, &media1);
				break;
			case 9:
				f09(exercicios2, trabalho2, prova2, &media2);
				break;
			case 10:
				f10(exercicios1, trabalho1, prova1, &media1, exercicios2, trabalho2, prova2, &media2, substituicao, prova3, &notaFinal);
				break;
			case 11:
				f11(substituicao);
				break;
			case 12:
				f12(substituicao, &prova3);
				break;
			case 13:
				f13(substituicao, prova3);
				break;
			case 14:
				f14(&sair);
				break;
			default:
				break;
		}
	} while (sair != 1);
	return 0;
}