#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>

void pede2(float* a, float*b) {
	system("cls");
	printf("Primeiro numero: ");
	scanf("%f", a);
	printf("Segundo numero: ");
	scanf("%f", b);
}

void somar2(float a, float b) {
	printf("%f + %f = %f\r\n", a, b, a+b);
	system("pause");
}

void subtrair2(float a, float b) {
	printf("%f - %f = %f\r\n", a, b, a-b);
	system("pause");
}

void multiplicar2(float a, float b) {
	printf("%f * %f = %f\r\n", a, b, a*b);
	system("pause");
}

void dividir2(float a, float b) {
	if (b != 0) {
		printf("%f / %f = %f\r\n", a, b, a / b);
		system("pause");
	}
	else {
		printf("Divisao por zero\r\n", a, b, a / b);
		system("pause");
	}
	
}

int main() {
	int opcao;
	float a, b;

	do {
		system("cls");
		printf("1. Somar\r\n");
		printf("2. Subtrair\r\n");
		printf("3. Multiplicar\r\n");
		printf("4. Dividir\r\n");
		printf("5. Sair\r\n");
		scanf("%d", &opcao);
		
		switch (opcao) {
		case 1:
			pede2(&a, &b);
			somar2(a, b);
			break;
		case 2:
			pede2(&a, &b);
			subtrair2(a, b);
			break;
		case 3:
			pede2(&a, &b);
			multiplicar2(a, b);
			break;
		case 4:
			pede2(&a, &b);
			dividir2(a, b);
			break;
		case 5:
			break;
		default:
			printf("Opcao invalida\r\n");
			system("pause");
		}
	} while (opcao != 5);
	return 0;
}