#include "Cidade.h"
#include <iostream>
#include <string>
using namespace std;

Cidade::Cidade()
{
}

Cidade::Cidade(string nome_, int populacao_, string dataDeCriacao_, string prefeitoAtual_, int numeroDeBairros_, bool isCapital_, string estado_, float area_)
{
	nome = nome_;
	populacao = populacao_;
	dataDeCriacao = dataDeCriacao_;
	prefeitoAtual = prefeitoAtual_;
	numeroDeBairros = numeroDeBairros_;
	isCapital = isCapital_;
	estado = estado_;
	area = area_;
}

Cidade::~Cidade()
{
}

string Cidade::getNome()
{
	return nome;
}

void Cidade::setNome(string nome_)
{
	nome = nome_;
}

int Cidade::getPopulacao()
{
	return populacao;
}

void Cidade::setPopulacao(int populacao_)
{
	populacao = populacao_;
}

string Cidade::getDataDeCriacao()
{
	return dataDeCriacao;
}

void Cidade::setDataDeCriacao(string dataDeCriacao_)
{
	dataDeCriacao = dataDeCriacao_;
}

string Cidade::getPrefeitoAtual()
{
	return prefeitoAtual;
}

void Cidade::setPrefeitoAtual(string prefeitoAtual_)
{
	prefeitoAtual = prefeitoAtual_;
}

int Cidade::getNumeroDeBairros()
{
	return numeroDeBairros;
}

void Cidade::setNumeroDeBairros(int numeroDeBairros_)
{
	numeroDeBairros = numeroDeBairros_;
}

bool Cidade::getIsCapital()
{
	return isCapital;
}

void Cidade::setIsCapital(bool isCapital_)
{
	isCapital = isCapital_;
}

string Cidade::getEstado()
{
	return estado;
}

void Cidade::setEstado(string estado_)
{
	estado = estado_;
}

float Cidade::getArea()
{
	return area;
}

void Cidade::setArea(float area_)
{
	area = area_;
}
