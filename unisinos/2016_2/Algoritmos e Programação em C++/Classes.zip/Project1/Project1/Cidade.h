#include <string>
#pragma once
using namespace std;

class Cidade
{
public:
	
	Cidade(string nome_, int populacao_, string dataDeCriacao_, string prefeitoAtual_, int numeroDeBairros_, bool isCapital_, string estado_, float area_);
	~Cidade();

	string getNome();
	void setNome(string nome_);
	int getPopulacao();
	void setPopulacao(int populacao_);
	string getDataDeCriacao();
	void setDataDeCriacao(string dataDeCriacao_);
	string getPrefeitoAtual();
	void setPrefeitoAtual(string prefeitoAtual_);
	int getNumeroDeBairros();
	void setNumeroDeBairros(int numeroDeBairros_);
	bool getIsCapital();
	void setIsCapital(bool isCapital_);
	string getEstado();
	void setEstado(string estado_);
	float getArea();
	void setArea(float area_);

private:
	Cidade();

	string nome;
	int populacao;
	string dataDeCriacao;
	string prefeitoAtual;
	int numeroDeBairros;
	bool isCapital;
	string estado;
	float area;
};
