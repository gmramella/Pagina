#include "Lampada.h"
#include <iostream>
#include <string>
using namespace std;

Lampada::Lampada()
{
}

Lampada::Lampada(float potencia_, float voltagem_, string tipoDeTecnologia, string fabricante_)
{
}

Lampada::~Lampada()
{
}

bool Lampada::getLigada()
{
	return ligada;
}

void Lampada::setLigada(bool l)
{
	ligada = l;
}

bool Lampada::getConectada()
{
	return conectada;
}

void Lampada::setConectada(bool c)
{
	conectada = c;
}

bool Lampada::getQueimada()
{
	return queimada;
}

void Lampada::setQueimada(bool q)
{
	queimada = q;
}

string Lampada::getFabricante()
{
	return fabricante;
}

void Lampada::conectar(float voltagem)
{
}

void Lampada::ligar(float voltagem)
{
}

float Lampada::getPotencia()
{
	return potencia;
}

float Lampada::getVoltagem()
{
	return voltagem;
}
