#include <string>
#pragma once
using namespace std;

class Lampada
{
public:
	Lampada(float potencia_, float voltagem_, string tipoDeTecnologia, string fabricante_);
	~Lampada();
	float getPotencia();
	float getVoltagem();
	string getTipoDeTecnologia();
	bool getLigada();
	void setLigada(bool l);
	bool getConectada();
	void setConectada(bool c);
	bool getQueimada();
	void setQueimada(bool q);
	string getFabricante();
	void conectar(float voltagem);
	void ligar(float voltagem);

private:
	Lampada();
	float potencia;
	float voltagem;
	string tipoDeTecnologia;
	bool ligada;
	bool conectada;
	bool queimada;
	string fabricante;
};

