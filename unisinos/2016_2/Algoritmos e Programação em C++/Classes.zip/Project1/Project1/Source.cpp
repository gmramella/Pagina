#define _CRT_NO_WARNINGS

#include <locale.h>
#include <iostream>
#include <conio.h>
#include "Cidade.h"
#include "Lampada.h"

using namespace std;

int main() {
	setlocale(LC_ALL, "");

	Cidade c1("S�o Leopoldo", 0, "25/07/1924", "An�bal Moacir da Silva", 24, false, "RS", 102313.0f);
	cout << "Nome da cidade: " << c1.getNome() << endl;
	cout << "Popula��o: " << c1.getPopulacao() << endl;
	cout << "Data de cria��o: " << c1.getDataDeCriacao() << endl;
	cout << "Prefeito atual: " << c1.getPrefeitoAtual() << endl;
	cout << "N�mero de bairros: " << c1.getNumeroDeBairros() << endl;
	cout << "Capital: " << c1.getIsCapital() << endl;
	cout << "Estado: " << c1.getEstado() << endl;

	Cidade *c2 = new Cidade("Porto Alegre", 0, "26/03/1772", "Jos� Fortunatti", 81, true, "RS", 496682.0f);
	cout << "Nome da cidade: " << c2->getNome() << endl;
	cout << "Popula��o: " << c2->getPopulacao() << endl;
	cout << "Data de cria��o: " << c2->getDataDeCriacao() << endl;
	cout << "Prefeito atual: " << c2->getPrefeitoAtual() << endl;
	cout << "N�mero de bairros: " << c2->getNumeroDeBairros() << endl;
	cout << "Capital: " << c2->getIsCapital() << endl;
	cout << "Estado: " << c2->getEstado() << endl;

	Lampada l1(10, 20, "LED", "Philips");
	Lampada l2(30, 40, "Incandescente", "Samsung");
	Lampada *l3 = new Lampada(50, 60, "Eletronica", "Osram");

	_getch();
}