#include <iostream>
#include <string>
#include <cstring>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <iomanip>
#include <vector>
#include <fstream>
#include "Vetor.h"

using namespace std;

int main()
{
	setlocale(LC_ALL, "ptb");
	srand((unsigned int)time(NULL));
	/*
	// Lista 01
	// Problema 01
	cout << "Va pelo caminho 3" << endl;
	// Problema 02
	double total = 0;
	for (int i = 0; i < 365*24; i++) {
		total += 4 * pow(2, 0-i);
	}
	cout << total << endl;
	// Problema 03
	cout << "Pesos: 35,43,49,32,54" << endl;
	// Problema 04
	cout << "Proximos: 26, 49, 19, 34, 18" << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 02
	// Problema 01
	cout << "int, float, float, float, float, int, float, int, float" << endl;
	// Problema 02
	cout << (14 % 3) << ", " << (10 % 5) << ", " << (52 % 2) << ", " << (100 % 23) << ", " << (23 % 100) << ", " << (99292 % 200000) << ", " << (153 % 7) << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 03
	// Problema 01
	cout << "n, n, n, n, n, n, s, n, n , n, s, s, s, n, s, s, n, s, n, s, s, n, s, n, s" << endl;
	// Problema 02
	cout << "int, int, float, bool, char, string, string, int, float, float, string, inv�lido, inv�lido, char, float, inv�lido, int, bool" << endl;
	// Problema 03
	float A, B, C;
	A = 5; B = 25; C = 10;
	cout << (A + B + C) << ", " << (A + B * C) << ", " << (A + B / C) << ", " << (A * B + C) << ", " << ((A + B) / C) << ", " << (A - (B / C)) << ", " << endl;
	// Problema 04
	A = 3;
	B = 2;
	C = A + B;
	B = A + B;
	C = B * 4;
	A = B + C;
	cout << A << ", " << B << ", " << C << endl;
	// Problema 05
	cout << "float, string, int, char" << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 04
	// Problema 01
	float comprimento, largura, area;
	cout << "Comprimento: ";
	cin >> comprimento;
	cout << "Largura: ";
	cin >> largura;
	area = comprimento * largura;
	cout << "Area: " << area << endl;
	// Problema 02
	int cavalos, ferraduras;
	cout << "Cavalos: ";
	cin >> cavalos;
	ferraduras = 4 * cavalos;
	cout << "Ferraduras: " << ferraduras << endl;
	// Problema 03
	int paes, broas;
	double arrecadacao;
	cout << "Paes: ";
	cin >> paes;
	cout << "Broas: ";
	cin >> broas;
	arrecadacao = 0.25 * paes + 1.50 * broas;
	cout << "Arrecadacao: " << arrecadacao << endl;
	// Problema 04
	float preco, valor, litros;
	cout << "Preco: ";
	cin >> preco;
	cout << "Valor: ";
	cin >> valor;
	litros = valor / preco;
	cout << "Litros: " << litros << endl;
	// Problema 05
	float grauA, grauB, notaFinal;
	cout << "Grau A: ";
	cin >> grauA;
	cout << "Grau B: ";
	cin >> grauB;
	notaFinal = (grauA + 2 * grauB) / 3;
	cout << "Nota final: " << notaFinal << endl;
	// Problema 06
	int centimetros;
	float metros;
	cout << "Centimetros: ";
	cin >> centimetros;
	metros = (float)centimetros / 100;
	cout << "Metros: " << metros << endl;
	// Problema 07
	int minutos, segundos;
	cout << "Minutos: ";
	cin >> minutos;
	segundos = minutos * 60;
	cout << "Segundos: " << segundos << endl;
	// Problema 08
	double normal, descontado;
	cout << "Normal: ";
	cin >> normal;
	descontado = normal * 0.85;
	cout << "Descontado: " << descontado << endl;
	// Problema 09
	int camisetas, calcas, cintos;
	double arrecadacao, desconto, valor;
	cout << "Camisetas: ";
	cin >> camisetas;
	cout << "Calcas: ";
	cin >> calcas;
	cout << "Cintos: ";
	cin >> cintos;
	arrecadacao = 19.00 * camisetas + 75.00 * calcas + 40.00 * cintos;
	desconto = arrecadacao * 0.10;
	valor = arrecadacao * 0.90;
	cout << "Desconto: " << desconto << endl;
	cout << "Valor: " << valor << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 05
	// Problema 01
	double gramas, kilos, valor;
	cout << "Gramas: ";
	cin >> gramas;
	kilos = gramas / 1000;
	valor = kilos * 45.00;
	cout << "Valor: " << valor << endl;
	// Problema 02
	double inicial, aumentado, descontado;
	cout << "Inicial: ";
	cin >> inicial;
	aumentado = inicial * 1.15;
	descontado = aumentado * 0.92;
	cout << "Inicial: " << inicial << endl;
	cout << "Aumentado: " << aumentado << endl;
	cout << "Descontado: " << descontado << endl;
	// Problema 03
	int hamburgueres;
	double tofu = 30, bife = 150, tomate = 60, milho = 13, ervilha = 13, maionese = 45;
	cout << "Hamburgueres: ";
	cin >> hamburgueres;
	streamsize temp = cout.precision();
	cout << "Tofupiry: " << fixed << setprecision(3) << (double)((hamburgueres * tofu) / 1000) << endl;
	cout << "Bife: " << fixed << setprecision(3) << (double)((hamburgueres * bife) / 1000) << endl;
	cout << "Tomate: " << fixed << setprecision(3) << (double)((hamburgueres * tomate) / 1000) << endl;
	cout << "Milho: " << fixed << setprecision(3) << (double)((hamburgueres * milho) / 1000) << endl;
	cout << "Ervilha: " << fixed << setprecision(3) << (double)((hamburgueres * ervilha) / 1000) << endl;
	cout << "Maionese: " << fixed << setprecision(3) << (double)((hamburgueres * maionese) / 1000) << endl;
	setprecision(temp);// NAO FUNCIONANDO ****************************************************************************
	// Problema 04
	int l330, l750, l1300;
	double litros;
	cout << "Garrafas de 330 ml: ";
	cin >> l330;
	cout << "Garrafas de 750 ml: ";
	cin >> l750;
	cout << "Garrafas de 1300 ml: ";
	cin >> l1300;
	litros = 0.330*l330 + 0.750*l750 + 1.300*l1300;
	cout << "Litros: " << litros << endl;
	// Problema 05
	double alturaPredio, sombraPredio, alturaPessoa, sombraPessoa;
	cout << "sombraPredio: ";
	cin >> sombraPredio;
	cout << "alturaPessoa: ";
	cin >> alturaPessoa;
	cout << "sombraPessoa: ";
	cin >> sombraPessoa;
	alturaPredio = sombraPredio * (alturaPessoa / sombraPessoa);
	cout << "Altura do predio: " << alturaPredio << endl;
	// Problema 06
	int m1, m5, m10, m25, m50, m100;
	double total = 0;
	cout << "Moedas de 1 centavo: ";
	cin >> m1;
	total += m1 * 1;
	cout << "Moedas de 5 centavos: ";
	cin >> m5;
	total += m5 * 5;
	cout << "Moedas de 10 centavos: ";
	cin >> m10;
	total += m10 * 10;
	cout << "Moedas de 25 centavos: ";
	cin >> m25;
	total += m25 * 25;
	cout << "Moedas de 50 centavos: ";
	cin >> m50;
	total += m50 * 50;
	cout << "Moedas de 1 real: ";
	cin >> m100;
	total += m100 * 100;
	total /= 100;
	cout << "Total: " << total << endl;
	// Problema 07
	double minimo, salario, quantidade;
	cout << "Minimo: ";
	cin >> minimo;
	cout << "Salario: ";
	cin >> salario;
	quantidade = salario / minimo;
	cout << "Quantidade: " << quantidade << endl;
	// Problema 08
	double salario1, salario2, despesas, percentual1, percentual2, valor1, valor2;
	cout << "Salario 1: ";
	cin >> salario1;
	cout << "Salario 2: ";
	cin >> salario2;
	cout << "Despesas: ";
	cin >> despesas;
	percentual1 = salario1 / (salario1 + salario2);
	percentual2 = salario2 / (salario1 + salario2);
	valor1 = percentual1 * despesas;
	valor2 = percentual2 * despesas;
	cout << "Valor 1: " << valor1 << endl;
	cout << "Valor 2: " << valor2 << endl;
	// Problema 09
	double distancia, litrosGastos, consumoDoCarro, tempoTotal, velocidade, tempoMinutos, tempoHoras;
	cout << "Digite o tempo de viagem em horas: ";
	cin >> tempoHoras;
	cout << "Digite o tempo de viagem em minutos: ";
	cin >> tempoMinutos;
	cout << "Digite a m�dia de velocidade: ";
	cin >> velocidade;
	cout << "Digite o consumo do carro (algo entre 4 e 17 km/litro): ";
	cin >> consumoDoCarro;
	tempoTotal = 60 * tempoHoras + tempoMinutos;
	distancia = (velocidade * tempoTotal) / 3.6;
	litrosGastos = distancia / consumoDoCarro;
	cout << "A dist�ncia percorrida foi: " << distancia << endl;
	cout << "O total de litros gastos foi: " << litrosGastos << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------

	// Lista 06
	// Problema 01
	double inicial, aumentado, descontado;
	cout << "Inicial: ";
	cin >> inicial;
	aumentado = inicial * 0.65;
	descontado = aumentado * 1.50;
	cout << "Inicial: " << inicial << endl;
	cout << "Aumentado: " << aumentado << endl;
	cout << "Descontado: " << descontado << endl;
	// Problema 02
	double gremio, internacional, novoHamburgo, juventude, nenhum;
	double percentualGremio, percentualInternacional, percentualNovoHamburgo, percentualJuventude;
	cout << "Gremio: ";
	cin >> gremio;
	cout << "Internacional: ";
	cin >> internacional;
	cout << "Novo Hamburgo: ";
	cin >> novoHamburgo;
	cout << "Juventude: ";
	cin >> juventude;
	cout << "Nenhum: ";
	cin >> nenhum;
	double total = gremio + internacional + novoHamburgo + juventude + nenhum;
	percentualGremio = gremio / total;
	percentualInternacional = internacional / total;
	percentualNovoHamburgo = novoHamburgo / total;
	percentualJuventude = juventude / total;
	cout << "Percentual Gremio: " << percentualGremio << endl;
	cout << "Percentual Internacional: " << percentualInternacional << endl;
	cout << "Percentual NovoHamburgo: " << percentualNovoHamburgo << endl;
	cout << "Percentual Juventude: " << percentualJuventude << endl;

	// Problema 03
	int horasTrabalhadas;
	double valorDaHora, percentual, bruto, desconto, liquido;
	cout << "Horas trabalhadas: ";
	cin >> horasTrabalhadas;
	cout << "Valor da hora: ";
	cin >> valorDaHora;
	cout << "Percentual: ";
	cin >> percentual;
	bruto = horasTrabalhadas * valorDaHora;
	desconto = (percentual / 100) * bruto;
	liquido = bruto - desconto;
	cout << "Bruto: " << bruto << endl;
	cout << "Desconto: " << desconto << endl;
	cout << "Liquido: " << liquido << endl;
	// Problema 04
	double val1, val2;
	cout << "Valor 1: ";
	cin >> val1;
	cout << "Valor 2: ";
	cin >> val2;
	double temp;
	temp = val1;
	val1 = val2;
	val2 = temp;
	cout << "Valor 1: " << val1 << endl;
	cout << "Valor 2: " << val2 << endl;
	// Problema 05
	double val1, val2, val3, final;
	cout << "Valor 1: ";
	cin >> val1;
	cout << "Valor 2: ";
	cin >> val2;
	cout << "Valor 3: ";
	cin >> val3;
	final = 0.2 * val1 + 0.3 * val2 + 0.5 * val3;
	cout << "Final: " << final << endl;
	// Problema 06
	int hora1, minuto1, hora2, minuto2;
	cout << "Hora e minuto de entrada: ";
	cin >> hora1 >> minuto1;
	cout << "Hora e minuto de sa�da: ";
	cin >> hora2 >> minuto2;
	if (minuto2 < minuto1)
	{
		minuto2 += 60;
		hora2 -= 1;
	}
	int horas = hora2 - hora1;
	int minutos = minuto2 - minuto1;
	int tempo = horas * 60 + minutos;
	double valor = 0.10 * tempo;
	streamsize temp = cout.precision();
	cout << "Valor: " << fixed << setprecision(2) << valor << endl;
	setprecision(temp);// NAO FUNCIONANDO ****************************************************************************
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 07
	// Problema 01
	bool a = false;
	bool b = true;
	bool c = false;
	bool d;

	d = a && b;
	cout << d << endl;
	d = a || b;
	cout << d << endl;
	d = a && b && c;
	cout << d << endl;
	d = a && b || c;
	cout << d << endl;
	d = a || c && b;
	cout << d << endl;
	d = (a || c) && b;
	cout << d << endl;
	d = !a;
	cout << d << endl;
	d = a || !a;
	cout << d << endl;
	d = a && !a;
	cout << d << endl;
	d = a && !b && c;
	cout << d << endl;
	d = !(a && b) || !c;
	cout << d << endl;
	// Problema 02
	int x = 5;
	int y = 10;
	bool a = (x == y);
	bool b = (x != y);
	bool c = (x < 5);
	bool d = (x <= 5);
	bool e = (x <= y);
	bool f = (y >= x + 1);
	bool g;

	g = a && b;
	cout << g << endl;
	g = b && c || d;
	cout << g << endl;
	g = d || e && f;
	cout << g << endl;
	g = (d || e) && f;
	cout << g << endl;
	g = !e || e && f || !f;
	cout << g << endl;
	g = (!e || e) && (f || !f);
	cout << g << endl;
	g = !(e && !e) && !(a || !a);
	cout << g << endl;
	g = !(!a) && a;
	cout << g << endl;
	g = !(!(!b) || b);
	cout << g << endl;
	g = !(c || !d) && f || e;
	cout << g << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 08
	// Problema 01
	double val1, val2;
	cout << "Valor 1: ";
	cin >> val1;
	cout << "Valor 2: ";
	cin >> val2;
	if (val2 != 0)
	{
		cout << "Divis�o: " << val1 / val2 << endl;
	}
	else {
		cout << "Segundo valor n�o pode ser 0: " << endl;
	}
	// Problema 02
	double A, B, C;
	cout << "A: ";
	cin >> A;
	cout << "B: ";
	cin >> B;
	cout << "C: ";
	cin >> C;
	if ((A + B) < (A + C))
	{
		cout << "A+B < A+C " << endl;
	}
	else {
		cout << "A+B >= A+C " << endl;
	}
	// Problema 03
	double grauA, grauB, grauC, mediaFinal;
	cout << "A: ";
	cin >> grauA;
	cout << "B: ";
	cin >> grauB;
	mediaFinal = (grauA + 2 * grauB) / 3;
	cout << "M�dia final: " << mediaFinal << endl;
	if (mediaFinal >= 6.0)
	{
		cout << "Passou" << endl;
	}
	else {
		cout << "Em recupera��o" << endl;
		char rec;
		cout << "Recuperar a ou b?" << endl;
		cin >> rec;
		while (rec != 'a' && rec != 'b') {
			cout << "Recuperar a ou b?" << endl;
			cin >> rec;
		}
		cout << "C: ";
		cin >> grauC;
		if (rec == 'a') {
			mediaFinal = (grauC + 2 * grauB) / 3;
		}
		else {
			mediaFinal = (grauA + 2 * grauC) / 3;
		}
		cout << "M�dia final: " << mediaFinal << endl;
		if (mediaFinal >= 6.0)
		{
			cout << "Aprovado" << endl;
		}
		else {
			cout << "Reprovado" << endl;
		}
	}
	// Problema 04
	int num;
	cout << "N�mero: ";
	cin >> num;
	if (num % 2)
	{
		cout << "�mpar" << endl;
	}
	else {
		cout << "Par" << endl;
	}
	// Problema 05
	double A, B, C;
	cout << "A: ";
	cin >> A;
	cout << "B: ";
	cin >> B;
	if (A == B)
	{
		C = A + B;
	}
	else {
		C = A*B;
	}
	cout << "C: " << C << endl;
	// Problema 06
	double num;
	cout << "N�mero: ";
	cin >> num;
	if (num >= 0)
	{
		cout << "Dobro: " << 2 * num << endl;
	}
	else {
		cout << "Triplo: " << 3 * num << endl;
	}
	// Problema 07
	int num;
	cout << "N�mero: ";
	cin >> num;
	if (num % 2)
	{
		cout << "+8: " << num + 8 << endl;
	}
	else {
		cout << "+5: " << num + 5 << endl;
	}
	// Problema 08
	double altura;
	char sexo;
	cout << "Altura (m): ";
	cin >> altura;
	cout << "Sexo (f/m): ";
	cin >> sexo;
	if (sexo == 'f')
	{
		cout << "Peso ideal: " << (62.1 * altura) - 44.7 << endl;
	}
	else {
		cout << "Peso ideal: " << (72.7 * altura) - 58 << endl;
	}
	// Problema 09
	double peso, altura, IMC;
	cout << "Peso (kg): ";
	cin >> peso;
	cout << "Altura (m): ";
	cin >> altura;
	IMC = peso / (altura * altura);
	if (IMC < 18.5) {
		cout << "Abaixo do peso" << endl;
	}
	else if (IMC >= 18.5 && IMC <= 25.0) {
		cout << "Peso normal" << endl;
	}
	else if (IMC >= 25.0 && IMC <= 30.0) {
		cout << "Acima do peso" << endl;
	}
	else {
		cout << "Obeso" << endl;
	}
	// Problema 10
	double normal, final;
	int condicao;

	cout << "Normal: ";
	cin >> normal;
	cout << "Condi��o: ";
	cin >> condicao;
	if (condicao == 1) {
		final = 0.85 * normal;
		cout << "Final: " << final << endl;
	}
	else if (condicao == 2) {
		final = 0.90 * normal;
		cout << "Final: " << final << endl;
	}
	else if (condicao == 3) {
		final = normal;
		cout << "Final: " << final << endl;
	}
	else if (condicao == 4) {
		final = 1.10 * normal;
		cout << "Final: " << final << endl;
	}
	else {
		cout << "Condi��o inv�lida" << endl;
	}
	// Problema 11
	string nome;
	double nota1, nota2, nota3, media;

	cout << "Nota 1: ";
	cin >> nota1;
	cout << "Nota 2: ";
	cin >> nota2;
	cout << "Nota 3: ";
	cin >> nota3;
	media = 0.15*nota1 + 0.35*nota2 + 0.50*nota3;
	cout << "M�dia: " << media << endl;
	// Problema 12
	int idade;
	cout << "Idade: ";
	cin >> idade;
	if (idade >= 5 && idade <= 7) {
		cout << "Infantil A" << endl;
	}
	else if (idade >= 8 && idade <= 10) {
		cout << "Infantil B" << endl;
	}
	else if (idade >= 11 && idade <= 13) {
		cout << "Juvenil A" << endl;
	}
	else if (idade >= 14 && idade <= 17) {
		cout << "Juvenil B" << endl;
	}
	else if (idade >= 18) {
		cout << "S�nior" << endl;
	}
	else {
		cout << "Idade inv�lida" << endl;
	}
	// Problema 13
	int numeroMes;
	string nomeMes[] = {"Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
	cout << "N�mero do m�s: ";
	cin >> numeroMes;
	if (numeroMes >= 1 && numeroMes <= 12) {
		cout << nomeMes[numeroMes - 1] << endl;
	}
	else {
		cout << "M�s inv�lido" << endl;
	}
	// Problema 14
	double inicial, aumentado;
	cout << "Inicial: ";
	cin >> inicial;
	if (inicial >= 0.00 && inicial < 20.00) {
		aumentado = 1.45 * inicial;
		cout << "Aumentado: " << aumentado << endl;
	}
	else if (inicial >= 20.00 && inicial <= 50.00) {
		aumentado = 1.35 * inicial;
		cout << "Aumentado: " << aumentado << endl;
	}
	else if (inicial > 50.00) {
		aumentado = 1.25 * inicial;
		cout << "Aumentado: " << aumentado << endl;
	}
	else {
		cout << "Valor inv�lido" << endl;
	}
	// Problema 15
	int numeros[5];

	cout << "Cinco n�meros: ";
	for (int i = 0; i < 5; i++) {
		cin >> numeros[i];
	}
	int max = numeros[0];
	int min = numeros[0];
	for (int i = 1; i < 5; i++) {
		if (numeros[i] > max) {
			max = numeros[i];
		}
		if (numeros[i] < min) {
			min = numeros[i];
		}
	}
	cout << "Maior: " << max << endl;
	cout << "Menor: " << min << endl;
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 09
	// Problema 01
	int numero;

	cout << "N�mero: ";
	cin >> numero;
	if (numero % 3) {
		cout << numero << " n�o � divis�vel por 3" << endl;
	}
	else {
		cout << numero << " � divis�vel por 3" << endl;
	}
	// Problema 02
	int valor;
	cout << "Valor: ";
	cin >> valor;
	int notas[] = {1, 5, 10, 20, 50, 100};
	int quantidades[6];
	for (int i = 5; i >= 0; i--) {
		quantidades[i] = (int)floor(valor / notas[i]);
		valor -= (quantidades[i] * notas[i]);
		if (valor == 0) {
			break;
		}
	}
	for (int i = 5; i >= 0; i--) {
		cout << quantidades[i] << " nota(s) de R$" << notas[i] << endl;
	}
	// Problema 03
	int numeroMes;
	string nomeMes[] = { "Janeiro, Fevereiro, Mar�o, Abril, Maio, Junho, Julho, Agosto, Setembro, Outubro, Novembro, Dezembro" };

	cout << "N�mero do m�s: ";
	cin >> numeroMes;
	if (numeroMes >= 1 && numeroMes <= 12) {
		if (numeroMes == 12 || numeroMes == 1 || numeroMes == 2 || numeroMes == 6 || numeroMes == 7) {
			cout << "Alta" << endl;
		}
		else {
			cout << "Baixa" << endl;
		}
	}
	else {
		cout << "M�s inv�lido" << endl;
	}
	// Problema 04
	double valor = 220.00;
	int qntds[4];

	cout << "Crian�as com menos de 10 anos: ";
	cin >> qntds[0];
	valor += qntds[0] * 80.00;
	cout << "Dependentes com idade entre 10 e 30 anos: ";
	cin >> qntds[1];
	valor += qntds[1] * 150.00;
	cout << "Dependentes com idade entre 31 e 60 anos: ";
	cin >> qntds[2];
	valor += qntds[2] * 195.00;
	cout << "Dependentes com mais de 60 anos: ";
	cin >> qntds[3];
	valor += qntds[3] * 250.00;

	cout << "Valor: " << valor << endl;
	// Problema 05
	double valor;
	int mes;
	cout << "Valor: ";
	cin >> valor;
	cout << "Mes: ";
	cin >> mes;
	if (mes >= 1 && mes <= 12) {
		for (int i = 0; i < mes - 1; i++) {
			streamsize temp = cout.precision();
			valor *= 1.05;
			setprecision(temp);// NAO FUNCIONANDO ****************************************************************************
		}
		cout << "Valor: " << fixed << setprecision(2) << valor << endl; // Arrumar casas decimais
	}
	else {
		cout << "M�s inv�lido" << endl;
	}
	// Problema 06
	double valor, desconto;

	cout << "Valor: ";
	cin >> valor;
	desconto = 0.89 * valor;
	if (desconto > 318.20) {
		desconto = 318.20;
	}
	cout << "Desconto: " << desconto << endl;
	// Problema 07
	double cotacaoDolar, cotacaoEuro;
	cout << "Cota��o do d�lar (1 d�lar custa quantos reais?): ";
	cin >> cotacaoDolar;
	cout << "Cota��o do euro (1 euro custa quantos reais?): ";
	cin >> cotacaoEuro;
	char opcao = 'g';
	cout << "a) Converter de Real para Euro" << endl;
	cout << "b) Converter de Real para D�lar" << endl;
	cout << "c) Converter de Euro para D�lar" << endl;
	cout << "d) Converter de Euro para Real" << endl;
	cout << "e) Converter de D�lar para Euro" << endl;
	cout << "f) Converter de D�lar para Real" << endl;
	cin >> opcao;
	while ((int)opcao < (int)'a' || (int)opcao >(int)'f') {
		system("cls");
		cout << "a) Converter de Real para Euro" << endl;
		cout << "b) Converter de Real para D�lar" << endl;
		cout << "c) Converter de Euro para D�lar" << endl;
		cout << "d) Converter de Euro para Real" << endl;
		cout << "e) Converter de D�lar para Euro" << endl;
		cout << "f) Converter de D�lar para Real" << endl;
		cin >> opcao;
	}
	double valorReal, valorDolar, valorEuro;
	if (opcao == 'a') {
		cout << "Valor em reais: ";
		cin >> valorReal;
		valorEuro = valorReal / cotacaoEuro;
		cout << "Origem: " << valorReal << " Destino: " << valorEuro << endl;
	}
	else if (opcao == 'b') {
		cout << "Valor em reais: ";
		cin >> valorReal;
		valorDolar = valorReal / cotacaoDolar;
		cout << "Origem: " << valorReal << " Destino: " << valorDolar << endl;
	}
	else if (opcao == 'c') {
		cout << "Valor em euros: ";
		cin >> valorEuro;
		valorReal = valorEuro / cotacaoEuro;
		valorDolar = valorReal * cotacaoDolar;
		cout << "Origem: " << valorEuro << " Destino: " << valorDolar << endl;
	}
	else if (opcao == 'd') {
		cout << "Valor em euros: ";
		cin >> valorEuro;
		valorReal = valorEuro / cotacaoEuro;
		cout << "Origem: " << valorEuro << " Destino: " << valorReal << endl;
	}
	else if (opcao == 'e') {
		cout << "Valor em d�lares: ";
		cin >> valorDolar;
		valorReal = valorDolar / cotacaoDolar;
		valorEuro = valorReal * cotacaoEuro;
		cout << "Origem: " << valorDolar << " Destino: " << valorEuro << endl;
	}
	else {
		cout << "Valor em d�lares: ";
		cin >> valorDolar;
		valorReal = valorDolar / cotacaoDolar;
		cout << "Origem: " << valorDolar << " Destino: " << valorReal << endl;
	}
	// Problema 08

	int num = (rand() % 100) + 1;
	if (num % 2) {
		cout << num << " � �mpar" << endl;
	}
	else {
		cout << num << " � par" << endl;
	}
	// Problema 09
	int numeros[10];
	for (int i = 0; i < 10; i++) {
		numeros[i] = (rand() % 6) + 1;
	}
	cout << "N�meros: ";
	for (int i = 0; i < 10; i++) {
		cout << numeros[i] << " ";
	}
	cout << endl;
	// Problema 10
	int numeros[10];
	int lados;
	cout << "Lados: ";
	cin >> lados;
	for (int i = 0; i < 10; i++) {
		numeros[i] = (rand() % lados) + 1;
	}
	cout << "N�meros: ";
	for (int i = 0; i < 10; i++) {
		cout << numeros[i] << " ";
	}
	cout << endl;
	// Problema 11
	int computador, jogador;
	computador = (rand() % 5) + 1;
	cout << "1 Pedra" << endl;
	cout << "2 Papel" << endl;
	cout << "3 Tesoura" << endl;
	cout << "4 Lagarto" << endl;
	cout << "5 Spock" << endl;
	cin >> jogador;
	while (jogador < 1 || jogador > 5) {
		system("cls");
		cout << "1 Pedra" << endl;
		cout << "2 Papel" << endl;
		cout << "3 Tesoura" << endl;
		cout << "4 Lagarto" << endl;
		cout << "5 Spock" << endl;
		cin >> jogador;
	}
	cout << "Computador escolheu " << computador << endl;
	cout << "Jogador escolheu " << jogador << endl;
	if (computador == 1) {
		if (jogador == 3 || jogador == 4) {
			cout << "Computador venceu" << endl;
		}
		else {
			cout << "Jogador venceu" << endl;
		}
	}
	else if (computador == 2) {
		if (jogador == 1 || jogador == 5) {
			cout << "Computador venceu" << endl;
		}
		else {
			cout << "Jogador venceu" << endl;
		}
	}
	else if (computador == 3) {
		if (jogador == 2 || jogador == 4) {
			cout << "Computador venceu" << endl;
		}
		else {
			cout << "Jogador venceu" << endl;
		}
	}
	else if (computador == 4) {
		if (jogador == 2 || jogador == 5) {
			cout << "Computador venceu" << endl;
		}
		else {
			cout << "Jogador venceu" << endl;
		}
	}
	else {
		if (jogador == 1 || jogador == 3) {
			cout << "Computador venceu" << endl;
		}
		else {
			cout << "Jogador venceu" << endl;
		}
	}
	// Problema 12
	int numeros[3];
	bool ordenado = false;
	for (int i = 0; i < 3; i++) {
		numeros[i] = (rand() % 7) + 1;
	}
	cout << "N�meros: " << numeros[0] << " " << numeros[1] << " " << numeros[2] << endl;
	if (numeros[0] <= numeros[1] && numeros[1] <= numeros[2]) {
		cout << "Tr�s chicletes" << endl;
		ordenado = true;
	}
	else if (numeros[0] >= numeros[1] && numeros[1] >= numeros[2]) {
		cout << "Uma caixinha de suco artificial" << endl;
		ordenado = true;
	}
	if (numeros[0] == numeros[1] && numeros[1] == numeros[2]) {
		cout << "Uma caixa de bombom" << endl;
	}
	else if (numeros[0] == numeros[1] || numeros[0] == numeros[1] || numeros[1] == numeros[2]) {
		cout << "Uma bala" << endl;
	}
	else {
		if (!ordenado) {
			cout << "Nada" << endl;
		}
	}
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 10
	// Problema 01
	for (int i = 0; i <= 100; i++) {
		cout << i << " ";
	}
	cout << endl;
	for (int i = 20; i <= 50; i += 2) {
		cout << i << " ";
	}
	cout << endl;
	for (int i = 70; i >= 25; i--) {
		cout << i << " ";
	}
	cout << endl;
	for (int i = 95; i >= 25; i -= 2) {
		cout << i << " ";
	}
	cout << endl;
	int soma = 0;
	for (int i = 0; i < 15; i++) {
		cout << "N�mero: ";
		int temp;
		cin >> temp;
		soma += temp;
	}
	cout << "Soma: " << soma << endl;
	cout << "M�dia: " << soma / 15 << endl;
	int impares = 0;
	for (int i = 0; i < 10; i++) {
		cout << "N�mero: ";
		int temp;
		cin >> temp;
		if (temp % 2) {
			impares++;
		}
	}
	cout << "Pares: " << 10 - impares << endl;
	cout << "Impares: " << impares << endl;
	int positivos = 0;
	int negativos = 0;
	for (int i = 0; i < 20; i++) {
		cout << "N�mero: ";
		int temp;
		cin >> temp;
		if (temp > 0) {
			positivos++;
			cout << temp << " POSITIVO" << endl;
		}
		else if (temp < 0) {
			negativos++;
			cout << temp << " NEGATIVO" << endl;
		}
		else {
			cout << temp << " NULO" << endl;
		}
	}
	cout << "Positivos: " << positivos << endl;
	cout << "Negativos: " << negativos << endl;
	int qntd;
	cout << "Quantos? ";
	cin >> qntd;
	int soma = 0;
	for (int i = 0; i < qntd; i++) {
		int temp;
		cout << "N�mero: ";
		cin >> temp;
		soma += temp;
	}
	cout << "Soma dos " << qntd << " n�meros: " << soma << endl;
	// Problema 02
	int inferior, superior;
	cout << "Inferior: ";
	cin >> inferior;
	cout << "Superior: ";
	cin >> superior;
	for (int i = inferior; i <= superior; i++) {
		cout << i << " ";
	}
	cout << endl;
	// Problema 03
	int qntd;
	double geral = 0;
	cout << "Quantos? ";
	cin >> qntd;
	for (int i = 0; i < qntd; i++) {
		double grauA, grauB, media;
		cout << "Grau A: ";
		cin >> grauA;
		cout << "Grau B: ";
		cin >> grauB;
		media = (grauA + 2 * grauB) / 3;
		if (media >= 6.0) {
			cout << "APROVADO" << endl;
		}
		else {
			double grauC;
			char qual;
			cout << "Grau C: ";
			cin >> grauC;
			cout << "Qual grau aproveitado? ";
			cin >> qual;
			qual = toupper(qual);
			while (qual != 'A' && qual != 'B') {
				cout << "Grau C: ";
				cin >> grauC;
				cout << "Qual grau aproveitado? ";
				cin >> qual;
				qual = toupper(qual);
			}
			if (qual == 'A') {
				media = (grauC + 2 * grauB) / 3;
			}
			else {
				media = (grauA + 2 * grauC) / 3;
			}
			if (media >= 6.0) {
				cout << "APROVADO" << endl;
			}
			else {
				cout << "REPROVADO" << endl;
			}
		}
		geral += media;
	}
	cout << "M�dia geral: " << geral / qntd << endl;
	// Problema 04
	bool sair = false;
	int advogados = 0;
	do {
		string nome;
		cout << "Nome: ";
		cin >> nome;
		if (nome == "fim") {
			sair = true;
			break;
		}
		string profissao;
		cout << "Profiss�o: ";
		cin >> profissao;
		if (profissao == "advogado") {
			advogados++;
		}
	} while (!sair);
	cout << "O n�mero de advogados cadastrados � " << advogados << endl;
	// Problema 05
	int ultimo;
	cout << "�ltimo: ";
	cin >> ultimo;
	if (ultimo > 0) {
		bool impar = true;
		for (int i = 1; i <= ultimo; i++) {
			cout << i << " elefante ";
			if (impar) {
				if (i != 1) {
					cout << "incomodam muita gente" << endl;
				}
				else {
					cout << "incomoda muita gente" << endl;
				}
			}
			else {
				cout << "incomodam";
				for (int j = 0; j < i; j++) {
					cout << ", incomodam";
				}
				cout << " muito mais" << endl;
			}
			impar = !impar;
		}
	}
	else {
		cout << "N�mero inv�lido" << endl;
	}
	// Problema 06
	int numero;
	long int fatorial = 1;
	do {
		cout << "Entre com um n�mero: ";
		cin >> numero;
		if (numero > 1) {
			for (int i = numero; i > 1; i++) {
				fatorial *= i;
			}
		}
		cout << "O fatorial de " << numero << " � " << fatorial << endl;
		cout << "Calcular outro n�mero (s/n)? ";
		cin >> sair;
		while (sair != 's' && sair != 'n') {
			cout << "Calcular outro n�mero (s/n)? ";
			cin >> sair;
		}
	} while (sair != 'n');
	// Problema 07
	int linhas;
	char caractere;
	cout << "Linhas: ";
	cin >> linhas;
	cout << "Caractere: ";
	cin >> caractere;
	for (int i = 0; i < linhas; i++) {
		string saida = "";
		for (int j = 0; j < i; j++) {
			saida += caractere;
		}
		cout << saida << endl;
	}
	// Problema 08
	int linhas;
	char caractere;
	cout << "Linhas: ";
	cin >> linhas;
	while (!(linhas % 2)) {
		cout << "Linhas: ";
		cin >> linhas;
	}
	cout << "Caractere: ";
	cin >> caractere;
	for (int i = 1; i < linhas; i += 2) {
		string saida = "";
		for (int j = 0; j < i; j++) {
			saida += caractere;
		}
		cout << saida << endl;
	}
	for (int i = linhas - 2; i > 0; i -= 2) {
		string saida = "";
		for (int j = 0; j < i; j++) {
			saida += caractere;
		}
		cout << saida << endl;
	}
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 11
	// Problema 01
	for (int i = 0; i < 10; i++) {
		cout << "Meu nome" << endl;
	}
	// Problema 02
	string nomes[5];
	for (int i = 0; i < 5; i++) {
		cout << "Nome: ";
		cin >> nomes[i];
	}
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < i; j++) {
			if (strcmp(nomes[i].c_str(), nomes[j].c_str()) == -1) {
				string temp = nomes[i];
				nomes[i] = nomes[j];
				nomes[j] = temp;
			}
		}
	}
	cout << "Nome: " << nomes[0] << endl;
	// Problema 03
	for (int i = 0; i < 10; i++) {
		cout << i << " ";
	}
	for (int i = -6; i < 4; i++) {
		cout << i << " ";
	}
	for (int i = 2; i <= 20; i += 2) {
		cout << i << " ";
	}
	for (int i = 4; i <= 40; i += 4) {
		cout << i << " ";
	}
	//e. Os �ltimos dez n�meros positivos inteiros. ?????????????????????????????????
	// Problema 04
	double soma = 0.0;
	double menor = 10.0;
	double maior = 0.0;
	for (int i = 0; i < 15; i++) {
		cout << "Nota: ";
		double temp;
		cin >> temp;
		soma += temp;
		if (temp > maior) {
			maior = temp;
		}
		if (temp < menor) {
			menor = temp;
		}
	}
	cout << "Menor: " << menor << endl;
	cout << "Naior: " << maior << endl;
	cout << "M�dia: " << soma / 15 << endl;
	// Problema 05
	string nome;
	int idade;
	char sexo;
	for (int i = 0; i < 10; i++) {
		cout << "Nome: ";
		cin >> nome;
		cout << "Idade: ";
		cin >> idade;
		cout << "Sexo: ";
		cin >> sexo;
		if ((sexo == 'f') && (idade <= 12 || idade >= 59)) {
			cout << "nome est� apta" << endl;
		}
		else {
			cout << "nome n�o est� apta" << endl;
		}
	}
	// Problema 06
	int numero = (rand() % 10) + 1;
	for (int i = 0; i < 3; i++) {
		cout << "Palpite: ";
		cin >> palpite;
		if (numero == palpite) {
			cout << "Acertou" << endl;
			break;
		}
		else {
			if (numero < palpite) {
				cout << "Menos" << endl;
			}
			else {
				cout << "Mais" << endl;
			}
		}
	}
	// Problema 07
	int numero;
	char sair;
	do {
		cout << "N�mero: ";
		cin >> numero;
		for (int i = 1; i <= 10; i++) {
			cout << numero << " x " << i << " = " << numero * i;
		}
		cout << "Sair? (s/n) ";
		cin >> sair;
		while (sair != 's' && sair != 'n') {
			cout << "Sair? (s/n) ";
			cin >> sair;
			cin >> sair;
		}
	} while (!sair);
	// Problema 08
	int divisor, inicio, fim
		int primeiro;
	cout << "Divisor: ";
	cin >> divisor;
	cout << "Inicio: ";
	cin >> inicio;
	cout << "Fim: ";
	cin >> fim;
	for (int i = inicio; i <= fim; i++) {
		if (i % divisor == 0) {
			primeiro = i;
			break;
		}
	}
	cout << "Divis�veis: ";
	for (int i = primeiro; i <= fim; i += divisor) {
		cout << i << " ";
	}
	// Problema 09
	int opcao;
	do {
		cout << "Programa com Menu:" << endl;
		cout << "1 - Fazer coisa 1" << endl;
		cout << "2 - Fazer coisa 2" << endl;
		cout << "3 - Fazer coisa 3" << endl;
		cout << "4 - Sair do programa" << endl;
		cout << "Programa com Menu: ";
		cin >> opcao;
		while (opcao < 1 && opcao > 4) {
			cout << "Programa com Menu:" << endl;
			cout << "1 - Fazer coisa 1" << endl;
			cout << "2 - Fazer coisa 2" << endl;
			cout << "3 - Fazer coisa 3" << endl;
			cout << "4 - Sair do programa" << endl;
			cout << "Programa com Menu: ";
			cin >> opcao;
		}
		if (opcao == 1) {
			cout << "Executando op��o 1" << endl;
		}
		else if (opcao == 2) {
			cout << "Executando op��o 2" << endl;
		}
		else if (opcao == 3) {
			cout << "Executando op��o 3" << endl;
		}
	} while (opcao != 4);
	// Problema 10
	int numero;
	cout << "N�mero: ";
	cin >> numero;
	do {
		cout << numero << " ";
		numero *= 3;
	} while (numero < 150);
	// Problema 11
	int votos[] = { 0,0,0,0,0,0 };
	char opcao, voto;
	string candidatos[] = { "K � Kirby", "L � Link", "M � Mario", "S � Sonic", "B - branco", "N - nulo" };
	do {
		cout << "(V)otar" << endl;
		cout << "(T)erminar a vota��o" << endl;
		cin >> opcao;
		while (opcao != 'v' && opcao != 't') {
			cout << "Op��o inv�lida" << endl;
			cout << "(V)otar" << endl;
			cout << "(T)erminar a vota��o" << endl;
			cin >> opcao;
		}
		if (opcao == 'v') {
			cout << "Candidatos ";
			for (int i = 0; i < 6; i++) {
				cout << candidatos[i];
			}
			cout << "Voto: " << endl;
			cin >> voto;
			while (voto != 'K' && voto != 'L' && voto != 'M' && voto != 'S' && voto != 'B' && voto != 'N') {
				cout << "Voto inv�lido" << endl;
				cout << "Candidatos ";
				for (int i = 0; i < 6; i++) {
					cout << candidatos[i];
				}
				cout << "Voto: " << endl;
				cin >> voto;
			}
			if (voto == 'K') {
				votos[0]++;
			}
			else if (voto == 'L') {
				votos[1]++;
			}
			else if (voto == 'M') {
				votos[2]++;
			}
			else if (voto == 'S') {
				votos[3]++;
			}
			else if (voto == 'B') {
				votos[4]++;
			}
			else {
				votos[5]++;
			}
			cout << "Obrigado" << endl;
		}
		else {
			for (int i = 0; i < 6; i++) {
				cout << "Votos para " << candidatos[i] << ": " << votos[i] << endl;
			}
			int votosVencedor = votos[0];
			for (int i = 1; i < 6; i++) {
				if (votos[i] > votosVencedor) {
					votosVencedor = votos[i];
				}
			}
			int vencedores = 0;
			for (int i = 0; i < 6; i++) {
				if (votos[i] == votosVencedor) {
					vencedores++;
				}
			}
			if (vencedores == 1) {
				for (int i = 0; i < 4; i++) {
					if (votos[i] == votosVencedor) {
						cout << "O vencedor � " << candidatos[i] << endl;
					}
				}
			}
			else if () {
				cout << "Vencedor indefinido" << endl;
			}
		}
	} while (opcao != 'v');
	// Problema 12
	char sexo;
	int idade, quantidade, quantidadeCriancas = 0, quantidadeMulheres = 0, idadeHomens = 0, quantidadeHomens = 0, quantidadeNenhum = 0, total = 0;
	do {
		cout << "Sexo: ";
		cin >> sexo;
		cout << "Idade: ";
		cin >> idade;
		cout << "Quantidade: ";
		cin >> quantidade;
		if (idade == 0) {
			break;
		}
		else {
			if (idade < 10) {
				quantidadeCriancas += quantidade;
			}
			if (sexo == 'f' && quantidade >= 5) {
				quantidadeMulheres++;
			}
			if (sexo == 'm' && quantidade < 5) {
				idadeHomens += idade;
				quantidadeHomens++;
			}
			if (quantidade == 0) {
				quantidadeNenhum++;
			}
			total++;
		}
	} while (idade != 0);
	cout << "Total de livros lidos pelos entrevistados menores de 10 anos: " << quantidadeCriancas << endl;
	cout << "Quantidade de mulheres que leram 5 livros ou mais: " << quantidadeMulheres << endl;
	cout << "M�dia de idade dos homens que leram menos que 5 livros: " << idadeHomens / quantidadeHomens << endl;
	cout << "Percentual de pessoas que n�o leram livros: " << quantidadeNenhum / total << endl;*/
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 13
	// Problema 01
	/*
	double matriz[4][4];
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << "Elemento " << i + 1 << "," << j + 1 << endl;
			cin >> matriz[i][j];
		}
	}
	double soma = 0;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			soma += matriz[i][j];
		}
	}
	cout << "Soma de todos os elementos: " << soma << endl;
	double somaSegundaLinha = 0;
	for (int j = 0; j < 4; j++)
	{
		somaSegundaLinha += matriz[1][j];
	}
	cout << "Soma dos elementos da segunda linha: " << somaSegundaLinha << endl;
	double somaTerceiraColuna = 0;
	for (int j = 0; j < 4; j++)
	{
		somaTerceiraColuna += matriz[j][2];
	}
	cout << "Soma dos elementos da terceira coluna: " << somaTerceiraColuna << endl;
	string diagonalPrincipal = "";
	for (int j = 0; j < 4; j++)
	{
		diagonalPrincipal += to_string(matriz[j][j]) + " ";
	}
	cout << "Diagonal principal: " << diagonalPrincipal << endl;
	string diagonalSecundaria = "";
	for (int j = 0; j < 4; j++)
	{
		diagonalSecundaria += to_string(matriz[j][3-j]) + " ";
	}
	cout << "Diagonal secund�ria: " << diagonalSecundaria << endl;
	// Problema 02
	double valores[6][3];
	double totalCadaDia[6] = { 0.0 };
	double valorMaiorVenda = 0.0;
	string dias[] = { "segunda", "ter�a", "quarta", "quinta", "sexta", "sabado" };
	string turnos[] = { "manh�", "tarde", "noite" };
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << turnos[j] + " de " + dias[i] << endl;
			cin >> valores[i][j];
			totalCadaDia[i] += valores[i][j];
			if (valores[i][j] > valorMaiorVenda)
			{
				valorMaiorVenda = valores[i][j];
			}
		}
	}
	double valorMenorVenda = 0.0;
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (valores[i][j] < valorMenorVenda)
			{
				valorMenorVenda = valores[i][j];
			}
		}
	}
	for (int i = 0; i < 6; i++)
	{
		cout << dias[i] << ": " << to_string(totalCadaDia[i]) << endl;
	}
	// Problema 03

	// Problema 04
	int n;
	cout << "n: " << endl;
	cin >> n;
	while (n == 0 || n > 10)
	{
		cout << "n deve ser entre 1 e 10" << endl;
		cout << "n: " << endl;
		cin >> n;
	}
	vector<vector<int>> matriz;
	for (int i = 0; i < n; i++)
	{
		vector<vector<int>> temp;
		for (int j = 0; j < n; j++)
		{
			temp.push_back(j);
		}
		matriz.push_back(temp);
	}
	for (int i = 0; i < n; i++)
	{
		int max = matriz[i][0];
		for (int j = 1; j < n; j++)
		{
			if (matriz[i][j] > max)
			{
				max = matriz[i][j];
			}
		}
		int temp = max;
		max = matriz[i][i];
		matriz[i][i] = temp;
	}
	// Problema 05
	int n, m;
	cout << "n: " << endl;
	cin >> n;
	cout << "m: " << endl;
	cin >> m;
	int matriz[4][4];
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << "Elemento " << i + 1 << "," << j + 1 << endl;
			cin >> matriz[i][j];
		}
	}
	int linhasNulas = 0, colunasNulas = 0;
	for (int i = 0; i < n; i++)
	{
		int cont = 0;
		for (int j = 0; j < m; j++)
		{
			if (matriz[i][j] == 0)
			{
				cont++;
			}
		}
		if (cont == m)
		{
			linhasNulas++;
		}
	}
	for (int i = 0; i < m; i++)
	{
		int cont = 0;
		for (int j = 0; j < n; j++)
		{
			if (matriz[j][i] == 0)
			{
				cont++;
			}
		}
		if (cont == n)
		{
			colunasNulas++;
		}
	}
	cout << "Tem " + to_string(linhasNulas) + " linhas nulas e " + to_string(colunasNulas) + " colunas nulas." << endl;
	*/
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 14
	// Problema 01
	/*char matriz[12][5];

	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			matriz[i][j] = (char)(65 + rand() % 26);
		}
	}
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			cout << matriz[i][j];
		}
		cout << endl;
	}*/
	// Problema 02
	/*int matriz[7][5];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			matriz[i][j] = (78 + rand() % 88);
			std::cout << std::to_string(matriz[i][j]) + " ";
		}
		std::cout << std::endl;
	}
	int maiorNumeroImpar = matriz[0][0], menorNumeroPar = matriz[0][0];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (matriz[i][j] % 2)
			{
				if (matriz[i][j] > maiorNumeroImpar)
				{
					maiorNumeroImpar = matriz[i][j];
				}

			}
			else
			{
				if (matriz[i][j] < menorNumeroPar)
				{
					menorNumeroPar = matriz[i][j];
				}
			}
		}

	}
	std::cout << "Maior numero impar: " + std::to_string(maiorNumeroImpar) + "\nMenor numero par: " + std::to_string(menorNumeroPar);
	std::cout << std::endl;*/
	// Problema 03
	/*std::string nomes[15];
	float notas[15][3];

	for (int i = 0; i < 15; i++)
	{
		std::cout << "Nome do aluno " + std::to_string(i + 1) + ": ";
		std::cin >> nomes[i];
	}
	for (int i = 0; i < 15; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			std::cout << "Nota " + std::to_string(j + 1) + " do aluno " + nomes[i] + ": ";
			std::cin >> notas[i][j];
		}
	}
	for (int i = 0; i < 15; i++)
	{
		float temp = 0;
		for (int j = 0; j < 3; j++)
		{
			temp += notas[i][j];
		}
		temp /= 3;
		std::cout << "A media do aluno " + std::to_string(i + 1) + " eh " + std::to_string(temp) << std::endl;
	}*/
	// Problema 04
	/*std::string nomes1[5];
	int pontuacoes1[5];
	for (int i = 0; i < 5; i++)
	{
		std::cout << "Nome do jogador " << (i + 1) << ": ";
		std::cin >> nomes1[i];
		std::cout << "Pontuacao do jogador " + nomes1[i] + ": ";
		std::cin >> pontuacoes1[i];
	}
	std::ofstream arqOut("pontuacao.txt");
	if (arqOut.is_open())
	{
		for (int i = 0; i < 5; i++)
		{
			arqOut << "Nome: " + nomes1[i] + "\n";
			arqOut << "Pontuacao: " + std::to_string(pontuacoes1[i]) + "\n";
		}
		arqOut.close();
	}
	std::string nomes2[5];
	std::string temp;
	int pontuacoes2[5];
	std::ifstream arqIn("pontuacao.txt");
	if (arqIn.is_open())
	{
		for (int i = 0; i < 5; i++)
		{
			std::getline(arqIn, temp);
			nomes2[i] = temp.substr(temp.find(": ") + 1);
			std::getline(arqIn, temp);
			pontuacoes2[i] = stoi(temp.substr(temp.find(": ") + 1));
		}
		arqIn.close();
	}
	for (int i = 0; i < 5; i++)
	{
		std::cout << "Nome: " + nomes2[i] + "\tPontuacao: " + std::to_string(pontuacoes2[i]) + "\n";
	}*/
	// Problema 05
	/*std::string palavra;
	int cont = 0;
	std::ifstream arq;

	std::cout << "Palavra: ";
	std::cin >> palavra;
	arq.open("palavras.txt");
	if (arq.is_open())
	{
		std::string temp;
		while (arq >> temp)
		{
			if (temp == palavra)
			{
				cont++;
			}
		}
		arq.close();
		if (cont == 0)
		{
			std::cout << "A palavra " + palavra + " n�o foi encontrada." << std::endl;
		}
		else
		{
			std::cout << "Foram encontradas " + std::to_string(cont) + " ocorr�ncias da palavra " + palavra + "." << std::endl;
		}
	}*/
	// Problema 06
	//int cont = 0;
	//std::ifstream arq("palavras.txt");
	//if (arq.is_open())
	//{
	//	std::string temp;
	//	while (arq >> temp)
	//	{
	//		cont++;
	//	}
	//	arq.close();
	//	std::cout << "O arquivo tem " + std::to_string(cont) + " palavras." << std::endl;
	//}
	// Problema 07
	/*std::string nomeArq;
	std::cout << "Nome do arquivo: ";
	std::cin >> nomeArq;

	int chave;
	do {
		std::cout << "Chave de ate 4 digitos: ";
		std::cin >> chave;
	} while (chave >= 10000);

	char op;
	do {
		std::cout << "c - Criptografia, d - Decriptografia: ";
		std::cin >> op;
	} while (tolower(op) != 'c' && tolower(op) != 'd');

	std::ifstream arqIn(nomeArq);
	if (arqIn.is_open())
	{
		std::string temp((std::istreambuf_iterator<char>(arqIn)), std::istreambuf_iterator<char>());
		arqIn.close();
		if (op == 'c')
		{
			for (int i = 0; i < temp.size(); i++)
			{
				temp[i] = temp[i] + (chave % 256);
			}
		}
		else
		{
			for (int i = 0; i < temp.size(); i++)
			{
				temp[i] = temp[i] - (chave % 256);
			}
		}
		std::cout << temp << std::endl;
		std::ofstream arqOut(nomeArq);
		if (arqOut.is_open())
		{
			arqOut << temp;
			arqOut.close();
		}
	}
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 16
	// Problema 01
	int *ptr;
	// Problema 02
	int ch = 10;
	int *indica = &ch;
	cout << (*indica) << " " << (ch) << endl;
	// Problema 03
	int num = 10;
	int *pnum = &num;
	cout << (num) << " " << (*pnum) << endl;
	// Problema 04
	int x = 10;
	int *px = &x;
	cout << "Novo valor para x: ";
	cin >> *px;
	cout << "Valor de x: " << x << endl;
	// Problema 05
	int j, *pj;
	pj = &j;
	*pj = 3;
	cout << "Valor de j: " << j << endl;
	// Problema 06
	int x = 10;
	int *px = &x;
	cout << "Valor de 5 * x: " << 5 * *px << endl;
	// Problema 07
	int i = 3, j = 5;
	int *p = &i, *q = &j;
	cout << (p == &i) << endl;
	cout << (*p - *q) << endl;
	cout << (**&p) << endl;
	// Problema 08
	int i = 5, *p = &i;
	cout << p << " " << *p + 2 << " " << **&p << " " << 3 * *p << " " << **&p + 4 << endl;
	// Problema 09
	int i = 3, j = 5;
	int *p = &i, *q = &j;
	p = &i;
	p = &*&i;
	i = *&j;
	i = *&*&j;
	i = (*p)++ + *q;
	// Problema 10
	int *pti;
	int i = 10;
	pti = &i;
	// pti != 10
	// Problema 11
	int x, *ptx, **px;
	float f, *ptf, **pf;
	x = 100;
	*pf = &f;
	cout << f << " " << **pf << endl;
	**pf = 7.9;
	cout << f << " " << **pf << endl;
	ptx = &x;
	*ptx = 20;
	pf = &ptf;*/
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	// Lista 17
	// Problema 01
	Vetor v;
	v = Vetor();
	v.alocar(6);
	v.ler();
	v.imprimir();
	v.alocar(4);
	v.ler();
	v.imprimir();
	v.desalocar();
	// Problema 02
	//Vetor v;
	v = Vetor();
	std::string nomeArquivo = "batata.txt";
	v.alocar(2);
	v.ler();
	v.salvarArquivo(nomeArquivo);
	v.imprimir();
	v.lerArquivo(nomeArquivo);
	v.desalocar();
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------
	system("pause");
	return 0;
}