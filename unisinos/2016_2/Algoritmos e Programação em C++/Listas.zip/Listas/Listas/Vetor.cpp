#include "Vetor.h"

Vetor::Vetor()
{
	tamanho = 0;
}

Vetor::~Vetor()
{
}

void Vetor::alocar(int novoTamanho)
{
	if (novoTamanho > 0) {
		if (tamanho == 0) {
			vetor = new int[novoTamanho];
			tamanho = novoTamanho;
		} else if (tamanho > novoTamanho) {
			int *temp = new int[novoTamanho];
			for (int i = 0; i < novoTamanho; i++) {
				temp[i] = vetor[i];
			}
			delete[] vetor;
			vetor = temp;
			tamanho = novoTamanho;
		} else if (tamanho < novoTamanho) {
			int *temp = new int[novoTamanho];
			for (int i = 0; i < tamanho; i++) {
				temp[i] = vetor[i];
			}
			delete[] vetor;
			vetor = temp;
			tamanho = novoTamanho;
		}
	}
}

void Vetor::desalocar()
{
	delete[] vetor;
	tamanho = 0;
}

void Vetor::ler()
{
	if (tamanho > 0) {
		for (int i = 0; i < tamanho; i++) {
			std::cout << "Novo valor da posicao " << (i + 1) << ": ";
			std::cin >> vetor[i];
		}
	}
	else {
		std::cout << "Vetor eh vazio" << std::endl;
	}
}

void Vetor::imprimir()
{
	if (tamanho > 0) {
		for (int i = 0; i < tamanho; i++) {
			std::cout << "Valor da posicao " << (i + 1) << ": " << vetor[i] << std::endl;
		}
	}
	else {
		std::cout << "Vetor eh vazio" << std::endl;
	}
}

void Vetor::salvarArquivo(std::string nomeArquivo)
{
	std::ofstream file;
	file.open(nomeArquivo);
	file << tamanho << std::endl;
	for (int i = 0; i < tamanho; i++) {
		file << vetor[i] << std::endl;
	}
	file.close();
}

void Vetor::lerArquivo(std::string nomeArquivo)
{
	std::string line;
	std::ifstream file(nomeArquivo);
	if (file.is_open())
	{
		int tam = -1;
		if (std::getline(file, line)) {
			tam = stoi(line);
			if (tam > 0) {
				int *vet = new int[tam];
				for (int i = 0; i < tam; i++) {
					std::getline(file, line);
					vet[i] = stoi(line);
				}
				delete vetor;
				*vetor = *vet;
				delete vet;
				tamanho = tam;
			}
			else if (tam == 0) {
				std::cout << "Vetor lido eh vazio" << std::endl;
			}
			else
			{
				std::cout << "Formato errado de arquivo" << std::endl;
			}
		}
		else
		{
			std::cout << "Falha na leitura" << std::endl;
		}
		file.close();
	}
}
