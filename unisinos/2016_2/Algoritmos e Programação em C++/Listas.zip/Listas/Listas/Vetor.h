#include <iostream>
#include <fstream>
#include <string>
#pragma once

class Vetor
{
	public:
		Vetor();
		~Vetor();
		
		void alocar(int novoTamanho);
		void desalocar();
		void ler();
		void imprimir();
		void salvarArquivo(std::string nomeArquivo);
		void lerArquivo(std::string nomeArquivo);
	private:
		int tamanho;
		int *vetor;
};
