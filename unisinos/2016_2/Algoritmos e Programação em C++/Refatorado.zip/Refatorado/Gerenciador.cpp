#include "Gerenciador.h"

int Gerenciador::sortearGinasio()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			xGinasio = sortearX(ginasio.getSprites()[0].getLargura());
			int forca = sortearForca();
			ginasio.inicializar(xGinasio, ++yGinasio, forca);
			return forca;
		}
	}
	return -1;
}

int Gerenciador::sortearLetrao()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			int sorteado = rand() % 7;
			xLetrao = sortearX(letrao.getSprite().getLargura());
			letrao.inicializar(xLetrao, ++yLetrao);
			letrao.getSprite().setFrame(sorteado);
			return sorteado;
		}
	}
	return -1;
}

int Gerenciador::sortearOvo()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			xOvo = sortearX(ovo.getSprite().getLargura());
			int km = rand() % 3;
			ovo.inicializar(xOvo, ++yOvo, km);
			return km;
		}
	}
	return -1;
}

int Gerenciador::sortearPokebola()
{
	if ((rand() % 60) == 0)
	{
		int sorteado3 = rand() % 40;
		int sorteado2 = rand() % 20;
		int sorteado1 = rand() % 10;
		if (sorteado3 == 0) {
			int novoPoder = 2;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 2;
		}
		if (sorteado2 == 0) {
			int novoPoder = 1;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 1;
		}
		if (sorteado1 == 0) {
			int novoPoder = 0;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 0;
		}
	}
	return -1;
}

void Gerenciador::sortearPokecoin()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			xPokecoin = sortearX(pokecoin.getSprite().getLargura());
			pokecoin.inicializar(xPokecoin, ++yPokecoin);
		}
	}
}

int Gerenciador::sortearPokemon()
{
	while (true)
	{
		int sorteado = rand() % (10 * 15);
		if (isPokemonMostrado[sorteado] == false)
		{
			isPokemonMostrado[sorteado] = true;
			quantidadeMostradaAtual++;
			return sorteado;
		}
	}
}

/*
evolucao	poder
0			[0,1,2]
1			[1,2]
2			[2]
*/
int Gerenciador::sortearPoder(int evolucao)
{
	return (rand() % (3 - evolucao)) + evolucao;
}

void Gerenciador::sortearPokestop()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			xPokestop = sortearX(pokestop.getSprite().getLargura());
			pokestop.inicializar(xPokestop, ++yPokestop);
		}
	}
}

void Gerenciador::sortearRocket()
{
	if ((rand() % 1) == 0)
	{
		int sorteado = rand() % 2;
		if (sorteado == 0) {
			xRocket[0] = sortearX(rocket.getSprites()[0].getLargura());
			xRocket[1] = sortearX(rocket.getSprites()[1].getLargura());
			rocket.inicializar(xRocket[0], xRocket[1], ++yRocket);
			return;
		}
	}
}

void Gerenciador::sortearVida()
{
	if ((rand() % 60) == 0)
	{
		if ((rand() % 3) == 0) {
			xVida = sortearX(vida.getSprite().getLargura());
			vida.inicializar(xVida, ++yVida);
		}
	}
}

int Gerenciador::sortearX(int largura)
{
	return ((rand() % (gJanela.getLargura() - largura)) + floor(largura / 2));
}

int Gerenciador::sortearForca()
{
	return (rand() % 5);
}

void Gerenciador::atualizarGinasio()
{
	ginasio.atualizar();
}

void Gerenciador::atualizarLetrao()
{
	letrao.atualizar();
}

void Gerenciador::atualizarOvo()
{
	ovo.atualizar();
}

void Gerenciador::atualizarPokebola()
{
	pokebola.atualizar();
}

void Gerenciador::atualizarPokecoin()
{
	pokecoin.atualizar();
}

void Gerenciador::atualizarPokemon()
{
	for (int i = 0; i < (int)(idsAtuais.size()); i++)
	{
		pokemons[idsAtuais[i]].atualizar();
	}
}

void Gerenciador::atualizarPokestop()
{
	pokestop.atualizar();
}

void Gerenciador::atualizarRocket()
{
	rocket.atualizar();
}

void Gerenciador::atualizarVida()
{
	vida.atualizar();
}

void Gerenciador::desenharGinasio()
{
	ginasio.desenhar();
}

void Gerenciador::desenharLetrao()
{
	letrao.desenhar();
}

void Gerenciador::desenharOvo()
{
	ovo.desenhar();
}

void Gerenciador::desenharPokebola()
{
	pokebola.desenhar();
}

void Gerenciador::desenharPokecoin()
{
	pokecoin.desenhar();
}

void Gerenciador::desenharPokemon()
{
	for (int i = 0; i < (int)(idsAtuais.size()); i++)
	{
		pokemons[idsAtuais[i]].desenhar();
	}
}

void Gerenciador::desenharPokestop()
{
	pokestop.desenhar();
}

void Gerenciador::desenharRocket()
{
	rocket.desenhar();
}

void Gerenciador::desenharVida()
{
	vida.desenhar();
}

Gerenciador::Gerenciador()
{
}

Gerenciador::~Gerenciador()
{
}

void Gerenciador::inicializar()
{
	// Inicializar Rocket
	xRocket[2];
	yRocket = -1;
	rocket.setY(-1);

	// Inicializar Ginasio
	xGinasio = -1;
	yGinasio = -1;
	ginasio.setY(-1);
	forcaGinasioAtual = -1;

	// Inicializar Letroes
	xLetrao = -1;
	yLetrao = -1;
	letrao.setY(-1);

	// Inicializar Ovos
	xOvo = -1;
	yOvo = -1;
	ovo.setY(-1);
	codKmOvo = -1;

	// Inicializar Pokebola
	xPokebola = -1;
	yPokebola = -1;
	poderPokebola = -1;
	pokebola.setY(-1);

	// Inicializar Pokecoin
	xPokecoin = -1;
	yPokecoin = -1;
	pokecoin.setY(-1);

	// Inicializar Pokemon
	xPokemon = -1;
	yPokemon = -1;
	quantidadeMostradaAtual = 0;
	quantidadeDePokemonsPorVez = 1;
	for (int i = 0; i < 10 * 15; i++)
	{
		isPokemonMostrado[i] = false;
	}
	/*sprite.setSpriteSheet("pokemons");
	sprite.setVelocidadeAnimacao(0);
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			pokemons[15 * i + j].setSprite(sprite);
		}
	}*/
	idsAtuais.clear();
	posxAtuais.clear();
	poderesAtuais.clear();
	for (int i = 0; i < 10 * 15; i++)
	{
		pokemons[i].setY(-1);
	}

	// Inicializar Pokestop
	xPokestop = -1;
	yPokestop = -1;
	pokestop.setY(-1);

	// Inicializar Vida
	xVida = -1;
	yVida = -1;
	vida.setY(-1);
}

void Gerenciador::gerenciar(Jogador * jogadores, int tempo)
{
	// Gerenciar Rocket
	if (rocket.getY() >= 0 && rocket.getY() <= gJanela.getAltura())
	{
		if (rocket.getY() - rocket.getSprites()[0].getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			rocket.setY(yRocket = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, rocket.getSprites()[0], (float)(rocket.getXs()[0]), (float)(rocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].variarPontos(50);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-50);
				//jogadores[0].variarHP(-50);
				jogadores[0].getSomAtacado().tocar();

				/*int sorteado = rand() % 150;
				while (jogadores[0].getPegouPokemons()[sorteado] == false)
				{
					sorteado = rand() % 150;
				}
				jogadores[0].setPegouPokemons(sorteado, false);
				for (int i = 0; i < 3; i++)
				{
					jogadores[0].setPokebolas(i, jogadores[0].getPokebolas()[i] - (rand() % (jogadores[0].getPokebolas()[i] + 1)));
				}
				jogadores[0].setPokecoins(jogadores[0].getPokecoins() - (rand() % (jogadores[0].getPokecoins() + 1)));
				jogadores[0].setPontos(jogadores[0].getPontos() - 10 * (rand() % ((jogadores[0].getPontos() / 10) + 1)));*/
			}
			rocket.setY(yRocket = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, rocket.getSprites()[1], (float)(rocket.getXs()[1]), (float)(rocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].variarPontos(50);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-50);
				//jogadores[0].variarHP(-50);
				jogadores[0].getSomAtacado().tocar();

				/*int sorteado = rand() % 150;
				while (jogadores[0].getPegouPokemons()[sorteado] == false)
				{
					sorteado = rand() % 150;
				}
				jogadores[0].setPegouPokemons(sorteado, false);
				for (int i = 0; i < 3; i++)
				{
					jogadores[0].setPokebolas(i, jogadores[0].getPokebolas()[i] - (rand() % (jogadores[0].getPokebolas()[i] + 1)));
				}
				jogadores[0].setPokecoins(jogadores[0].getPokecoins() - (rand() % (jogadores[0].getPokecoins() + 1)));
				jogadores[0].setPontos(jogadores[0].getPontos() - 10 * (rand() % ((jogadores[0].getPontos() / 10) + 1)));*/
			}
			rocket.setY(yRocket = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, rocket.getSprites()[0], (float)(rocket.getXs()[0]), (float)(rocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].variarPontos(50);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-50);
				jogadores[1].variarHP(-50);
				jogadores[1].getSomAtacado().tocar();

				/*int sorteado = rand() % 150;
				while (jogadores[1].getPegouPokemons()[sorteado] == false)
				{
					sorteado = rand() % 150;
				}
				jogadores[1].setPegouPokemons(sorteado, false);
				for (int i = 0; i < 3; i++)
				{
					jogadores[1].setPokebolas(i, jogadores[1].getPokebolas()[i] - (rand() % (jogadores[1].getPokebolas()[i] + 1)));
				}
				jogadores[1].setPokecoins(jogadores[1].getPokecoins() - (rand() % (jogadores[1].getPokecoins() + 1)));
				jogadores[1].setPontos(jogadores[1].getPontos() - 10 * (rand() % ((jogadores[1].getPontos() / 10) + 1)));*/
			}
			rocket.setY(yRocket = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, rocket.getSprites()[1], (float)(rocket.getXs()[1]), (float)(rocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].variarPontos(50);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-50);
				jogadores[1].variarHP(-50);
				jogadores[1].getSomAtacado().tocar();

				/*int sorteado = rand() % 150;
				while (jogadores[1].getPegouPokemons()[sorteado] == false)
				{
					sorteado = rand() % 150;
				}
				jogadores[1].setPegouPokemons(sorteado, false);
				for (int i = 0; i < 3; i++)
				{
					jogadores[1].setPokebolas(i, jogadores[1].getPokebolas()[i] - (rand() % (jogadores[1].getPokebolas()[i] + 1)));
				}
				jogadores[1].setPokecoins(jogadores[1].getPokecoins() - (rand() % (jogadores[1].getPokecoins() + 1)));
				jogadores[1].setPontos(jogadores[1].getPontos() - 10 * (rand() % ((jogadores[1].getPontos() / 10) + 1)));*/
			}
			rocket.setY(yRocket = -1);
		}
		else
		{
			atualizarRocket();
			desenharRocket();
		}
	}
	else
	{
		sortearRocket();
	}

	// Gerenciar Ginasios
	if (ginasio.getY() >= 0 && ginasio.getY() <= gJanela.getAltura())
	{
		if (ginasio.getY() - ginasio.getSprites()[0].getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			ginasio.setY(yGinasio = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, ginasio.getSprites()[0], (float)(ginasio.getX()), (float)(ginasio.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incGinasios(forcaGinasioAtual);
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			ginasio.setY(yGinasio = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, ginasio.getSprites()[0], (float)(ginasio.getX()), (float)(ginasio.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incGinasios(forcaGinasioAtual);
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			ginasio.setY(yGinasio = -1);
		}
		else
		{
			atualizarGinasio();
			desenharGinasio();
		}
	}
	else
	{
		int forcaNovoGinasio = sortearGinasio();
		if (forcaNovoGinasio != -1)
		{
			forcaGinasioAtual = forcaNovoGinasio;
		}
	}

	// Gerenciar Letroes
	if (letrao.getY() >= 0 && letrao.getY() <= gJanela.getAltura())
	{
		if (letrao.getY() - letrao.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			letrao.setY(yLetrao = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, letrao.getSprite(), (float)(letrao.getX()), (float)(letrao.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incQntdLetras(letraoAtual);
				jogadores[0].setPegouLetroes(letraoAtual, true);
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			letrao.setY(yLetrao = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, letrao.getSprite(), (float)(letrao.getX()), (float)(letrao.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incQntdLetras(letraoAtual);
				jogadores[1].setPegouLetroes(letraoAtual, true);
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			letrao.setY(yLetrao = -1);
		}
		else
		{
			atualizarLetrao();
			desenharLetrao();
		}
	}
	else
	{
		letraoAtual = sortearLetrao();
	}

	// Gerenciar Ovos
	if (ovo.getY() >= 0 && ovo.getY() <= gJanela.getAltura())
	{
		if (ovo.getY() - ovo.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			ovo.setY(yOvo = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, ovo.getSprite(), (float)(ovo.getX()), (float)(ovo.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incQntdOvos(codKmOvo);
				jogadores[0].pegouOvo(tempo, codKmOvo);
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			ovo.setY(yOvo = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, ovo.getSprite(), (float)(ovo.getX()), (float)(ovo.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incQntdOvos(codKmOvo);
				jogadores[1].pegouOvo(tempo, codKmOvo);
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			ovo.setY(yOvo = -1);
		}
		else
		{
			atualizarOvo();
			desenharOvo();
		}
	}
	else
	{
		codKmOvo = sortearOvo();
	}

	// Gerenciar Pokebolas
	if (pokebola.getY() >= 0 && pokebola.getY() <= gJanela.getAltura())
	{
		if (pokebola.getY() - pokebola.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yPokebola = -1;
			poderPokebola = -1;
			pokebola.setY(-1);
			pokebola.setPoder(poderPokebola);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokebola.getSprite(), (float)(pokebola.getX()), (float)(pokebola.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incPokebolas(poderPokebola);
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			yPokebola = -1;
			poderPokebola = -1;
			pokebola.setY(-1);
			pokebola.setPoder(poderPokebola);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokebola.getSprite(), (float)(pokebola.getX()), (float)(pokebola.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incPokebolas(poderPokebola);
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			yPokebola = -1;
			poderPokebola = -1;
			pokebola.setY(-1);
			pokebola.setPoder(poderPokebola);
		}
		else
		{
			atualizarPokebola();
			desenharPokebola();
		}
	}
	else
	{
		int novoPoder = sortearPokebola();
		if (novoPoder != -1)
		{
			pokebola.getSprite().setSpriteSheet("pb" + to_string(novoPoder + 1));
			poderPokebola = novoPoder;
		}
	}

	// Gerenciar Pokecoins
	if (pokecoin.getY() >= 0 && pokecoin.getY() <= gJanela.getAltura())
	{
		if (pokecoin.getY() - pokecoin.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			pokecoin.setY(yPokecoin = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokecoin.getSprite(), (float)(pokecoin.getX()), (float)(pokecoin.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incPokecoins();
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			pokecoin.setY(yPokecoin = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokecoin.getSprite(), (float)(pokecoin.getX()), (float)(pokecoin.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incPokecoins();
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			pokecoin.setY(yPokecoin = -1);
		}
		else
		{
			atualizarPokecoin();
			desenharPokecoin();
		}
	}
	else
	{
		sortearPokecoin();
	}

	// Gerenciar Pokemons
	for (int j = 0; j < (int)(idsAtuais.size()); j++)
	{
		if (pokemons[idsAtuais[j]].getY() - pokemons[idsAtuais[j]].getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			isPokemonMostrado[idsAtuais[j]] = false;
			quantidadeMostradaAtual--;
			idsAtuais.erase(idsAtuais.begin() + j);
			posxAtuais.erase(posxAtuais.begin() + j);
			poderesAtuais.erase(poderesAtuais.begin() + j);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokemons[idsAtuais[j]].getSprite(), (float)(pokemons[idsAtuais[j]].getX()), (float)(pokemons[idsAtuais[j]].getY()), 0))
		{
			isPokemonMostrado[idsAtuais[j]] = false;
			quantidadeMostradaAtual--;
			idsAtuais.erase(idsAtuais.begin() + j);
			posxAtuais.erase(posxAtuais.begin() + j);
			poderesAtuais.erase(poderesAtuais.begin() + j);
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar()/* && (jogadores[0].getTipoDaPokebola() >= poderesAtuais.at(poderesAtuais.begin() + i))*/)
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].pegouPokemon(*(idsAtuais.data() + j));
				jogadores[0].variarPontos(100);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokemons[idsAtuais[j]].getSprite(), (float)(pokemons[idsAtuais[j]].getX()), (float)(pokemons[idsAtuais[j]].getY()), 0))
		{
			isPokemonMostrado[idsAtuais[j]] = false;
			quantidadeMostradaAtual--;
			idsAtuais.erase(idsAtuais.begin() + j);
			posxAtuais.erase(posxAtuais.begin() + j);
			poderesAtuais.erase(poderesAtuais.begin() + j);
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar()/* && (jogadores[1].getTipoDaPokebola() >= poderesAtuais.at(poderesAtuais.begin() + i))*/)
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].pegouPokemon(*(idsAtuais.data() + j));
				jogadores[1].variarPontos(100);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
		}
	}
	for (int j = quantidadeMostradaAtual; (j < quantidadeDePokemonsPorVez) && (quantidadeMostradaAtual <= floor(gJanela.getLargura() / 82)); j++)
	{
		int novoPokemon = sortearPokemon();
		int novoX = sortearX(pokemons[novoPokemon].getSprite().getLargura());
		int novoPoder = sortearPoder(tabelaDeEvolucoes[novoPokemon]);
		pokemons[novoPokemon].inicializar(novoX, 0, 1, 270, novoPokemon, novoPoder);
		idsAtuais.push_back(novoPokemon);
		posxAtuais.push_back(novoX);
		poderesAtuais.push_back(novoPoder);
	}
	atualizarPokemon();
	desenharPokemon();

	// Gerenciar Pokestops
	if (pokestop.getY() >= 0 && pokestop.getY() <= gJanela.getAltura())
	{
		if (pokestop.getY() - pokestop.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			pokestop.setY(yPokestop = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokestop.getSprite(), (float)(pokestop.getX()), (float)(pokestop.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].incQntdPokestops();
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();

				/*for (int i = 0; i < 3; i++)
				{
					jogadores[0].setPokebolas(i, jogadores[0].getPokebolas()[i] + (rand() % (jogadores[0].getPokebolas()[i] + 1)));
				}
				for (int i = 0; i < 3; i++)
				{
					int qntdNovos = (rand() % jogadores[0].getQntdsOvos()[i]) + 1;
					jogadores[0].setQntdsOvos(i, jogadores[0].getQntdsOvos()[i] + qntdNovos);
					for (int j = 0; j < qntdNovos; j++)
					{
						jogadores[0].pegouOvo(tempo, i);
					}
				}
				jogadores[0].setPontos(jogadores[0].getPontos() + 10 * (rand() % ((jogadores[0].getPontos() / 10) + 1)));
				int qntdNovas = (rand() % (jogadores[0].getVidas() + 1));
				for (int j = 0; j < qntdNovas; j++)
				{
					jogadores[0].pegouVida();
				}*/
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			pokestop.setY(yPokestop = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokestop.getSprite(), (float)(pokestop.getX()), (float)(pokestop.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].incQntdPokestops();
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();

				/*for (int i = 0; i < 3; i++)
				{
					jogadores[1].setPokebolas(i, jogadores[1].getPokebolas()[i] + (rand() % (jogadores[1].getPokebolas()[i] + 1)));
				}
				for (int i = 0; i < 3; i++)
				{
					int qntdNovos = (rand() % jogadores[1].getQntdsOvos()[i]) + 1;
					jogadores[1].setQntdsOvos(i, jogadores[1].getQntdsOvos()[i] + qntdNovos);
					for (int j = 0; j < qntdNovos; j++)
					{
						jogadores[1].pegouOvo(tempo, i);
					}
				}
				jogadores[1].setPontos(jogadores[1].getPontos() + 10 * (rand() % ((jogadores[1].getPontos() / 10) + 1)));
				int qntdNovas = (rand() % (jogadores[1].getVidas() + 1));
				for (int j = 0; j < qntdNovas; j++)
				{
					jogadores[1].pegouVida();
				}*/
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			pokestop.setY(yPokestop = -1);
		}
		else
		{
			atualizarPokestop();
			desenharPokestop();
		}
	}
	else
	{
		sortearPokestop();
	}

	// Gerenciar Vidas
	if (vida.getY() >= 0 && vida.getY() <= gJanela.getAltura())
	{
		if (vida.getY() - vida.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			vida.setY(yVida = -1);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, vida.getSprite(), (float)(vida.getX()), (float)(vida.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				jogadores[0].setPodePegar(false);
				jogadores[0].pegouVida();
				jogadores[0].variarPontos(10);
				jogadores[0].getSomCaptura().tocar();
			}
			else
			{
				jogadores[0].variarPontos(-10);
				//jogadores[0].variarHP(-10);
				jogadores[0].getSomAtacado().tocar();
			}
			vida.setY(yVida = -1);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, vida.getSprite(), (float)(vida.getX()), (float)(vida.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				jogadores[1].setPodePegar(false);
				jogadores[1].pegouVida();
				jogadores[1].variarPontos(10);
				jogadores[1].getSomCaptura().tocar();
			}
			else
			{
				jogadores[1].variarPontos(-10);
				jogadores[1].variarHP(-10);
				jogadores[1].getSomAtacado().tocar();
			}
			vida.setY(yVida = -1);
		}
		else
		{
			atualizarVida();
			desenharVida();
		}
	}
	else
	{
		sortearVida();
	}
}
