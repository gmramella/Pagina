#include "Ginasio.h"

Ginasio::Ginasio()
{
}

Ginasio::~Ginasio()
{
}

void Ginasio::inicializar(int x_, int y_, int velocidade_)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "ginasio", 0);
}

void Ginasio::atualizar()
{
	Objeto::atualizar();
}

void Ginasio::desenhar()
{
	Objeto::desenhar();
}

Sprite & Ginasio::getSprite()
{
	Objeto::getSprite();
}

int Ginasio::getX()
{
	Objeto::getX();
}

int Ginasio::getY()
{
	Objeto::getY();
}

void Ginasio::setY(int y_)
{
	Objeto::setY(y_);
}
