#include "Jogo.h"

void Jogo::telaInicial()
{
	fundos[0].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);

	if (!gMusica.estaTocando())
	{
		gMusica.tocar("somOpening", true);
	}
	for (int i = 0; i < 4; i++)
	{
		botoes[i].atualizar();
		botoes[i].desenhar();
	}

	for (int i = 0; i < 2; i++)
	{
		jogadores[i].resetarJogador();
	}

	iniciarTempo = true;

	if (botoes[0].estaClicado())
	{
		gMusica.parar();
		status = tJogo;
		contadorDeFrames = 0;
		segundosQuandoPausou = 0;
		segundoAnterior = 0;
	}
	if (botoes[1].estaClicado())
	{
		gMusica.parar();
		status = tInstrucoes;
	}
	if (botoes[2].estaClicado())
	{
		gMusica.parar();
		status = tCreditos;
	}
	if (botoes[3].estaClicado())
	{
		gMusica.parar();
		statusAnterior = tInicial;
		status = tConfirmar;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		statusAnterior = tInicial;
		status = tConfirmar;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		statusAnterior = tInicial;
		status = tConfirmar;
	}
}

void Jogo::telaJogo()
{
	// Iniciar cronometro
	if (iniciarTempo)
	{
		start = time(0) - segundosQuandoPausou;
		iniciarTempo = false;
	}

	// Tocar musicas
	/*if (!musicaPausadaPorJogador)
	{
	if (musicaAtual == "")
	{
	gMusica.tocar("somJogo", false);

	musicaAtual = "somJogo";
	}
	else if (!gMusica.estaTocando() && musicaAtual == "somJogo")
	{
	gMusica.tocar("somJogo2", false);
	musicaAtual = "somJogo2";
	}
	else if (!gMusica.estaTocando() && musicaAtual == "somJogo2")
	{
	gMusica.tocar("somJogo", false);
	musicaAtual = "somJogo";
	}
	}*/

	// Mutar musica
	/*if (gTeclado.soltou[TECLA_M])
	{
	gMusica.pausar();
	musicaPausadaPorJogador = !musicaPausadaPorJogador;
	if (gMusica.getNomeMusica() == "")
	{
	musicaAtual = "";
	}
	else if (gMusica.getNomeMusica() == "somJogo")
	{
	musicaAtual = "somJogo2";
	}
	else if (gMusica.getNomeMusica() == "somJogo2")
	{
	musicaAtual = "somJogo";
	}
	}*/

	// Desenhar fundo em movimento
	fundos[1].desenhar(gJanela.getLargura() / 2, -(gJanela.getAltura() / 2) + contadorDeFrames);
	fundos[1].desenhar(gJanela.getLargura() / 2, (gJanela.getAltura() / 2) + contadorDeFrames);

	segundos = difftime(time(0), start);

	int vivos;
	int codsMovimentos[2];
	Sprite spr1, spr2;
	float x1, y1, x2, y2;
	int primeiro, ultimo;

	// Movimentar jogadores
	if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		// Jogadores vivos
		vivos = 2;
		codsMovimentos[0] = jogadores[0].atualizar((int)segundos, &segundoAnterior);
		codsMovimentos[1] = jogadores[1].atualizar((int)segundos, &segundoAnterior);
		spr1 = jogadores[0].getSprite();
		x1 = (float)(jogadores[0].getX());
		y1 = (float)(jogadores[0].getY());
		spr2 = jogadores[1].getSprite();
		x2 = (float)(jogadores[1].getX());
		y2 = (float)(jogadores[1].getY());
		primeiro = 0; ultimo = 1;
	}
	else if (jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		// Jogador 2 vivo
		vivos = 1;
		codsMovimentos[0] = -1;
		codsMovimentos[1] = jogadores[1].atualizar((int)segundos, &segundoAnterior);
		spr1 = jogadores[0].getSprite();
		x1 = (float)(-jogadores[0].getSprite().getLargura() / 2);
		y1 = (float)(-jogadores[0].getSprite().getAltura() / 2);
		spr2 = jogadores[1].getSprite();
		x2 = (float)(jogadores[1].getX());
		y2 = (float)(jogadores[1].getY());
		primeiro = 1; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && jogadores[1].getMorto())
	{
		// Jogador 1 vivo
		vivos = 0;
		codsMovimentos[0] = jogadores[0].atualizar((int)segundos, &segundoAnterior);
		codsMovimentos[1] = -1;
		spr1 = jogadores[0].getSprite();
		x1 = (float)(jogadores[0].getX());
		y1 = (float)(jogadores[0].getY());
		spr2 = jogadores[1].getSprite();
		x2 = (float)(-jogadores[1].getSprite().getLargura() / 2);
		y2 = (float)(-jogadores[1].getSprite().getAltura() / 2);
		primeiro = 0; ultimo = 0;
	}
	else
	{
		vivos = -1;
	}

	switch(vivos)
	{
		case 2:
		case 1:
		case 0:
			if (uniTestarColisao(spr1, x1, y1, 0, spr2, x2, y2, 0))
			{
				for (int i = primeiro; i <= ultimo; i++)
				{
					jogadores[i].desfazerAtualizar();
				}
			}
			for (int i = primeiro; i <= ultimo; i++)
			{
				// Desenhar jogadores
				jogadores[i].atualizar((int)segundos, &segundoAnterior);
				jogadores[i].desenhar();

				gerenciador.gerenciar(jogadores, (int)segundos);
				contadorDeFrames = (contadorDeFrames + 1) % gJanela.getAltura();

				if (gTeclado.soltou[jogadores[i].getTeclaPausar()])
				{
					statusAnterior = tJogo;
					status = tPausa;
					segundosQuandoPausou = segundos;
				}
			}
			break;
		case -1:
			// Jogadores mortos
			status = tGameover;
			break;
	}

	// Desenhar HUD
	desenharHUD();
}

void Jogo::telaPausa()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	logo.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 - 160);

	for (int i = 7; i < 16; i++)
	{
		botoes[i].atualizar();
		botoes[i].desenhar();
	}

	if (botoes[7].estaClicado())
	{
		status = tJogo;
		iniciarTempo = true;
	}
	if (botoes[8].estaClicado())
	{
		status = tGinasios;
	}
	if (botoes[9].estaClicado())
	{
		status = tLetras;
	}
	if (botoes[10].estaClicado())
	{
		status = tOvos;
	}
	if (botoes[11].estaClicado())
	{
		status = tPokedex;
	}
	if (botoes[12].estaClicado())
	{
		status = tRanking;
	}
	if (botoes[15].estaClicado())
	{
		statusAnterior = tPausa;
		status = tConfirmar;
	}

	int primeiro, ultimo;
	if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 1; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 0;
	}
	for (int i = primeiro; i <= ultimo; i++)
	{
		if (gTeclado.soltou[jogadores[i].getTeclaPausar()])
		{
			status = tJogo;
			iniciarTempo = true;
		}
	}
}

void Jogo::telaCreditos()
{
	fundos[3].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	textos[0].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2, 0);

	botoes[4].atualizar();
	botoes[4].desenhar();

	if (botoes[4].estaClicado())
	{
		status = tInicial;
	}

	int primeiro, ultimo;
	if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 1; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 0;
	}
	for (int i = primeiro; i <= ultimo; i++)
	{
		if (gTeclado.soltou[jogadores[i].getTeclaPausar()])
		{
			status = tInicial;
		}
	}
}

void Jogo::telaInstrucoes()
{
	fundos[4].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	textos[1].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2, 0);

	botoes[4].atualizar();
	botoes[4].desenhar();

	if (botoes[4].estaClicado())
	{
		status = tInicial;
	}

	int primeiro, ultimo;
	if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 1; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 0;
	}
	for (int i = primeiro; i <= ultimo; i++)
	{
		if (gTeclado.soltou[jogadores[i].getTeclaPausar()])
		{
			status = tInicial;
		}
	}
}

void Jogo::telaConfirmar(Tela anterior, Tela seguinte)
{
	fundos[5].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	textos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2, 0);

	botoes[5].atualizar();
	botoes[5].desenhar();
	botoes[6].atualizar();
	botoes[6].desenhar();

	if (botoes[5].estaClicado())
	{
		status = seguinte;
	}
	else if (botoes[6].estaClicado())
	{
		status = anterior;
	}

	int primeiro, ultimo;
	if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 1; ultimo = 1;
	}
	else if (!jogadores[0].getMorto() && !jogadores[1].getMorto())
	{
		primeiro = 0; ultimo = 0;
	}
	for (int i = primeiro; i <= ultimo; i++)
	{
		if (gTeclado.soltou[jogadores[i].getTeclaPausar()])
		{
			status = anterior;
		}
	}
}

void Jogo::telaGinasios()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Sprite ginasio, forcasGinasio;
	ginasio.setVelocidadeAnimacao(0);
	ginasio.setSpriteSheet("ginasioPequeno");
	ginasio.setFrame(0);
	for (int i = 0; i < 5; i++)
	{
		ginasio.desenhar(150, 75 + i * 135);
	}
	forcasGinasio.setVelocidadeAnimacao(0);
	forcasGinasio.setSpriteSheet("forcasGinasio");
	for (int i = 0; i < 5; i++)
	{
		forcasGinasio.setFrame(i);
		forcasGinasio.desenhar(150, 75 + i * 135);
	}
	Texto quantidades[2][5];
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			quantidades[i][j].setFonte("fonte");
			quantidades[i][j].setCor(0, 0, 255);
			quantidades[i][j].setString(to_string(jogadores[i].getQntdsGinasios()[j]));
			quantidades[i][j].desenhar(gJanela.getLargura() / 2 - 100 + i * 300, 75 + j * 135);
		}
	}
	botoes[13].atualizar();
	botoes[13].desenhar();
	if (botoes[13].estaClicado())
	{
		status = tPausa;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		status = tPausa;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		status = tPausa;
	}
}

void Jogo::telaLetras()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Sprite letrasGrandesEscondidas, letrasGrandes;
	letrasGrandesEscondidas.setSpriteSheet("letrasGrandesEscondidas");
	letrasGrandesEscondidas.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 - 180);
	letrasGrandesEscondidas.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 + 100);
	letrasGrandes.setSpriteSheet("letrasGrandes");
	letrasGrandes.setVelocidadeAnimacao(0);
	for (int i = 0; i < 7; i++) {
		letrasGrandes.setFrame(i);
		if (jogadores[0].getPegouLetroes()[i])
		{
			letrasGrandes.desenhar(73 + i * 146, gJanela.getAltura() / 2 - 180);
		}
		if (jogadores[1].getPegouLetroes()[i])
		{
			letrasGrandes.desenhar(73 + i * 146, gJanela.getAltura() / 2 + 100);
		}
	}
	botoes[13].atualizar();
	botoes[13].desenhar();
	if (botoes[13].estaClicado())
	{
		status = tPausa;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		status = tPausa;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		status = tPausa;
	}
}

void Jogo::telaOvos()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Sprite ovosGrandes;
	ovosGrandes.setSpriteSheet("ovosGrandes");
	for (int i = 0; i < 3; i++)
	{
		ovosGrandes.setFrame(i);
		ovosGrandes.desenhar(145 + i * 300, gJanela.getAltura() / 2 - 180);
		ovosGrandes.desenhar(145 + i * 300, gJanela.getAltura() / 2 + 100);
	}
	int kms[] = { 2, 5, 10 };
	Texto kilometros;
	kilometros.setFonte("fonte");
	kilometros.setCor(0, 0, 255);
	for (int i = 0; i < 3; i++)
	{
		kilometros.setString(to_string(kms[i]) + " km");
		kilometros.desenhar(145 + i * 300, gJanela.getAltura() / 2 - 300);
		kilometros.desenhar(145 + i * 300, gJanela.getAltura() / 2 - 20);
	}
	Texto quantidades;
	quantidades.setFonte("fonte");
	quantidades.setCor(0, 0, 255);
	for (int i = 0; i < 3; i++)
	{
		kilometros.setString(to_string(jogadores[0].getQntdsOvos()[i]));
		kilometros.desenhar(275 + i * 300, gJanela.getAltura() / 2 - 180);
		kilometros.setString(to_string(jogadores[1].getQntdsOvos()[i]));
		kilometros.desenhar(275 + i * 300, gJanela.getAltura() / 2 + 100);
	}

	botoes[13].atualizar();
	botoes[13].desenhar();
	if (botoes[13].estaClicado())
	{
		status = tPausa;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		status = tPausa;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		status = tPausa;
	}
}

void Jogo::telaPokedex()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Sprite pokemonsEscondidos, pokemons;
	pokemonsEscondidos.setSpriteSheet("pokedex");
	pokemonsEscondidos.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 - 40);
	pokemons.setSpriteSheet("pokemons");
	pokemons.setVelocidadeAnimacao(0);
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			pokemons.setAnimacao(i);
			pokemons.setFrame(j);
			if (jogadores[playerPokedex].getPegouPokemons()[15 * i + j])
			{
				pokemons.desenhar(34 + 68 * j + 2, 34 + 68 * i + 4);
			}
		}
	}
	botoes[13].atualizar();
	botoes[13].desenhar();
	setas[0].atualizar();
	setas[0].desenhar();
	setas[1].atualizar();
	setas[1].desenhar();
	
	if (botoes[13].estaClicado())
	{
		status = tPausa;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		status = tPausa;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		status = tPausa;
	}

	int qntdTelas = 2;
	if (setas[0].estaClicado())
	{
		playerPokedex = (playerPokedex + (qntdTelas - 1)) % qntdTelas;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaEsquerda()])
	{
		playerPokedex = (playerPokedex + (qntdTelas - 1)) % qntdTelas;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaEsquerda()])
	{
		playerPokedex = (playerPokedex + (qntdTelas - 1)) % qntdTelas;
	}

	if (setas[1].estaClicado())
	{
		playerPokedex = (playerPokedex + 1) % qntdTelas;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaDireita()])
	{
		playerPokedex = (playerPokedex + 1) % qntdTelas;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaDireita()])
	{
		playerPokedex = (playerPokedex + 1) % qntdTelas;
	}
}

void Jogo::telaRanking()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Sprite painelAlongado;
	painelAlongado.setSpriteSheet("painelAlongado");
	painelAlongado.desenhar(gJanela.getLargura() / 2 - 200, gJanela.getAltura() / 2 - 32);
	painelAlongado.desenhar(gJanela.getLargura() / 2 + 200, gJanela.getAltura() / 2 - 32);
	lerRanking();
	Texto textoRanking;
	textoRanking.setFonte("fonte");
	textoRanking.setCor(255, 0, 0);
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < qntdNomesNoRanking; j++)
		{
			if (i == 0)
			{
				textoRanking.setString(nomes[j]);
				textoRanking.desenhar(gJanela.getLargura() / 2 - 200 + i * 400, gJanela.getAltura() / 2 - 200 + j * 45);
			}
			else
			{
				textoRanking.setString(pontuacoes[j]);
				textoRanking.desenhar(gJanela.getLargura() / 2 - 200 + i * 400, gJanela.getAltura() / 2 - 200 + j * 42);
			}
		}
	}
	botoes[13].atualizar();
	botoes[13].desenhar();
	if (botoes[13].estaClicado())
	{
		status = tPausa;
	}

	if (gTeclado.soltou[jogadores[0].getTeclaPausar()])
	{
		status = tPausa;
	}
	else if (gTeclado.soltou[jogadores[1].getTeclaPausar()])
	{
		status = tPausa;
	}
}

void Jogo::telaGameover()
{
	fundos[5].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Texto textoGameOver;
	textoGameOver.setFonte("fonte");
	textoGameOver.setCor(255, 0, 0);
	textoGameOver.setString("FIM DE JOGO");
	textoGameOver.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 - 100);
	painel.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	string pontosFixos = "Gin�sios\nLetras\nOvos\nPokemons\nPokestops\nPontos";
	string valores[2];
	for (int i = 0; i < 2; i++)
	{
		int somaQntdsGinasios = 0;
		for (int j = 0; j < 5; j++)
		{
			somaQntdsGinasios += jogadores[i].getQntdsGinasios()[j];
		}
		int somaQntdsOvos = 0;
		for (int j = 0; j < 5; j++)
		{
			somaQntdsOvos += jogadores[i].getQntdsOvos()[j];
		}
		valores[i] = to_string(somaQntdsGinasios) + "\n" + to_string(jogadores[i].getQntdLetras()) + "\n" + to_string(somaQntdsOvos) + "\n" + to_string(jogadores[i].getQntdPokemons()) + "\n" + to_string(jogadores[i].getQntdPokestops()) + "\n" + to_string(jogadores[i].getPontos());
	}
	Texto textoFixo, resultado1, resultado2;
	textoFixo.setFonte("fonte2");
	textoFixo.setCor(255, 255, 255);
	textoFixo.setString(pontosFixos);
	textoFixo.desenhar(gJanela.getLargura() / 2 - 100, gJanela.getAltura() / 2);
	resultado1.setFonte("fonte2");
	resultado1.setCor(255, 255, 255);
	resultado1.setString(valores[0]);
	resultado1.desenhar(gJanela.getLargura() / 2 + 0, gJanela.getAltura() / 2);
	resultado2.setFonte("fonte2");
	resultado2.setCor(255, 255, 255);
	resultado2.setString(valores[1]);
	resultado2.desenhar(gJanela.getLargura() / 2 + 100, gJanela.getAltura() / 2);
	botoes[14].atualizar();
	botoes[14].desenhar();
	if (botoes[14].estaClicado())
	{
		if (qntdNomesNoRanking == 10)
		{
			if (jogadores[0].getPontos() > menorPontuacao && jogadores[1].getPontos() > menorPontuacao)
			{
				if (jogadores[0].getPontos() == jogadores[1].getPontos())
				{
					status = tNome;
					codNovoNome = 2;
				}
				else if (jogadores[0].getPontos() > jogadores[1].getPontos())
				{
					status = tNome;
					codNovoNome = 0;
				}
				else
				{
					status = tNome;
					codNovoNome = 1;
				}
			}
			else if (jogadores[0].getPontos() > menorPontuacao)
			{
				status = tNome;
				codNovoNome = 0;
			}
			else if (jogadores[1].getPontos() > menorPontuacao)
			{
				status = tNome;
				codNovoNome = 1;
			}
			else
			{
				status = tInicial;
				codNovoNome = -1;
			}
		}
		else if (qntdNomesNoRanking > 0 && qntdNomesNoRanking < 10)
		{
			if (jogadores[0].getPontos() >= menorPontuacao && jogadores[1].getPontos() >= menorPontuacao)
			{
				status = tNome;
				codNovoNome = 2;
			}
			else if (jogadores[0].getPontos() >= menorPontuacao)
			{
				status = tNome;
				codNovoNome = 0;
			}
			else if (jogadores[1].getPontos() >= menorPontuacao)
			{
				status = tNome;
				codNovoNome = 1;
			}
			else
			{
				status = tInicial;
				codNovoNome = -1;
			}
		}
		else
		{
			if (jogadores[0].getPontos() > menorPontuacao && jogadores[1].getPontos() > menorPontuacao)
			{
				status = tNome;
				codNovoNome = 2;
			}
			else if (jogadores[0].getPontos() > menorPontuacao)
			{
				status = tNome;
				codNovoNome = 0;
			}
			else if (jogadores[1].getPontos() > menorPontuacao)
			{
				status = tNome;
				codNovoNome = 1;
			}
			else
			{
				status = tInicial;
				codNovoNome = -1;
			}
		}
	}
}

void Jogo::telaNome()
{
	fundos[2].desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	painel.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	Texto textoJogador;
	textoJogador.setFonte("fonte2");
	textoJogador.setCor(255, 0, 0);
	if (codNovoNome == 2)
	{
		textoJogador.setString("Jogador 1");
	}
	else if (codNovoNome == 1)
	{
		textoJogador.setString("Jogador 2");
	}
	else
	{
		textoJogador.setString("Jogador 1");
	}
	textoJogador.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 - 50);
	if (novoNomeProRanking.size() == 0)
	{
		barra.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	}
	barra.avancarAnimacao();
	escreverTexto();
	Texto textoNome;
	textoNome.setFonte("fonte");
	textoNome.setCor(255, 255, 255);
	textoNome.setString(novoNomeProRanking);
	textoNome.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	botoes[14].atualizar();
	botoes[14].desenhar();
	if ((novoNomeProRanking.size() > 0) && (botoes[14].estaClicado() || gTeclado.soltou[TECLA_ENTER]))
	{
		atualizarRanking();
		novoNomeProRanking = "";
		if (codNovoNome == 2)
		{
			codNovoNome = 1;
		}
		else
		{
			status = tInicial;
		}
	}
}

void Jogo::desenharHUD()
{
	hud.desenhar(gJanela.getLargura() / 2, (gJanela.getAltura() / 2));
	string textos[] = { "VIDAS", "HP", "POKEBOLAS", "OVOS" };
	int xs[] = { 110, 310, 620, 900 };
	Texto textosHud[4];
	for (int i = 0; i < 4; i++)
	{
		textosHud[i].setFonte("fonte");
		textosHud[i].setCor(0, 128, 0);
		textosHud[i].setString(textos[i]);
		textosHud[i].desenhar(xs[i], gJanela.getAltura() - 160);
	}
	
	pokecoinGirando.desenhar(37, 37);
	pokecoinGirando.avancarAnimacao();
	Texto textoPokecoins;
	textoPokecoins.setFonte("fonte");
	textoPokecoins.setCor(255, 255, 0);
	textoPokecoins.setString(to_string(jogadores[0].getPokecoins()) + " x " + to_string(jogadores[1].getPokecoins()));
	textoPokecoins.desenhar(170, 37);

	relogio.desenhar(gJanela.getLargura() - 230, 50);
	relogio.avancarAnimacao();
	Texto textoTempo;
	textoTempo.setFonte("fonte");
	textoTempo.setCor(0, 0, 255);
	textoTempo.setString(to_string((int)segundos));
	textoTempo.desenhar(gJanela.getLargura() - 120, 50);

	textoPlacar = to_string(jogadores[0].getPontos()) + " x " + to_string(jogadores[1].getPontos());
	placar.setString(textoPlacar);
	placar.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2);
	
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < jogadores[i].getVidas(); j++)
		{
			spriteVida.setSpriteSheet("p" + to_string(i + 1));
			spriteVida.setVelocidadeAnimacao(0);
			spriteVida.setAnimacao(1);
			spriteVida.setFrame(1);
			spriteVida.desenhar((gJanela.getLargura() / 2) - 430 + 30 * j, gJanela.getAltura() - 110 + i * 80);
		}
	}

	Texto textoHpJogador;
	textoHpJogador.setFonte("fonte2");
	Sprite forcasJogador;
	for (int i = 0; i < 2; i++)
	{
		textoHpJogador.setCor(0, 128, 0);
		textoHpJogador.setString(to_string(jogadores[i].getHp()));
		textoHpJogador.desenhar(gJanela.getLargura() / 2 - 220 + i * 40, gJanela.getAltura() - 125);
		forcasJogador.setSpriteSheet("forcasJogador");
		forcasJogador.setFrame((int)floor(jogadores[i].getHp() / 10));
		forcasJogador.desenhar(gJanela.getLargura() / 2 - 210 + i * 20, gJanela.getAltura() - 60);
	}
	
	Texto textoPokebola;
	textoPokebola.setFonte("fonte2");
	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 2; i++)
		{
			pokebolasHUD[j].desenhar((gJanela.getLargura() / 2) + 10 + i * 140, gJanela.getAltura() - 90 + j * 20);
			textoPokebola.setCor((int)(j == 0) * 255, (int)(j == 1) * 255, (int)(j == 2) * 255);
			textoPokebola.setString(to_string(jogadores[i].getPokebolas()[j]));
			textoPokebola.desenhar((gJanela.getLargura() / 2) + 50 + i * 140, gJanela.getAltura() - 90 + j * 20, 0);
		}
		pokebolasHUD[j].avancarAnimacao();
	}

	Texto textoKm;
	textoKm.setFonte("fonte2");
	Sprite ovos;
	ovos.setSpriteSheet("ovos");
	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 2; i++)
		{
			textoKm.setCor((int)(j == 0) * 255, (int)(j == 1) * 255, (int)(j == 2) * 255);
			if (jogadores[i].idxPrimeiroOvoCadaKm[j] != -1)
			{
				int metros = jogadores[i].kmsOvos[jogadores[i].idxPrimeiroOvoCadaKm[j]];
				textoKm.setString(to_string(metros));
				textoKm.desenhar(gJanela.getLargura() / 2 + 330 + j * 60, gJanela.getAltura() - 120 + i * 60);
			}
			else
			{
				textoKm.setString("-----");
				textoKm.desenhar(gJanela.getLargura() / 2 + 330 + j * 60, gJanela.getAltura() - 120 + i * 60);
			}
			ovos.setFrame(j);
			ovos.desenhar(gJanela.getLargura() / 2 + 330 + j * 60, gJanela.getAltura() - 90 + i * 60);
		}
	}
}

bool Jogo::vaiSairDaTela(float x, float y, float velocidade, int codMovimento)
{
	double xTemp, yTemp;
	switch (codMovimento)
	{
	case 0:
		xTemp = x - (velocidade / sqrt(2));
		yTemp = y - (velocidade / sqrt(2));
		break;
	case 1:
		xTemp = x + velocidade / sqrt(2);
		yTemp = y - velocidade / sqrt(2);
		break;
	case 2:
		xTemp = x - velocidade / sqrt(2);
		yTemp = y + velocidade / sqrt(2);
		break;
	case 3:
		xTemp = x + velocidade / sqrt(2);
		yTemp = y + velocidade / sqrt(2);
		break;
	case 4:
		xTemp = x;
		yTemp = y - velocidade;
		break;
	case 5:
		xTemp = x;
		yTemp = y + velocidade;
		break;
	case 6:
		xTemp = x - velocidade;
		yTemp = y;
		break;
	case 7:
		xTemp = x + velocidade;
		yTemp = y;
		break;
	}
	return (xTemp < 20 || xTemp > gJanela.getLargura() - 20 || yTemp < 50 || yTemp > gJanela.getAltura() - 50 - 158);
}

bool Jogo::vaiColidirComOutroJogador(Sprite spr1, float x1, float y1, Sprite spr2, float x2, float y2, float velocidade, int codMovimento)
{
	double xTemp, yTemp;
	switch (codMovimento)
	{
	case 0:
		xTemp = x1 - (velocidade / sqrt(2));
		yTemp = y1 - (velocidade / sqrt(2));
		break;
	case 1:
		xTemp = x1 + velocidade / sqrt(2);
		yTemp = y1 - velocidade / sqrt(2);
		break;
	case 2:
		xTemp = x1 - velocidade / sqrt(2);
		yTemp = y1 + velocidade / sqrt(2);
		break;
	case 3:
		xTemp = x1 + velocidade / sqrt(2);
		yTemp = y1 + velocidade / sqrt(2);
		break;
	case 4:
		xTemp = x1;
		yTemp = y1 - velocidade;
		break;
	case 5:
		xTemp = x1;
		yTemp = y1 + velocidade;
		break;
	case 6:
		xTemp = x1 - velocidade;
		yTemp = y1;
		break;
	case 7:
		xTemp = x1 + velocidade;
		yTemp = y1;
		break;
	}
	return uniTestarColisao(spr1, (float)(xTemp), (float)(yTemp), 0, spr2, x2, y2, 0);
}

void Jogo::lerRanking()
{
	string temp;
	ifstream arqIn;
	arqIn.open("ranking.bin", ios::in | ios::binary);
	if (arqIn.is_open())
	{
		string contents((istreambuf_iterator<char>(arqIn)), istreambuf_iterator<char>());
		temp = contents;
		arqIn.close();
	}
	size_t pos = 0;
	string delimitador = "\n", token;
	int cont = 0;
	while ((pos = temp.find(delimitador)) != string::npos) {
		token = temp.substr(0, pos);
		if (cont % 2 == 0)
		{
			nomes[cont / 2] = token;
		}
		else
		{
			pontuacoes[(int)(cont - 1) / 2] = token;
			menorPontuacao = stoi(token);
		}
		cont++;
		temp.erase(0, pos + delimitador.length());
	}
	qntdNomesNoRanking = cont / 2;
}

void Jogo::atualizarRanking()
{
	lerRanking();
	if (qntdNomesNoRanking == 10)
	{
		int posicaoDoNovoNome = -1;
		for (int i = 0; i < qntdNomesNoRanking; i++)
		{
			if (stoi(pontuacoes[i]) < jogadores[0].getPontos())
			{
				posicaoDoNovoNome = i;
				break;
			}
		}

		if (posicaoDoNovoNome != -1)
		{
			vector<string> nomesCopia, pontuacoesCopia;
			vector<string>::iterator it;
			nomesCopia.assign(nomes, nomes + qntdNomesNoRanking);
			pontuacoesCopia.assign(pontuacoes, pontuacoes + qntdNomesNoRanking);

			for (int i = nomesCopia.size() - 1; i > posicaoDoNovoNome; i--)
			{
				nomesCopia[i] = nomesCopia[i - 1];
			}
			nomesCopia[posicaoDoNovoNome] = novoNomeProRanking;

			for (int i = pontuacoesCopia.size() - 1; i > posicaoDoNovoNome; i--)
			{
				pontuacoesCopia[i] = pontuacoesCopia[i - 1];
			}
			pontuacoesCopia[posicaoDoNovoNome] = to_string(jogadores[0].getPontos());

			ofstream arqOut;
			arqOut.open("ranking.bin", ios::out | ios::binary);
			if (arqOut.is_open())
			{
				for (int i = 0; i < nomesCopia.size(); i++)
				{
					arqOut << nomesCopia[i] + "\n";
					arqOut << pontuacoesCopia[i] + "\n";
				}
				arqOut.close();
			}
		}
	}
	else if (qntdNomesNoRanking > 0 && qntdNomesNoRanking < 10)
	{
		int posicaoDoNovoNome = -1;
		for (int i = 0; i < qntdNomesNoRanking; i++)
		{
			if (stoi(pontuacoes[i]) < jogadores[0].getPontos())
			{
				posicaoDoNovoNome = i;
				break;
			}
		}
		if (posicaoDoNovoNome == -1)
		{
			posicaoDoNovoNome = qntdNomesNoRanking;
		}

		if (posicaoDoNovoNome != -1)
		{
			vector<string> nomesCopia, pontuacoesCopia;
			vector<string>::iterator it;
			nomesCopia.assign(nomes, nomes + qntdNomesNoRanking);
			pontuacoesCopia.assign(pontuacoes, pontuacoes + qntdNomesNoRanking);

			for (int i = nomesCopia.size() - 1; i > posicaoDoNovoNome; i--)
			{
				nomesCopia[i] = nomesCopia[i - 1];
			}
			it = nomesCopia.begin();
			nomesCopia.insert(it + posicaoDoNovoNome, novoNomeProRanking);

			for (int i = pontuacoesCopia.size() - 1; i > posicaoDoNovoNome; i--)
			{
				pontuacoesCopia[i] = pontuacoesCopia[i - 1];
			}
			it = pontuacoesCopia.begin();
			pontuacoesCopia.insert(it + posicaoDoNovoNome, to_string(jogadores[0].getPontos()));

			ofstream arqOut;
			arqOut.open("ranking.bin", ios::out | ios::binary);
			if (arqOut.is_open())
			{
				for (int i = 0; i < nomesCopia.size(); i++)
				{
					arqOut << nomesCopia[i] + "\n";
					arqOut << pontuacoesCopia[i] + "\n";
				}
				arqOut.close();
			}
		}
	}
	else
	{
		ofstream arqOut;
		arqOut.open("ranking.bin", ios::out | ios::binary);
		if (arqOut.is_open())
		{
			arqOut << novoNomeProRanking + "\n";
			arqOut << to_string(jogadores[0].getPontos()) + "\n";
			arqOut.close();
		}
	}
}

void Jogo::escreverTexto()
{
	if (gTeclado.soltou[TECLA_VOLTAR] && novoNomeProRanking.size() > 0) novoNomeProRanking.pop_back();
	else if (gTeclado.soltou[TECLA_A] && novoNomeProRanking.size() < 10) novoNomeProRanking += "A";
	else if (gTeclado.soltou[TECLA_B] && novoNomeProRanking.size() < 10) novoNomeProRanking += "B";
	else if (gTeclado.soltou[TECLA_C] && novoNomeProRanking.size() < 10) novoNomeProRanking += "C";
	else if (gTeclado.soltou[TECLA_D] && novoNomeProRanking.size() < 10) novoNomeProRanking += "D";
	else if (gTeclado.soltou[TECLA_E] && novoNomeProRanking.size() < 10) novoNomeProRanking += "E";
	else if (gTeclado.soltou[TECLA_F] && novoNomeProRanking.size() < 10) novoNomeProRanking += "F";
	else if (gTeclado.soltou[TECLA_G] && novoNomeProRanking.size() < 10) novoNomeProRanking += "G";
	else if (gTeclado.soltou[TECLA_H] && novoNomeProRanking.size() < 10) novoNomeProRanking += "H";
	else if (gTeclado.soltou[TECLA_I] && novoNomeProRanking.size() < 10) novoNomeProRanking += "I";
	else if (gTeclado.soltou[TECLA_J] && novoNomeProRanking.size() < 10) novoNomeProRanking += "J";
	else if (gTeclado.soltou[TECLA_K] && novoNomeProRanking.size() < 10) novoNomeProRanking += "K";
	else if (gTeclado.soltou[TECLA_L] && novoNomeProRanking.size() < 10) novoNomeProRanking += "L";
	else if (gTeclado.soltou[TECLA_M] && novoNomeProRanking.size() < 10) novoNomeProRanking += "M";
	else if (gTeclado.soltou[TECLA_N] && novoNomeProRanking.size() < 10) novoNomeProRanking += "N";
	else if (gTeclado.soltou[TECLA_O] && novoNomeProRanking.size() < 10) novoNomeProRanking += "O";
	else if (gTeclado.soltou[TECLA_P] && novoNomeProRanking.size() < 10) novoNomeProRanking += "P";
	else if (gTeclado.soltou[TECLA_Q] && novoNomeProRanking.size() < 10) novoNomeProRanking += "Q";
	else if (gTeclado.soltou[TECLA_R] && novoNomeProRanking.size() < 10) novoNomeProRanking += "R";
	else if (gTeclado.soltou[TECLA_S] && novoNomeProRanking.size() < 10) novoNomeProRanking += "S";
	else if (gTeclado.soltou[TECLA_T] && novoNomeProRanking.size() < 10) novoNomeProRanking += "T";
	else if (gTeclado.soltou[TECLA_U] && novoNomeProRanking.size() < 10) novoNomeProRanking += "U";
	else if (gTeclado.soltou[TECLA_V] && novoNomeProRanking.size() < 10) novoNomeProRanking += "V";
	else if (gTeclado.soltou[TECLA_W] && novoNomeProRanking.size() < 10) novoNomeProRanking += "W";
	else if (gTeclado.soltou[TECLA_X] && novoNomeProRanking.size() < 10) novoNomeProRanking += "X";
	else if (gTeclado.soltou[TECLA_Y] && novoNomeProRanking.size() < 10) novoNomeProRanking += "Y";
	else if (gTeclado.soltou[TECLA_Z] && novoNomeProRanking.size() < 10) novoNomeProRanking += "Z";
}

Jogo::Jogo()
{
}

Jogo::~Jogo()
{
}

void Jogo::inicializar()
{
	uniInicializar(1024, 768, false, "Po, que mao!");

	srand((unsigned int)time(NULL));

	// Carregar sons e musicas
	gRecursos.carregarAudio("somGotcha", "assets/sounds/gotcha.mp3");
	gRecursos.carregarMusica("somJogo", "assets/sounds/jogo.mp3");
	gRecursos.carregarMusica("somJogo2", "assets/sounds/jogo2.mp3");
	gRecursos.carregarMusica("somOpening", "assets/sounds/opening.mp3");
	gRecursos.carregarAudio("somOuch", "assets/sounds/ouch.mp3");

	// Carregar fundos das telas
	string nomesDasTelas[] = { "telaInicial" , "telaJogo" , "telaPausa", "telaCreditos" , "telaInstrucoes" , "telaConfirmar" };
	for (int i = 0; i < 6; i++)
	{
		gRecursos.carregarSpriteSheet(nomesDasTelas[i], "assets/backgrounds/fundo" + to_string(i + 1) + ".jpg");
		fundos[i].setSpriteSheet(nomesDasTelas[i]);
	}

	// Carregar botoes
	string nomesDosBotoes[] = { "botaoJogar" , "botaoInstrucoes" , "botaoCreditos" , "botaoSair" , "botaoVoltar" , "botaoSim" , "botaoNao" , "botaoContinuar" , "botaoGinasios" , "botaoLetras" , "botaoOvos" , "botaoPokedex" , "botaoRanking" , "botaoVoltar2" , "botaoOK" , "botaoSair2" };
	float alturasDosBotoes[] = { 400 , 460 , 520 , 580 , 580, (float)((gJanela.getLargura() / 2) - 50), (float)((gJanela.getLargura() / 2) + 50), 380, 440, 500, 560, 620, 680, 720, 720, 740 };
	for (int i = 0; i < 16; i++)
	{
		gRecursos.carregarSpriteSheet(nomesDosBotoes[i], "assets/buttons/botao" + to_string(i + 1) + ".png", 3);
		botoes[i].setSpriteSheet(nomesDosBotoes[i]);
		botoes[i].setPos((float)(gJanela.getLargura() / 2), alturasDosBotoes[i]);
	}
	string nomesDasSetas[] = { "botaoAnterior" , "botaoSeguinte" };
	float alturasDasSetas[] = { 720, 720 };
	for (int i = 0; i < 2; i++)
	{
		gRecursos.carregarSpriteSheet(nomesDasSetas[i], "assets/buttons/seta" + to_string(i + 1) + ".png", 3);
		setas[i].setSpriteSheet(nomesDasSetas[i]);
		setas[i].setPos((float)(gJanela.getLargura() / 2) - pow(-1, i % 2) * 300, alturasDasSetas[i]);
	}

	// Carregar sprite do Logo
	gRecursos.carregarSpriteSheet("logo", "assets/sprites/logo.png");
	logo.setSpriteSheet("logo");

	// Carregar sprite do Game Over
	gRecursos.carregarSpriteSheet("painel", "assets/backgrounds/painel.png");
	painel.setSpriteSheet("painel");

	// Carregar sprite da Pokedex
	gRecursos.carregarSpriteSheet("pokedex", "assets/sprites/pokedex.png");

	// Carregar sprite do Ginasio Pequeno
	gRecursos.carregarSpriteSheet("ginasioPequeno", "assets/sprites/ginasioPequeno.png");

	// Carregar sprites das Letras Grandes
	gRecursos.carregarSpriteSheet("letrasGrandesEscondidas", "assets/sprites/letrasGrandesEscondidas.png");
	gRecursos.carregarSpriteSheet("letrasGrandes", "assets/sprites/letrasGrandes.png", 1, 7);

	// Carregar sprite dos Ovos Grandes
	gRecursos.carregarSpriteSheet("ovosGrandes", "assets/sprites/ovosGrandes.png", 1, 3);

	// Carregar sprite do Ranking
	gRecursos.carregarSpriteSheet("painelAlongado", "assets/backgrounds/painelAlongado.png");

	// Carregar sprite da Pokecoin Girando
	gRecursos.carregarSpriteSheet("pokecoinGirando", "assets/sprites/pokecoinGirando.png", 1, 12);
	pokecoinGirando.setSpriteSheet("pokecoinGirando");
	pokecoinGirando.setVelocidadeAnimacao(8);

	// Carregar sprite do Relogio
	gRecursos.carregarSpriteSheet("relogio", "assets/sprites/relogio.png", 1, 12);
	relogio.setSpriteSheet("relogio");
	relogio.setVelocidadeAnimacao(6.5);

	// Carregar sprite da Barra
	gRecursos.carregarSpriteSheet("barra", "assets/sprites/barra.png", 1, 2);
	barra.setSpriteSheet("barra");
	barra.setVelocidadeAnimacao(2);

	// Carregar sprite das For�as do Jogador
	gRecursos.carregarSpriteSheet("forcasJogador", "assets/sprites/forcasJogador.png", 1, 11);

	// Carregar sprites dos jogadores
	gRecursos.carregarSpriteSheet("p1", "assets/sprites/p1.png", 4, 3);
	gRecursos.carregarSpriteSheet("p2", "assets/sprites/p2.png", 4, 3);

	// Carregar sprites da Equipe Rocket
	gRecursos.carregarSpriteSheet("rocket1", "assets/sprites/rocket1.png", 4, 3);
	gRecursos.carregarSpriteSheet("rocket2", "assets/sprites/rocket2.png", 4, 3);

	// Carregar sprite do Ginasio
	gRecursos.carregarSpriteSheet("ginasio", "assets/sprites/ginasio.png");
	gRecursos.carregarSpriteSheet("forcasGinasio", "assets/sprites/forcasGinasio.png", 1, 5);

	// Carregar sprites dos Letroes
	gRecursos.carregarSpriteSheet("letras", "assets/sprites/letras.png", 1, 7);

	// Carregar sprites dos Ovos
	gRecursos.carregarSpriteSheet("ovos", "assets/sprites/ovos.png", 1, 3);

	// Carregar sprites das pokebolas
	gRecursos.carregarSpriteSheet("pb1", "assets/sprites/pokebola1.png");
	gRecursos.carregarSpriteSheet("pb2", "assets/sprites/pokebola2.png");
	gRecursos.carregarSpriteSheet("pb3", "assets/sprites/pokebola3.png");
	gRecursos.carregarSpriteSheet("pokebolasGirando", "assets/sprites/pokebolas.png", 4, 12);

	// Carregar sprite da Pokecoin
	gRecursos.carregarSpriteSheet("pokecoin", "assets/sprites/pokecoins.png");

	// Carregar sprites dos Pokemons
	gRecursos.carregarSpriteSheet("pokemons", "assets/sprites/pokemons.png", 10, 15);

	// Carregar sprite da Pokestop
	gRecursos.carregarSpriteSheet("pokestop", "assets/sprites/pokestop.png");

	// Carregar sprite da Vida
	gRecursos.carregarSpriteSheet("vida", "assets/sprites/vida.png", 1, 14);

	// Carregar sprite do HUD
	gRecursos.carregarSpriteSheet("hud", "assets/sprites/hud.png");
	hud.setSpriteSheet("hud");

	// Configurar textos das telas de creditos, instrucoes e de confirmar
	gRecursos.carregarFonte("fonte", "fonte_padrao.ttf", 48);
	gRecursos.carregarFonte("fonte2", "fonte_padrao.ttf", 18);
	textos[0].setFonte("fonte");
	textos[0].setString("Cr�ditos\nGiuseppe Moroni Ramella");
	textos[0].setCor(255, 0, 0);
	textos[1].setFonte("fonte");
	textos[1].setString("Instru��es\nS� vai...");
	textos[1].setCor(0, 255, 0);
	textos[2].setFonte("fonte");
	textos[2].setString("Deseja realmente sair?");
	textos[2].setCor(0, 0, 255);

	// Inicializar jogadores
	jogadores[0].inicializar((gJanela.getLargura() / 2) - 50, (gJanela.getAltura() / 2) + 50, 4, 0);
	jogadores[1].inicializar((gJanela.getLargura() / 2) + 50, (gJanela.getAltura() / 2) + 50, 4, 1);

	// Inicializar pokebolas
	pokebolas[0].inicializar(jogadores[0].getX(), jogadores[0].getY() - 40);
	pokebolas[1].inicializar(jogadores[1].getX(), jogadores[1].getY() - 40);

	//gdPokemons.inicializar(1);
	//gdPokebolas.inicializar();
	contadorDeFrames = 0;

	musicaPausadaPorJogador = false;

	placar.setFonte("fonte");
	placar.setCor(255, 0, 0);

	// Comecar na tela inicial
	status = tInicial;

	// Pegar altura das sprites da Equipe Rocket
	Sprite rocket1, rocket2;
	rocket1.setSpriteSheet("rocket1");
	rocket2.setSpriteSheet("rocket2");

	// Pegar altura da sprite do Ginasio
	Sprite ginasio;
	ginasio.setSpriteSheet("ginasio");

	// Pegar altura das sprites dos Letroes
	Sprite letras;
	letras.setSpriteSheet("letras");

	// Pegar altura das sprites dos Ovos
	Sprite ovos;
	ovos.setSpriteSheet("ovos");

	// Pegar altura das sprites das pokebolas
	Sprite pokebolas;
	pokebolas.setSpriteSheet("pokebolas");

	// Pegar altura das sprite da Pokecoin
	Sprite pokecoins;
	pokecoins.setSpriteSheet("pokecoins");

	// Pegar altura das sprites dos Pokemons
	Sprite pokemons;
	pokemons.setSpriteSheet("pokemons");

	// Pegar altura da sprite da Pokestop
	Sprite pokestop;
	pokestop.setSpriteSheet("pokestop");

	// Pegar altura da sprite da Vida
	Sprite vida;
	vida.setSpriteSheet("vida");
	int yRocket_ = rocket1.getAltura() / 2, yGinasio_ = ginasio.getAltura() / 2, yLetrao_ = letras.getAltura() / 2, yOvo_ = ovos.getAltura() / 2, yPokebola_ = pokebolas.getAltura() / 2, yPokecoin_ = pokecoins.getAltura() / 2, yPokemon_ = pokemons.getAltura() / 2, yPokestop_ = pokestop.getAltura() / 2, yVida_ = vida.getAltura() / 2;
	gerenciador.inicializar();

	for (int i = 0; i < 3; i++)
	{
		pokebolasHUD[i].setSpriteSheet("pokebolasGirando");
		pokebolasHUD[i].setVelocidadeAnimacao(8);
		pokebolasHUD[i].setAnimacao(i);
	}

	novoNomeProRanking = "";
	codNovoNome = -1;
	lerRanking();
}

void Jogo::finalizar()
{
	gRecursos.descarregarTudo();
	uniFinalizar();
}

void Jogo::executar()
{
	while (!gEventos.sair && status != tSair)
	{
		uniIniciarFrame();
		switch (status)
		{
		case tInicial: gMouse.mostrarCursor(); telaInicial(); break;
		case tJogo: gMouse.esconderCursor(); telaJogo(); break;
		case tPausa: gMouse.mostrarCursor(); telaPausa(); break;
		case tCreditos: gMouse.mostrarCursor(); telaCreditos(); break;
		case tInstrucoes: gMouse.mostrarCursor(); telaInstrucoes(); break;
		case tConfirmar: gMouse.mostrarCursor(); telaConfirmar(statusAnterior, tSair); break;
		case tGinasios: gMouse.mostrarCursor(); telaGinasios(); break;
		case tLetras: gMouse.mostrarCursor(); telaLetras(); break;
		case tOvos: gMouse.mostrarCursor(); telaOvos(); break;
		case tPokedex: gMouse.mostrarCursor(); telaPokedex(); break;
		case tRanking: gMouse.mostrarCursor(); telaRanking(); break;
		case tGameover: gMouse.mostrarCursor(); telaGameover(); break;
		case tNome: gMouse.mostrarCursor(); telaNome(); break;
		}
		uniTerminarFrame();
	}
}