#include "Letrao.h"

Letrao::Letrao()
{
}

Letrao::~Letrao()
{
}

void Letrao::inicializar(int x_, int y_, int velocidade_, int qual)
{
	Objeto::inicializar(1, x_, y_, velocidade_, "letras", qual);
}

void Letrao::atualizar()
{
	Objeto::atualizar();
}

void Letrao::desenhar()
{
	Objeto::desenhar();
}

Sprite & Letrao::getSprite()
{
	Objeto::getSprite();
}

int Letrao::getX()
{
	Objeto::getX();
}

int Letrao::getY()
{
	Objeto::getY();
}

void Letrao::setY(int y_)
{
	Objeto::setY(y_);
}
