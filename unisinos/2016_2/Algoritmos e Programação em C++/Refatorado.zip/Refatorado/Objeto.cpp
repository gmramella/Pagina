#include "Objeto.h"

using namespace std;

Objeto::Objeto()
{
}

Objeto::~Objeto()
{
}

void Objeto::inicializar(int cod, int var1, int var2, int var3, std::string var4, int var5)
{
	x = var1;
	y = var2;
	velocidade = var3;
	sprite.setSpriteSheet(var4);
	switch(cod)
	{
		case 0:// "ginasio", "pokebola", "pokecoin", "pokestop", "rocket", "vida" | 0, 0, 0, 10
			sprite.setVelocidadeAnimacao(var5);// pokestop girando?, var5 = qntd de frames da sprite?
			sprite.setAnimacao(0);
			sprite.setFrame(0);
			break;
		case 1:// "letras", "ovos"
			sprite.setVelocidadeAnimacao(0);
			sprite.setAnimacao(0);
			sprite.setFrame(var5);
			break;
		case 2:// "pokemons"
			sprite.setVelocidadeAnimacao(0);
			sprite.setAnimacao((int)floor(var5 / 15));
			sprite.setFrame(var5 % 15);
			break;
	}
}

void Objeto::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Objeto::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Objeto::getSprite()
{
	return sprite;
}

int Objeto::getX()
{
	return x;
}

int Objeto::getY()
{
	return y;
}

void Objeto::setY(int y_)
{
	y = y_;
}
