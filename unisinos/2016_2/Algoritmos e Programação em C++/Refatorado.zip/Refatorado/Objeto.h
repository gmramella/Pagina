#pragma once
#include "libUnicornio.h"
#include "Objeto.h"

class Objeto
{
	public:
		Objeto();
		~Objeto();
		
		void inicializar(int cod, int var1, int var2, int var3, std::string var4, int var5);
		void atualizar();
		void desenhar();

		Sprite & getSprite();
		int getX();
		int getY();
		
		void setY(int y_);

	private:
		Sprite sprite;
		int x;
		int y;
		int velocidade;
};
