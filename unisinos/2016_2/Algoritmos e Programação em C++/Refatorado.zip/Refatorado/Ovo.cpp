#include "Ovo.h"

Ovo::Ovo()
{
}

Ovo::~Ovo()
{
}

void Ovo::inicializar(int x_, int y_, int velocidade_, int qual)
{
	Objeto::inicializar(1, x_, y_, velocidade_, "ovos", qual);
}

void Ovo::atualizar()
{
	Objeto::atualizar();
}

void Ovo::desenhar()
{
	Objeto::desenhar();
}

Sprite & Ovo::getSprite()
{
	Objeto::getSprite();
}

int Ovo::getX()
{
	Objeto::getX();
}

int Ovo::getY()
{
	Objeto::getY();
}

void Ovo::setY(int y_)
{
	Objeto::setY(y_);
}
