#include "Pokebola.h"

Pokebola::Pokebola()
{
}

Pokebola::~Pokebola()
{
}

void Pokebola::inicializar(int x_, int y_, int velocidade_, int velocidadeAnimacao)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "pokebolas", velocidadeAnimacao);
}

void Pokebola::atualizar()
{
	Objeto::atualizar();
}

void Pokebola::atualizar(int x_, int y_)
{
	sprite.avancarAnimacao();
	x = x_;
	y = y_;
}

void Pokebola::desenhar()
{
	Objeto::desenhar();
}

Sprite & Pokebola::getSprite()
{
	Objeto::getSprite();
}

int Pokebola::getX()
{
	Objeto::getX();
}

int Pokebola::getY()
{
	Objeto::getY();
}

void Pokebola::setY(int y_)
{
	Objeto::setY(y_);
}
