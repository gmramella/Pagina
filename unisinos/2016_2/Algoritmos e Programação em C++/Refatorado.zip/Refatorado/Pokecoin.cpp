#include "Pokecoin.h"

Pokecoin::Pokecoin()
{
}

Pokecoin::~Pokecoin()
{
}

void Pokecoin::inicializar(int x_, int y_, int velocidade_)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "pokecoin", 0);
}

void Pokecoin::atualizar()
{
	Objeto::atualizar();
}

void Pokecoin::desenhar()
{
	Objeto::desenhar();
}

Sprite & Pokecoin::getSprite()
{
	Objeto::getSprite();
}

int Pokecoin::getX()
{
	Objeto::getX();
}

int Pokecoin::getY()
{
	Objeto::getY();
}

void Pokecoin::setY(int y_)
{
	Objeto::setY(y_);
}
