#include "Pokemon.h"

Pokemon::Pokemon()
{
}

Pokemon::~Pokemon()
{
}

void Pokemon::inicializar(int x_, int y_, int velocidade_, int qual)
{
	Objeto::inicializar(2, x_, y_, velocidade_, "pokemons", qual);
}

void Pokemon::atualizar()
{
	Objeto::atualizar();
}

void Pokemon::desenhar()
{
	Objeto::desenhar();
}

Sprite & Pokemon::getSprite()
{
	Objeto::getSprite();
}

int Pokemon::getX()
{
	Objeto::getX();
}

int Pokemon::getY()
{
	Objeto::getY();
}

void Pokemon::setY(int y_)
{
	Objeto::setY(y_);
}
