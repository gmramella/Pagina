#include "Pokestop.h"

Pokestop::Pokestop()
{
}

Pokestop::~Pokestop()
{
}

void Pokestop::inicializar(int x_, int y_, int velocidade_)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "pokestop", 0);//pokestop girando?
}

void Pokestop::atualizar()
{
	Objeto::atualizar();
}

void Pokestop::desenhar()
{
	Objeto::desenhar();
}

Sprite & Pokestop::getSprite()
{
	Objeto::getSprite();
}

int Pokestop::getX()
{
	Objeto::getX();
}

int Pokestop::getY()
{
	Objeto::getY();
}

void Pokestop::setY(int y_)
{
	Objeto::setY(y_);
}
