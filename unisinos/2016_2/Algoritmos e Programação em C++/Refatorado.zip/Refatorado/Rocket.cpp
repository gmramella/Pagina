#include "Rocket.h"

Rocket::Rocket()
{
}

Rocket::~Rocket()
{
}

void Rocket::inicializar(int x_, int y_, int velocidade_, int qual)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "rocket" + std::to_string(qual + 1), 8);
}

void Rocket::atualizar()
{
	Objeto::atualizar();
}

void Rocket::desenhar()
{
	Objeto::desenhar();
}

Sprite & Rocket::getSprite()
{
	Objeto::getSprite();
}

int Rocket::getX()
{
	Objeto::getX();
}

int Rocket::getY()
{
	Objeto::getY();
}

void Rocket::setY(int y_)
{
	Objeto::setY(y_);
}
