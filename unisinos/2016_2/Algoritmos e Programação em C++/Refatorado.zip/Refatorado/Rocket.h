#pragma once
#include "libUnicornio.h"
#include "Objeto.h"

class Rocket : public Objeto
{
	public:
		Rocket();
		~Rocket();
		
		void inicializar(int x_, int y_, int velocidade_, int qual);
		void atualizar();
		void desenhar();

		Sprite & getSprite();
		int getX();
		int getY();

		void setY(int y_);

	private:
		Sprite sprite;
		int x;
		int y;
		int velocidade;
};
