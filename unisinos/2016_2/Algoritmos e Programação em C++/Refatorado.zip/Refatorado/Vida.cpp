#include "Vida.h"

Vida::Vida()
{
}

Vida::~Vida()
{
}

void Vida::inicializar(int x_, int y_, int velocidade_)
{
	Objeto::inicializar(0, x_, y_, velocidade_, "vida", 10);//velocidadeAnimacao = qntd de frames da sprite?
}

void Vida::atualizar()
{
	Objeto::atualizar();
}

void Vida::desenhar()
{
	Objeto::desenhar();
}

Sprite & Vida::getSprite()
{
	Objeto::getSprite();
}

int Vida::getX()
{
	Objeto::getX();
}

int Vida::getY()
{
	Objeto::getY();
}

void Vida::setY(int y_)
{
	Objeto::setY(y_);
}
