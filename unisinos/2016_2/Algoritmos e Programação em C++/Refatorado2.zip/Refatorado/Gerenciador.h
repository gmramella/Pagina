#pragma once
#include "libUnicornio.h"
#include "Jogador.h"
#include "Ginasio.h"
#include "Letrao.h"
#include "Ovo.h"
#include "Pokebola.h"
#include "Pokecoin.h"
#include "Pokemon.h"
#include "Pokestop.h"
#include "Rocket.h"
#include "Vida.h"

class Gerenciador
{
private:
	int velocidadeGlobal;

	Ginasio ginasio;

	Letrao letrao;
	int letraoAtual;

	Ovo ovo;
	Pokebola pokebola;
	Pokecoin pokecoin;

	Pokemon pokemons[10 * 15];
	bool isPokemonMostrado[10 * 15];
	vector<int> idsAtuais, posxAtuais, poderesAtuais;
	/*
	http://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_evolution_family
	http://www.giantbomb.com/profile/wakka/lists/the-150-original-pokemon/59579/
	*/
	int tabelaDeEvolucoes[10 * 15] = { 0,1,2,0,1,2,0,1,2,0,1,2,0,1,2,1,2,0,1,0,1,0,1,1,2,0,1,0,1,2,1,2,1,2,0,1,1,2,0,1,0,1,2,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,2,0,2,0,1,2,0,1,2,0,1,0,1,2,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,2,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,1,0,1,1,1,0,0,1,0,0,0,1,1,1,0,0,1,0,1,0,1,0,0,0,1,2,0,0,0,0,0,1,1,1,0,0 };

	Pokestop pokestop;
	Rocket rocket[2];
	Vida vida;

	int xGinasio, yGinasio, yGinasioInicial, forcaGinasioAtual;
	int xLetrao, yLetrao, yLetraoInicial;
	int xOvo, yOvo, yOvoInicial, codKmOvo;
	int xPokebola, yPokebola, yPokebolaInicial, poderPokebola;
	int xPokecoin, yPokecoin, yPokecoinInicial;
	int xPokemon, yPokemon, yPokemonInicial, quantidadeDePokemonsPorVez, quantidadeMostradaAtual;
	int xPokestop, yPokestop, yPokestopInicial;
	int xRocket[2], yRocket, yRocketInicial;
	int xVida, yVida, yVidaInicial;

	int sortearGinasio();
	int sortearLetrao();
	int sortearOvo();
	int sortearPokebola();
	void sortearPokecoin();
	int sortearPokemon();
	int sortearPoder(int evolucao);
	void sortearPokestop();
	void sortearRocket();
	void sortearVida();

	int sortearX(int largura);
	int sortearForca();

	void atualizarGinasio();
	void atualizarLetrao();
	void atualizarOvo();
	void atualizarPokebola();
	void atualizarPokecoin();
	void atualizarPokemon();
	void atualizarPokestop();
	void atualizarRocket();
	void atualizarVida();

	void desenharGinasio();
	void desenharLetrao();
	void desenharOvo();
	void desenharPokebola();
	void desenharPokecoin();
	void desenharPokemon();
	void desenharPokestop();
	void desenharRocket();
	void desenharVida();

public:
	Gerenciador();
	~Gerenciador();
	void inicializar(int velocidadeGlobal_);
	void gerenciar(Jogador* jogadores, int tempo, int velocidadeGlobal_);
};
