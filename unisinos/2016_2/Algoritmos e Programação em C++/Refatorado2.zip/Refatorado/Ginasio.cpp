#include "Ginasio.h"

Ginasio::Ginasio()
{
}

Ginasio::~Ginasio()
{
}

void Ginasio::inicializar(int x_, int y_, int velocidade_)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("ginasio");
	sprite.setVelocidadeAnimacao(0);
	sprite.setAnimacao(0);
	sprite.setFrame(0);
}

void Ginasio::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Ginasio::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Ginasio::getSprite()
{
	return sprite;
}

int Ginasio::getX()
{
	return x;
}

int Ginasio::getY()
{
	return y;
}

void Ginasio::setY(int y_)
{
	y = y_;
}
