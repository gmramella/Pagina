#include "Letrao.h"

Letrao::Letrao()
{
}

Letrao::~Letrao()
{
}

void Letrao::inicializar(int x_, int y_, int velocidade_, int qual)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("letras");
	sprite.setVelocidadeAnimacao(0);
	sprite.setAnimacao(0);
	sprite.setFrame(qual);
}

void Letrao::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Letrao::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Letrao::getSprite()
{
	return sprite;
}

int Letrao::getX()
{
	return x;
}

int Letrao::getY()
{
	return y;
}

void Letrao::setY(int y_)
{
	y = y_;
}
