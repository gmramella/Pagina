#pragma once
#include "libUnicornio.h"
#include <vector>
#include <fstream>
#include <ios>

class Log
{
	Log();
	~Log();

	static void logOvos(int op, int codKm, int tempo, std::vector<int> codsRachados, int idxPrimeiroOvoCadaKm[3], std::vector<int> kmsOvos, std::vector<int> codsKmsOvos);
	static void logOvos(int op, int pokemonSorteado, int poderSorteado, int codRachado);
};
