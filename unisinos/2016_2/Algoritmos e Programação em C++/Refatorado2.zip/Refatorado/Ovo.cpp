#include "Ovo.h"

Ovo::Ovo()
{
}

Ovo::~Ovo()
{
}

void Ovo::inicializar(int x_, int y_, int velocidade_, int qual)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("ovos");
	sprite.setVelocidadeAnimacao(0);
	sprite.setAnimacao(0);
	sprite.setFrame(qual);
}

void Ovo::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Ovo::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Ovo::getSprite()
{
	return sprite;
}

int Ovo::getX()
{
	return x;
}

int Ovo::getY()
{
	return y;
}

void Ovo::setY(int y_)
{
	y = y_;
}
