#include "Pokebola.h"

Pokebola::Pokebola()
{
}

Pokebola::~Pokebola()
{
}

void Pokebola::inicializar(int x_, int y_, int velocidade_, int velocidadeAnimacao, int poder_)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("pokebolas");
	sprite.setVelocidadeAnimacao(velocidadeAnimacao);
	sprite.setAnimacao(0);
	sprite.setFrame(0);
	poder = poder_;
}

void Pokebola::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Pokebola::atualizar(int x_, int y_)
{
	sprite.avancarAnimacao();
	x = x_;
	y = y_;
}

void Pokebola::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Pokebola::getSprite()
{
	return sprite;
}

int Pokebola::getX()
{
	return x;
}

int Pokebola::getY()
{
	return y;
}

int Pokebola::getPoder()
{
	return poder;
}

void Pokebola::setY(int y_)
{
	y = y_;
}

void Pokebola::setPoder(int poder_)
{
	poder = poder_;
}
