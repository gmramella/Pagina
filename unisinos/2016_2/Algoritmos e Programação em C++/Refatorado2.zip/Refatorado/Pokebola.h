#pragma once
#include "libUnicornio.h"

class Pokebola
{
public:
	Pokebola();
	~Pokebola();

	void inicializar(int x_, int y_, int velocidade_, int velocidadeAnimacao, int poder_);
	void atualizar();
	void atualizar(int x_, int y_);
	void desenhar();

	Sprite & getSprite();
	int getX();
	int getY();
	int getPoder();

	void setY(int y_);
	void setPoder(int poder_);

private:
	Sprite sprite;
	int x;
	int y;
	int velocidade;
	int poder;
};
