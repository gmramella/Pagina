#include "Pokecoin.h"

Pokecoin::Pokecoin()
{
}

Pokecoin::~Pokecoin()
{
}

void Pokecoin::inicializar(int x_, int y_, int velocidade_)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("pokecoin");
	sprite.setVelocidadeAnimacao(0);
	sprite.setAnimacao(0);
	sprite.setFrame(0);
}

void Pokecoin::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Pokecoin::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Pokecoin::getSprite()
{
	return sprite;
}

int Pokecoin::getX()
{
	return x;
}

int Pokecoin::getY()
{
	return y;
}

void Pokecoin::setY(int y_)
{
	y = y_;
}
