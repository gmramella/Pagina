#include "Pokemon.h"

Pokemon::Pokemon()
{
}

Pokemon::~Pokemon()
{
}

void Pokemon::inicializar(int x_, int y_, int velocidade_, int qual)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("pokemons");
	sprite.setVelocidadeAnimacao(0);
	sprite.setAnimacao((int)floor(qual / 15));
	sprite.setFrame(qual % 15);
}

void Pokemon::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Pokemon::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Pokemon::getSprite()
{
	return sprite;
}

int Pokemon::getX()
{
	return x;
}

int Pokemon::getY()
{
	return y;
}

void Pokemon::setY(int y_)
{
	y = y_;
}
