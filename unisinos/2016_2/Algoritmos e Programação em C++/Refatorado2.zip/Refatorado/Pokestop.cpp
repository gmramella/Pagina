#include "Pokestop.h"

Pokestop::Pokestop()
{
}

Pokestop::~Pokestop()
{
}

void Pokestop::inicializar(int x_, int y_, int velocidade_)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("pokestop");
	sprite.setVelocidadeAnimacao(0);// pokestop girando?, var5 = qntd de frames da sprite?
	sprite.setAnimacao(0);
	sprite.setFrame(0);
}

void Pokestop::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Pokestop::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Pokestop::getSprite()
{
	return sprite;
}

int Pokestop::getX()
{
	return x;
}

int Pokestop::getY()
{
	return y;
}

void Pokestop::setY(int y_)
{
	y = y_;
}
