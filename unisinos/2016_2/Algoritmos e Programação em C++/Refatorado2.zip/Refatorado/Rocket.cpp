#include "Rocket.h"

Rocket::Rocket()
{
}

Rocket::~Rocket()
{
}

void Rocket::inicializar(int x_, int y_, int velocidade_, int qual)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("rocket" + std::to_string(qual + 1));
	sprite.setVelocidadeAnimacao(8);
	sprite.setAnimacao(0);
	sprite.setFrame(0);
}

void Rocket::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Rocket::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Rocket::getSprite()
{
	return sprite;
}

int Rocket::getX()
{
	return x;
}

int Rocket::getY()
{
	return y;
}

void Rocket::setY(int y_)
{
	y = y_;
}
