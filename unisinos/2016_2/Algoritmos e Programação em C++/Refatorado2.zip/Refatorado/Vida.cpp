
#include "Vida.h"

Vida::Vida()
{
}

Vida::~Vida()
{
}

void Vida::inicializar(int x_, int y_, int velocidade_)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	sprite.setSpriteSheet("vida");
	sprite.setVelocidadeAnimacao(10);//velocidadeAnimacao = qntd de frames da sprite? (14)
	sprite.setAnimacao(0);
	sprite.setFrame(0);
}

void Vida::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Vida::desenhar()
{
	sprite.desenhar(x, y);
}

Sprite & Vida::getSprite()
{
	return sprite;
}

int Vida::getX()
{
	return x;
}

int Vida::getY()
{
	return y;
}

void Vida::setY(int y_)
{
	y = y_;
}
