#pragma once
#include "libUnicornio.h"

class Vida
{
public:
	Vida();
	~Vida();

	void inicializar(int x_, int y_, int velocidade_);
	void atualizar();
	void desenhar();

	Sprite & getSprite();
	int getX();
	int getY();

	void setY(int y_);

private:
	Sprite sprite;
	int x;
	int y;
	int velocidade;
};
