#include "Pais.h"

Pais::Pais(string nome_, string capital_, float dimensao_)
{
	nome = nome_;
	capital = capital_;
	dimensao = dimensao_;
	tamanho = 0;
}

Pais::~Pais()
{
	delete[] vizinhos;
}

float Pais::getDimensao()
{
	return dimensao;
}

void Pais::setQtdPaisesVizinhos(int nPaises)
{
	if (tamanho == 0) {
		string *temp = new string[nPaises];
		vizinhos = temp;
		tamanho = nPaises;
	}
	else if (tamanho > nPaises) {
		string *temp = new string[nPaises];
		for (int i = 0; i < nPaises; i++) {
			temp[i] = vizinhos[i];
		}
		delete[] vizinhos;
		vizinhos = temp;
		tamanho = nPaises;
	} else {
		string *temp = new string[nPaises];
		for (int i = 0; i < tamanho; i++) {
			temp[i] = vizinhos[i];
		}
		delete[] vizinhos;
		vizinhos = temp;
		tamanho = nPaises;
	}
}

void Pais::adicionaVizinhos()
{
	int qntd;
	cout << "Quantos novos: ";
	cin >> qntd;

	if (tamanho == 0) {
		string *temp = new string[qntd];
		for (int i = 0; i < qntd; i++) {
			cout << "Nome do pais: ";
			cin >> temp[i];
		}
		vizinhos = temp;
		tamanho = qntd;
	}
	else {
		string *temp = new string[tamanho + qntd];
		for (int i = 0; i < tamanho; i++) {
			temp[i] = vizinhos[i];
		}
		for (int i = tamanho; i < tamanho + qntd; i++) {
			cout << "Nome do pais: ";
			cin >> temp[i];
		}
		delete[] vizinhos;
		vizinhos = temp;
		tamanho += qntd;
	}
}

bool Pais::saoVizinhos(string testado)
{
	for (int i = 0; i < tamanho; i++) {
		if (vizinhos[i] == testado)
			return true;
	}
	return false;
}

void Pais::mostrarVizinhos()
{
	for (int i = 0; i < tamanho; i++) {
		cout << vizinhos[i] << endl;
	}
}
