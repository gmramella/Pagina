#pragma once
#include <iostream>
#include <string>

using namespace std;

class Pais
{
public:
	Pais(string nome_, string capital_, float dimensao_);
	~Pais();
	float getDimensao();
	void setQtdPaisesVizinhos(int nPaises);
	void adicionaVizinhos();
	bool saoVizinhos(string testado);
	void mostrarVizinhos();
private:
	string nome;
	string capital;
	float dimensao;
	string *vizinhos;
	int tamanho;
};

