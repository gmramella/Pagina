#include "Pais.h"
#include <cstdlib>
#include <time.h>

int ex2(int tamanho, int vetor[]) {
	int total = 0;
	for (int i = 0; i < tamanho; i++) {
		total += i * vetor[i];
	}
	return total;
}

char* ex3(int n) {
	char *vetor = new char[n];
	for (int i = 0; i < n; i++) {
		vetor[i] = (char)('A' + rand() % 26);
	}
	return vetor;
}

int** ex4() {
	int **matriz = new int*[4];
	for (int i = 0; i < 4; i++) {
		matriz[i] = new int[4];
	}
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			matriz[i][j] = 1 + 2 * i + 8 * j;
		}
	}
	return matriz;
}

int main() {
	srand(time(NULL));
	Pais p("Brasil", "Brasilia", 8515767.0);
	cout << p.getDimensao() << endl;
	p.setQtdPaisesVizinhos(0);
	p.adicionaVizinhos();
	p.mostrarVizinhos();
	cout << p.saoVizinhos("Uruguai") << endl;
	cout << p.saoVizinhos("Equador") << endl;
	cout << endl;
	int v1[] = { 12,4,3,13,1,6,2,10 };
	cout << ex2(8, v1) << endl;
	cout << endl;
	int qntd;
	cout << "Quantas letras: ";
	cin >> qntd;
	char *v2 = ex3(qntd);
	for (int i = 0; i < qntd; i++) {
		cout << v2[i] << " ";
	}
	delete[] v2;
	cout << endl;
	int **matriz = ex4();
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			cout << matriz[i][j] << " ";
		}
		cout << endl;
	}
	for (int i = 0; i < 4; ++i)
		delete[] matriz[i];
	delete[] matriz;
	system("pause");
}