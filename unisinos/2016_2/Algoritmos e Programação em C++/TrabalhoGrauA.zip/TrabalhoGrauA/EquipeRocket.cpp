#include "EquipeRocket.h"

EquipeRocket::EquipeRocket()
{
}

EquipeRocket::~EquipeRocket()
{
}

void EquipeRocket::desenhar()
{
	for (int i = 0; i < 2; i++) {
		sprites[i].desenhar(x[i], y);
	}
}

void EquipeRocket::atualizar()
{
	for (int i = 0; i < 2; i++) {
		sprites[i].avancarAnimacao();
	}
	y += velocidade;
}

void EquipeRocket::inicializar(int x1_, int x2_, int y_)
{
	x[0] = x1_;
	x[1] = x2_;
	y = y_;
	velocidade = 6;
	for (int i = 0; i < 2; i++) {
		sprites[i].setVelocidadeAnimacao(8);
		sprites[i].setSpriteSheet("rocket" + to_string(i+1));
		sprites[i].setAnimacao(0);
		sprites[i].setFrame(0);
	}
}

int* EquipeRocket::getXs()
{
	int xs[] = { x[0], x[1] };
	return xs;
}

int EquipeRocket::getY()
{
	return y;
}

void EquipeRocket::setY(int y_)
{
	y = y_;
}

Sprite* EquipeRocket::getSprites()
{
	return sprites;
}
