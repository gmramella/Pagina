#pragma once
#include "libUnicornio.h"

class EquipeRocket
{
public:
	EquipeRocket();
	~EquipeRocket();
	void desenhar();
	void atualizar();
	void inicializar(int x1_, int x2_, int y_);
	int* getXs();
	int getY();
	void setY(int y_);
	Sprite* getSprites();

private:
	Sprite sprites[2];
	int x[2], y, velocidade;
};
