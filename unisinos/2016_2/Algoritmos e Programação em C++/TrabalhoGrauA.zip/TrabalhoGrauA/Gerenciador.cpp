#include "Gerenciador.h"

Gerenciador::Gerenciador()
{
}

Gerenciador::~Gerenciador()
{
}

void Gerenciador::inicializar(int yEquipeRocketInicial_, int yGinasioInicial_, int yLetraoInicial_, int yOvoInicial_, int yPokebolaInicial_, int yPokecoinInicial_, int yPokemonInicial_, int yPokestopInicial_, int yVidaInicial_)
{
	yEquipeRocketInicial = yEquipeRocketInicial_;
	yGinasioInicial = yGinasioInicial_;
	yLetraoInicial = yLetraoInicial_;
	yOvoInicial = yOvoInicial_;
	yPokebolaInicial = yPokebolaInicial_;
	yPokecoinInicial = yPokecoinInicial_;
	yPokemonInicial = yPokecoinInicial_;
	yPokestopInicial = yPokestopInicial_;
	yVidaInicial = yVidaInicial_;

	// Inicializar Equipe Rocket
	xEquipeRocket[2];
	yEquipeRocket = yEquipeRocketInicial;
	equipeRocket.setY(yEquipeRocketInicial);

	// Inicializar Ginasio
	xGinasio = -1;
	yGinasio = yGinasioInicial;
	ginasio.setY(yGinasioInicial);
	forcaGinasioAtual = -1;

	// Inicializar Letroes
	xLetrao = -1;
	yLetrao = yLetraoInicial;
	letrao.setY(yLetraoInicial);

	// Inicializar Ovos
	xOvo = -1;
	yOvo = yOvoInicial;
	ovo.setY(yOvoInicial);
	codKmOvo = -1;

	// Inicializar Pokebola
	xPokebola = -1;
	yPokebola = yPokebolaInicial;
	pokebola.setY(yPokebolaInicial);
	poderPokebola = -1;

	// Inicializar Pokecoin
	xPokecoin = -1;
	yPokecoin = yPokecoinInicial;
	pokecoin.setY(yPokecoinInicial);

	// Inicializar Pokemon
	xPokemon = -1;
	yPokemon = yPokemonInicial;
	pokemon.setY(yPokemonInicial);

	// Inicializar Pokestop
	xPokestop = -1;
	yPokestop = yPokestopInicial;
	pokestop.setY(yPokestopInicial);

	// Inicializar Vida
	xVida = -1;
	yVida = yVidaInicial;
	vida.setY(yVidaInicial);

	tempoMedioEntreEquipesRocket = 30;
	tempoMedioEntreGinasios = 30;
	tempoMedioEntreLetroes = 30;
	tempoMedioEntreOvos = 3;
	tempoMedioEntrePokebolas = 3;
	tempoMedioEntrePokecoins = 6;
	tempoMedioEntrePokemons = 3;
	tempoMedioEntrePokestops = 30;
	tempoMedioEntreVidas = 30;

	tempoMedioEntreEquipesRocket = 1;
	tempoMedioEntreGinasios = 1;
	tempoMedioEntreLetroes = 1;
	tempoMedioEntreOvos = 1;
	tempoMedioEntrePokebolas = 1;
	tempoMedioEntrePokecoins = 1;
	tempoMedioEntrePokemons = 1;
	tempoMedioEntrePokestops = 1;
	tempoMedioEntreVidas = 1;
}

void Gerenciador::gerenciar(Jogador * jogadores, int tempo)
{
	// Gerenciar Equipe Rocket
	if (equipeRocket.getY() > yEquipeRocketInicial && equipeRocket.getY() <= gJanela.getAltura())
	{
		if (equipeRocket.getY() - equipeRocket.getSprites()[0].getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yEquipeRocket = yEquipeRocketInicial;
			equipeRocket.setY(yEquipeRocketInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, equipeRocket.getSprites()[0], (float)(equipeRocket.getXs()[0]), (float)(equipeRocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouEquipeRocket(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouEquipeRocket(jogadores, 0);
				}
				else
				{

				}
			}
			yEquipeRocket = yEquipeRocketInicial;
			equipeRocket.setY(yEquipeRocketInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, equipeRocket.getSprites()[1], (float)(equipeRocket.getXs()[1]), (float)(equipeRocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouEquipeRocket(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouEquipeRocket(jogadores, 0);
				}
				else
				{

				}
			}
			yEquipeRocket = yEquipeRocketInicial;
			equipeRocket.setY(yEquipeRocketInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, equipeRocket.getSprites()[0], (float)(equipeRocket.getXs()[0]), (float)(equipeRocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouEquipeRocket(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouEquipeRocket(jogadores, 1);
				}
				else
				{

				}
			}
			yEquipeRocket = yEquipeRocketInicial;
			equipeRocket.setY(yEquipeRocketInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, equipeRocket.getSprites()[1], (float)(equipeRocket.getXs()[1]), (float)(equipeRocket.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouEquipeRocket(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouEquipeRocket(jogadores, 1);
				}
				else
				{

				}
			}
			yEquipeRocket = yEquipeRocketInicial;
			equipeRocket.setY(yEquipeRocketInicial);
		}
		else
		{
			atualizarEquipeRocket();
			desenharEquipeRocket();
		}
	}
	else
	{
		sortearEquipeRocket();
	}

	// Gerenciar Ginasios
	if (ginasio.getY() > yGinasioInicial && ginasio.getY() <= gJanela.getAltura())
	{
		if (ginasio.getY() - ginasio.getSprites()[0].getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yGinasio = yGinasioInicial;
			ginasio.setY(yGinasioInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, ginasio.getSprites()[0], (float)(ginasio.getX()), (float)(ginasio.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouGinasio(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouGinasio(jogadores, 0);
				}
				else
				{

				}
			}
			yGinasio = yGinasioInicial;
			ginasio.setY(yGinasioInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, ginasio.getSprites()[0], (float)(ginasio.getX()), (float)(ginasio.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouGinasio(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouGinasio(jogadores, 1);
				}
				else
				{

				}
			}
			yGinasio = yGinasioInicial;
			ginasio.setY(yGinasioInicial);
		}
		else
		{
			atualizarGinasio();
			desenharGinasio();
		}
	}
	else
	{
		forcaGinasioAtual = sortearGinasio();
	}

	// Gerenciar Letroes
	if (letrao.getY() > yLetraoInicial && letrao.getY() <= gJanela.getAltura())
	{
		if (letrao.getY() - letrao.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yLetrao = yLetraoInicial;
			letrao.setY(yLetraoInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, letrao.getSprite(), (float)(letrao.getX()), (float)(letrao.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouLetrao(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouLetrao(jogadores, 0);
				}
				else
				{

				}
			}
			yLetrao = yLetraoInicial;
			letrao.setY(yLetraoInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, letrao.getSprite(), (float)(letrao.getX()), (float)(letrao.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouLetrao(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouLetrao(jogadores, 1);
				}
				else
				{

				}
			}
			yLetrao = yLetraoInicial;
			letrao.setY(yLetraoInicial);
		}
		else
		{
			atualizarLetrao();
			desenharLetrao();
		}
	}
	else
	{
		letraoAtual = sortearLetrao();
	}

	// Gerenciar Ovos
	if (ovo.getY() > yOvoInicial && ovo.getY() <= gJanela.getAltura())
	{
		if (ovo.getY() - ovo.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yOvo = yOvoInicial;
			ovo.setY(yOvoInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, ovo.getSprite(), (float)(ovo.getX()), (float)(ovo.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouOvo(jogadores, 0, tempo);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouOvo(jogadores, 0);
				}
				else
				{

				}
			}
			yOvo = yOvoInicial;
			ovo.setY(yOvoInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, ovo.getSprite(), (float)(ovo.getX()), (float)(ovo.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouOvo(jogadores, 1, tempo);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouOvo(jogadores, 1);
				}
				else
				{

				}
			}
			yOvo = yOvoInicial;
			ovo.setY(yOvoInicial);
		}
		else
		{
			atualizarOvo();
			desenharOvo();
		}
	}
	else
	{
		codKmOvo = sortearOvo();
	}

	// Gerenciar Pokebolas
	if (pokebola.getY() > yPokebolaInicial && pokebola.getY() <= gJanela.getAltura())
	{
		if (pokebola.getY() - pokebola.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yPokebola = yPokebolaInicial;
			pokebola.setY(yPokebolaInicial);
			poderPokebola = -1;
			pokebola.setPoder(poderPokebola);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokebola.getSprite(), (float)(pokebola.getX()), (float)(pokebola.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouPokebola(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouPokebola(jogadores, 0);
				}
				else
				{

				}
			}
			yPokebola = yPokebolaInicial;
			pokebola.setY(yPokebolaInicial);
			poderPokebola = -1;
			pokebola.setPoder(poderPokebola);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokebola.getSprite(), (float)(pokebola.getX()), (float)(pokebola.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouPokebola(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouPokebola(jogadores, 1);
				}
				else
				{

				}
			}
			yPokebola = yPokebolaInicial;
			pokebola.setY(yPokebolaInicial);
			poderPokebola = -1;
			pokebola.setPoder(poderPokebola);
		}
		else
		{
			atualizarPokebola();
			desenharPokebola();
		}
	}
	else
	{
		int novoPoder = sortearPokebola();
		if (novoPoder != -1)
		{
			pokebola.getSprite().setSpriteSheet("pb" + to_string(novoPoder + 1));
			poderPokebola = novoPoder;
		}
	}

	// Gerenciar Pokecoins
	if (pokecoin.getY() > yPokecoinInicial && pokecoin.getY() <= gJanela.getAltura())
	{
		if (pokecoin.getY() - pokecoin.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yPokecoin = yPokecoinInicial;
			pokecoin.setY(yPokecoinInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokecoin.getSprite(), (float)(pokecoin.getX()), (float)(pokecoin.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouPokecoin(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouPokecoin(jogadores, 0);
				}
				else
				{

				}
			}
			yPokecoin = yPokecoinInicial;
			pokecoin.setY(yPokecoinInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokecoin.getSprite(), (float)(pokecoin.getX()), (float)(pokecoin.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouPokecoin(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouPokecoin(jogadores, 1);
				}
				else
				{

				}
			}
			yPokecoin = yPokecoinInicial;
			pokecoin.setY(yPokecoinInicial);
		}
		else
		{
			atualizarPokecoin();
			desenharPokecoin();
		}
	}
	else
	{
		sortearPokecoin();
	}

	// Gerenciar Pokemons
	if (pokemon.getY() > yPokemonInicial && pokemon.getY() <= gJanela.getAltura())
	{
		if (pokemon.getY() - pokemon.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yPokemon = yPokemonInicial;
			pokemon.setY(yPokemonInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokemon.getSprite(), (float)(pokemon.getX()), (float)(pokemon.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar() && jogadores[0].getTipoDaPokebola() >= tabelaDeEvolucoes[pokemonAtual] && jogadores[0].getPokebolas()[jogadores[0].getTipoDaPokebola()] > 0)
			{
				pegouPokemon(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouPokemon(jogadores, 0);
				}
				else
				{

				}
			}
			yPokemon = yPokemonInicial;
			pokemon.setY(yPokemonInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokemon.getSprite(), (float)(pokemon.getX()), (float)(pokemon.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar() && jogadores[1].getTipoDaPokebola() >= tabelaDeEvolucoes[pokemonAtual] && jogadores[1].getPokebolas()[jogadores[1].getTipoDaPokebola()] > 0)
			{
				pegouPokemon(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouPokemon(jogadores, 1);
				}
				else
				{

				}
			}
			yPokemon = yPokemonInicial;
			pokemon.setY(yPokemonInicial);
		}
		else
		{
			atualizarPokemon();
			desenharPokemon();
		}
	}
	else
	{
		/*
		// Tem que ser com double
		int cod = sortearPokemon();
		if (cod != -1)
		{
			int cont;
			cont = 0;
			while ((cod % 2) == 0)
			{
				cont++;
				cod = (int)(cod / 2);
			}
			pokemonAtual = 15 * cont;
			cont = 0;
			while ((cod % 3) == 0)
			{
				cont++;
				cod = (int)(cod / 3);
			}
			pokemonAtual += cont;
			cont = 0;
			while ((cod % 5) == 0)
			{
				cont++;
				cod = (int)(cod / 5);
			}
			poderAtual = cont;
		}*/
		pokemonAtual = sortearPokemon();
	}

	// Gerenciar Pokestops
	if (pokestop.getY() > yPokestopInicial && pokestop.getY() <= gJanela.getAltura())
	{
		if (pokestop.getY() - pokestop.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yPokestop = yPokestopInicial;
			pokestop.setY(yPokestopInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, pokestop.getSprite(), (float)(pokestop.getX()), (float)(pokestop.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouPokestop(jogadores, 0, tempo);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouPokestop(jogadores, 0);
				}
				else
				{

				}
			}
			yPokestop = yPokestopInicial;
			pokestop.setY(yPokestopInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, pokestop.getSprite(), (float)(pokestop.getX()), (float)(pokestop.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouPokestop(jogadores, 1, tempo);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouPokestop(jogadores, 1);
				}
				else
				{

				}
			}
			yPokestop = yPokestopInicial;
			pokestop.setY(yPokestopInicial);
		}
		else
		{
			atualizarPokestop();
			desenharPokestop();
		}
	}
	else
	{
		sortearPokestop();
	}

	// Gerenciar Vidas
	if (vida.getY() > yVidaInicial && vida.getY() <= gJanela.getAltura())
	{
		if (vida.getY() - vida.getSprite().getAltura() / 2 >= gJanela.getAltura() - 184)
		{
			yVida = yVidaInicial;
			vida.setY(yVidaInicial);
		}
		else if (uniTestarColisao(jogadores[0].getSprite(), (float)(jogadores[0].getX()), (float)(jogadores[0].getY()), 0, vida.getSprite(), (float)(vida.getX()), (float)(vida.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[0].getTeclaPegar()] && jogadores[0].getPodePegar())
			{
				pegouVida(jogadores, 0);
			}
			else
			{
				if (jogadores[0].getVulneravel())
				{
					naoPegouVida(jogadores, 0);
				}
				else
				{

				}
			}
			yVida = yVidaInicial;
			vida.setY(yVidaInicial);
		}
		else if (uniTestarColisao(jogadores[1].getSprite(), (float)(jogadores[1].getX()), (float)(jogadores[1].getY()), 0, vida.getSprite(), (float)(vida.getX()), (float)(vida.getY()), 0))
		{
			if (gTeclado.segurando[jogadores[1].getTeclaPegar()] && jogadores[1].getPodePegar())
			{
				pegouVida(jogadores, 1);
			}
			else
			{
				if (jogadores[1].getVulneravel())
				{
					naoPegouVida(jogadores, 1);
				}
				else
				{

				}
			}
			yVida = yVidaInicial;
			vida.setY(yVidaInicial);
		}
		else
		{
			atualizarVida();
			desenharVida();
		}
	}
	else
	{
		sortearVida();
	}
}

void Gerenciador::sortearEquipeRocket()
{
	if ((rand() % (60 * tempoMedioEntreEquipesRocket)) == 0)
	{
		xEquipeRocket[0] = sortearX(equipeRocket.getSprites()[0].getLargura());
		xEquipeRocket[1] = sortearX(equipeRocket.getSprites()[1].getLargura());
		equipeRocket.inicializar(xEquipeRocket[0], xEquipeRocket[1], ++yEquipeRocket);
	}
}

int Gerenciador::sortearGinasio()
{
	if ((rand() % (60 * tempoMedioEntreGinasios)) == 0)
	{
		xGinasio = sortearX(ginasio.getSprites()[0].getLargura());
		int forca = sortearForca();
		ginasio.inicializar(xGinasio, ++yGinasio, forca);
		return forca;
	}
	return -1;
}

int Gerenciador::sortearLetrao()
{
	if ((rand() % (60 * tempoMedioEntreLetroes)) == 0)
	{
		int sorteado = rand() % 7;
		xLetrao = sortearX(letrao.getSprite().getLargura());
		letrao.inicializar(xLetrao, ++yLetrao);
		letrao.getSprite().setFrame(sorteado);
		return sorteado;
	}
	return -1;
}

int Gerenciador::sortearOvo()
{
	if ((rand() % (60 * tempoMedioEntreOvos)) == 0)
	{
		xOvo = sortearX(ovo.getSprite().getLargura());
		int km = rand() % 3;
		ovo.inicializar(xOvo, ++yOvo, km);
		return km;
	}
	return -1;
}

int Gerenciador::sortearPokebola()
{
	if ((rand() % (60 * tempoMedioEntrePokebolas)) == 0)
	{
		int sorteado3 = rand() % 4;
		int sorteado2 = rand() % 2;
		int sorteado1 = rand() % 1;
		if (sorteado3 == 0) {
			int novoPoder = 2;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 2;
		}
		if (sorteado2 == 0) {
			int novoPoder = 1;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 1;
		}
		if (sorteado1 == 0) {
			int novoPoder = 0;
			xPokebola = sortearX(pokebola.getSprite().getLargura());
			pokebola.inicializar(xPokebola, ++yPokebola, novoPoder);
			return 0;
		}
	}
	return -1;
}

void Gerenciador::sortearPokecoin()
{
	if ((rand() % (60 * tempoMedioEntrePokecoins)) == 0)
	{
		xPokecoin = sortearX(pokecoin.getSprite().getLargura());
		pokecoin.inicializar(xPokecoin, ++yPokecoin);
	}
}

int Gerenciador::sortearPokemon()
{
	if ((rand() % (60 * tempoMedioEntrePokemons)) == 0)
	{
		xPokemon = sortearX(pokemon.getSprite().getLargura());
		int qual = rand() % 150;
		int poder = sortearPoder(tabelaDeEvolucoes[qual]);
		pokemon.inicializar(xPokemon, ++yPokemon, qual, poder);
		//return pow(2, (int)(qual / 15)) * pow(3, (qual % 15)) * pow(5, (poder % 15));
		return qual;
	}
	return -1;
}

/*
evolucao	poder
0			[0,1,2]
1			[1,2]
2			[2]
*/
int Gerenciador::sortearPoder(int evolucao)
{
	return (rand() % (3 - evolucao)) + evolucao;
}

void Gerenciador::sortearPokestop()
{
	if ((rand() % (60 * tempoMedioEntrePokestops)) == 0)
	{
		xPokestop = sortearX(pokestop.getSprite().getLargura());
		pokestop.inicializar(xPokestop, ++yPokestop);
	}
}

void Gerenciador::sortearVida()
{
	if ((rand() % (60 * tempoMedioEntreVidas)) == 0)
	{
		xVida = sortearX(vida.getSprite().getLargura());
		vida.inicializar(xVida, ++yVida);
	}
}

int Gerenciador::sortearX(int largura)
{
	return ((rand() % (gJanela.getLargura() - largura)) + (int)floor(largura / 2));
}

int Gerenciador::sortearForca()
{
	return (rand() % 5);
}

void Gerenciador::atualizarEquipeRocket()
{
	equipeRocket.atualizar();
}

void Gerenciador::atualizarGinasio()
{
	ginasio.atualizar();
}

void Gerenciador::atualizarLetrao()
{
	letrao.atualizar();
}

void Gerenciador::atualizarOvo()
{
	ovo.atualizar();
}

void Gerenciador::atualizarPokebola()
{
	pokebola.atualizar();
}

void Gerenciador::atualizarPokecoin()
{
	pokecoin.atualizar();
}

void Gerenciador::atualizarPokemon()
{
	pokemon.atualizar();
}

void Gerenciador::atualizarPokestop()
{
	pokestop.atualizar();
}

void Gerenciador::atualizarVida()
{
	vida.atualizar();
}

void Gerenciador::desenharEquipeRocket()
{
	equipeRocket.desenhar();
}

void Gerenciador::desenharGinasio()
{
	ginasio.desenhar();
}

void Gerenciador::desenharLetrao()
{
	letrao.desenhar();
}

void Gerenciador::desenharOvo()
{
	ovo.desenhar();
}

void Gerenciador::desenharPokebola()
{
	pokebola.desenhar();
}

void Gerenciador::desenharPokecoin()
{
	pokecoin.desenhar();
}

void Gerenciador::desenharPokemon()
{
	pokemon.desenhar();
}

void Gerenciador::desenharPokestop()
{
	pokestop.desenhar();
}

void Gerenciador::desenharVida()
{
	vida.desenhar();
}

void Gerenciador::pegouEquipeRocket(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].variarPontos(50);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouGinasio(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].incGinasios(forcaGinasioAtual);
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouLetrao(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].incQntdLetras(letraoAtual);
	jogadores[idxJogadores].setPegouLetroes(letraoAtual, true);
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouOvo(Jogador* jogadores, int idxJogadores, int tempo)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].incQntdOvos(codKmOvo);
	jogadores[idxJogadores].pegouOvo(tempo, codKmOvo);
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouPokebola(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].setPokebolas(poderPokebola, jogadores[idxJogadores].getPokebolas()[poderPokebola] + 1);
	jogadores[idxJogadores].variarPontos(10 * (poderPokebola + 1));
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouPokecoin(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].incPokecoins();
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouPokemon(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].setPegouPokemons(pokemonAtual, true);
	jogadores[idxJogadores].decPokebolas(jogadores[idxJogadores].getTipoDaPokebola());
	jogadores[idxJogadores].variarPontos(100 * (tabelaDeEvolucoes[pokemonAtual] + 1));
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::pegouPokestop(Jogador* jogadores, int idxJogadores, int tempo)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].incQntdPokestops();
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();

	int pontosGanhos = 0;
	for (int i = 0; i < 3; i++)
	{
		int sorteado = (rand() % (jogadores[idxJogadores].getPokebolas()[i] + 1));
		jogadores[idxJogadores].setPokebolas(i, jogadores[idxJogadores].getPokebolas()[i] + sorteado);
		pontosGanhos += 10 * sorteado;
	}
	for (int i = 0; i < 3; i++)
	{
		//int qntdNovos = (rand() % (jogadores[idxJogadores].getQntdsOvos()[i] + 1));
		int qntdNovos = (rand() % 2);
		jogadores[idxJogadores].setQntdsOvos(i, jogadores[idxJogadores].getQntdsOvos()[i] + qntdNovos);
		for (int j = 0; j < qntdNovos; j++)
		{
			jogadores[idxJogadores].pegouOvo(tempo, i);
			pontosGanhos += 10 * qntdNovos;
		}
	}
	//int qntdNovas = (rand() % (jogadores[idxJogadores].getVidas() + 1));
	int qntdNovas = (rand() % 2);
	for (int j = 0; j < qntdNovas; j++)
	{
		jogadores[idxJogadores].pegouVida();
	}
	pontosGanhos += 10 * qntdNovas;
	jogadores[idxJogadores].setPontos(jogadores[idxJogadores].getPontos() + pontosGanhos);
}

void Gerenciador::pegouVida(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].setPodePegar(false);
	jogadores[idxJogadores].pegouVida();
	jogadores[idxJogadores].variarPontos(10);
	jogadores[idxJogadores].getSomCaptura().tocar();
}

void Gerenciador::naoPegouEquipeRocket(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-50);
	jogadores[idxJogadores].variarHP(-50);
	jogadores[idxJogadores].getSomAtacado().tocar();

	if (jogadores[idxJogadores].getQntdPokemons() > 0)
	{
		int sorteado1 = rand() % 150;
		while (jogadores[idxJogadores].getPegouPokemons()[sorteado1] == false)
		{
			sorteado1 = (sorteado1 + 1) % 150;
		}
		jogadores[idxJogadores].setPegouPokemons(sorteado1, false);
		jogadores[idxJogadores].setPontos(jogadores[idxJogadores].getPontos() - 100 * (tabelaDeEvolucoes[sorteado1] + 1));
		for (int i = 0; i < 3; i++)
		{
			int sorteado2 = rand() % (jogadores[idxJogadores].getPokebolas()[i] + 1);
			jogadores[idxJogadores].setPokebolas(i, jogadores[idxJogadores].getPokebolas()[i] - sorteado2);
			jogadores[idxJogadores].setPontos(jogadores[idxJogadores].getPontos() - 10 * (i + 1) * sorteado2);
		}
		int sorteado3 = rand() % (jogadores[idxJogadores].getPokecoins() + 1);
		jogadores[idxJogadores].setPokecoins(jogadores[idxJogadores].getPokecoins() - sorteado3);
		jogadores[idxJogadores].setPontos(jogadores[idxJogadores].getPontos() - 10 * sorteado3);
	}
}

void Gerenciador::naoPegouGinasio(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouLetrao(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouOvo(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouPokebola(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10 * (poderPokebola + 1));
	jogadores[idxJogadores].variarHP(-10 * (poderPokebola + 1));
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouPokecoin(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouPokemon(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-100 * (tabelaDeEvolucoes[pokemonAtual] + 1));
	jogadores[idxJogadores].variarPontos(-10 * (tabelaDeEvolucoes[pokemonAtual] + 1));
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouPokestop(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}

void Gerenciador::naoPegouVida(Jogador* jogadores, int idxJogadores)
{
	jogadores[idxJogadores].variarPontos(-10);
	jogadores[idxJogadores].variarHP(-10);
	jogadores[idxJogadores].getSomAtacado().tocar();
}
