#pragma once
#include "libUnicornio.h"
#include "EquipeRocket.h"
#include "Ginasio.h"
#include "Jogador.h"
#include "Letrao.h"
#include "Ovo.h"
#include "Pokebola.h"
#include "Pokecoin.h"
#include "Pokemon.h"
#include "Pokestop.h"
#include "Vida.h"

class Gerenciador
{
public:
	Gerenciador();
	~Gerenciador();
	void inicializar(int yEquipeRocketInicial_, int yGinasioInicial_, int yLetraoInicial_, int yOvoInicial_, int yPokebolaInicial_, int yPokecoinInicial_, int yPokemonInicial_, int yPokestopInicial_, int yVidaInicial_);
	void gerenciar(Jogador* jogadores, int tempo);

private:
	EquipeRocket equipeRocket;
	Ginasio ginasio;
	Letrao letrao;

	Ovo ovo;
	int letraoAtual;

	Pokebola pokebola;
	Pokecoin pokecoin;

	Pokemon pokemon;
	int pokemonAtual;
	int poderAtual;
	/*
	http://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_evolution_family
	http://www.giantbomb.com/profile/wakka/lists/the-150-original-pokemon/59579/
	*/
	int tabelaDeEvolucoes[10 * 15] = { 0,1,2,0,1,2,0,1,2,0,1,2,0,1,2,1,2,0,1,0,1,0,1,1,2,0,1,0,1,2,1,2,1,2,0,1,1,2,0,1,0,1,2,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,2,0,2,0,1,2,0,1,2,0,1,0,1,2,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,2,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,1,0,1,1,1,0,0,1,0,0,0,1,1,1,0,0,1,0,1,0,1,0,0,0,1,2,0,0,0,0,0,1,1,1,0,0 };

	Pokestop pokestop;
	Vida vida;

	int xEquipeRocket[2], yEquipeRocket, yEquipeRocketInicial;
	int xGinasio, yGinasio, yGinasioInicial, forcaGinasioAtual;
	int xLetrao, yLetrao, yLetraoInicial;
	int xOvo, yOvo, yOvoInicial, codKmOvo;
	int xPokebola, yPokebola, yPokebolaInicial, poderPokebola;
	int xPokecoin, yPokecoin, yPokecoinInicial;
	int xPokemon, yPokemon, yPokemonInicial, quantidadeDePokemonsPorVez, quantidadeMostradaAtual;
	int xPokestop, yPokestop, yPokestopInicial;
	int xVida, yVida, yVidaInicial;

	int tempoMedioEntreEquipesRocket;
	int tempoMedioEntreGinasios;
	int tempoMedioEntreLetroes;
	int tempoMedioEntreOvos;
	int tempoMedioEntrePokebolas;
	int tempoMedioEntrePokecoins;
	int tempoMedioEntrePokemons;
	int tempoMedioEntrePokestops;
	int tempoMedioEntreVidas;

	void sortearEquipeRocket();
	int sortearGinasio();
	int sortearLetrao();
	int sortearOvo();
	int sortearPokebola();
	void sortearPokecoin();
	int sortearPokemon();
	int sortearPoder(int evolucao);
	void sortearPokestop();
	void sortearVida();

	int sortearX(int largura);
	int sortearForca();

	void atualizarEquipeRocket();
	void atualizarGinasio();
	void atualizarLetrao();
	void atualizarOvo();
	void atualizarPokebola();
	void atualizarPokecoin();
	void atualizarPokemon();
	void atualizarPokestop();
	void atualizarVida();

	void desenharEquipeRocket();
	void desenharGinasio();
	void desenharLetrao();
	void desenharOvo();
	void desenharPokebola();
	void desenharPokecoin();
	void desenharPokemon();
	void desenharPokestop();
	void desenharVida();

	void pegouEquipeRocket(Jogador* jogadores, int idxJogadores);
	void pegouGinasio(Jogador* jogadores, int idxJogadores);
	void pegouLetrao(Jogador* jogadores, int idxJogadores);
	void pegouOvo(Jogador* jogadores, int idxJogadores, int tempo);
	void pegouPokebola(Jogador* jogadores, int idxJogadores);
	void pegouPokecoin(Jogador* jogadores, int idxJogadores);
	void pegouPokemon(Jogador* jogadores, int idxJogadores);
	void pegouPokestop(Jogador* jogadores, int idxJogadores, int tempo);
	void pegouVida(Jogador* jogadores, int idxJogadores);

	void naoPegouEquipeRocket(Jogador* jogadores, int idxJogadores);
	void naoPegouGinasio(Jogador* jogadores, int idxJogadores);
	void naoPegouLetrao(Jogador* jogadores, int idxJogadores);
	void naoPegouOvo(Jogador* jogadores, int idxJogadores);
	void naoPegouPokebola(Jogador* jogadores, int idxJogadores);
	void naoPegouPokecoin(Jogador* jogadores, int idxJogadores);
	void naoPegouPokemon(Jogador* jogadores, int idxJogadores);
	void naoPegouPokestop(Jogador* jogadores, int idxJogadores);
	void naoPegouVida(Jogador* jogadores, int idxJogadores);
};
