#include "Ginasio.h"

Ginasio::Ginasio()
{
}

Ginasio::~Ginasio()
{
}

void Ginasio::desenhar()
{
	sprites[0].desenhar(x, y);
	sprites[1].desenhar(x, y - 150);
}

void Ginasio::atualizar()
{
	y += velocidade;
}

void Ginasio::inicializar(int x_, int y_, int forca)
{
	x = x_;
	y = y_;
	velocidade = 1;
	sprites[0].setVelocidadeAnimacao(0);
	sprites[0].setSpriteSheet("ginasio");
	sprites[0].setFrame(0);
	sprites[1].setVelocidadeAnimacao(0);
	sprites[1].setSpriteSheet("forcasGinasio");
	sprites[1].setFrame(forca);
}

int Ginasio::getX()
{
	return x;
}

int Ginasio::getY()
{
	return y;
}

void Ginasio::setY(int y_)
{
	y = y_;
}

Sprite* Ginasio::getSprites()
{
	return sprites;
}
