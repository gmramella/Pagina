#pragma once
#include "libUnicornio.h"

class Ginasio
{
public:
	Ginasio();
	~Ginasio();
	void desenhar();
	void atualizar();
	void inicializar(int x_, int y_, int forca);
	int getX();
	int getY();
	void setY(int y_);
	Sprite* getSprites();

private:
	Sprite sprites[2];
	int x, y, velocidade;
};
