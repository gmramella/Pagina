#include "Jogador.h"
#include <algorithm>

Jogador::Jogador()
{
}

Jogador::~Jogador()
{
}

void Jogador::inicializar(int x_, int y_, int velocidade_, int player_ = 0)
{
	x = x_;
	y = y_;
	velocidade = velocidade_;
	direcao = 90;
	player = player_;
	tipoDaPokebola = 0;
	pontos = 0;
	dx = 0;
	dy = 0;

	kmsOvos.erase(kmsOvos.begin(), kmsOvos.begin() + kmsOvos.size());
	codsKmsOvos.erase(codsKmsOvos.begin(), codsKmsOvos.begin() + codsKmsOvos.size());
	codsRachados.erase(codsRachados.begin(), codsRachados.begin() + codsRachados.size());
	for (int i = 0; i < 3; i++) idxPrimeiroOvoCadaKm[i] = -1;

	if (player == 0)
	{
		xInicial = (gJanela.getLargura() / 2) - 50;
		yInicial = (gJanela.getAltura() / 2) + 50;

		tecla_cima = TECLA_W;
		tecla_baixo = TECLA_S;
		tecla_esq = TECLA_A;
		tecla_dir = TECLA_D;

		tecla_fraca = TECLA_1;
		tecla_media = TECLA_2;
		tecla_forte = TECLA_3;

		tecla_pegar = TECLA_ESPACO;
		tecla_pausar = TECLA_ESC;
	}
	else if (player == 1)
	{
		xInicial = (gJanela.getLargura() / 2) + 50;
		yInicial = (gJanela.getAltura() / 2) + 50;

		tecla_cima = TECLA_CIMA;
		tecla_baixo = TECLA_BAIXO;
		tecla_esq = TECLA_ESQ;
		tecla_dir = TECLA_DIR;

		tecla_fraca = TECLA_KP_1;
		tecla_media = TECLA_KP_2;
		tecla_forte = TECLA_KP_3;

		tecla_pegar = TECLA_KP_0;
		tecla_pausar = TECLA_P;
	}

	//gRecursos.carregarAudio("passos", "");

	sprite.setVelocidadeAnimacao(8);
	gRecursos.carregarSpriteSheet("player" + to_string(player + 1), "assets/sprites/p" + to_string(player + 1) + ".png", 4, 3);
	sprite.setSpriteSheet("player" + to_string(player + 1));

	captura.setAudio("somGotcha");
	atacado.setAudio("somOuch");

	vulneravel = true;
	visivel = true;
	contInvulneravel = 0;
}

int Jogador::atualizar(int tempo, int* segundoAnterior)
{
	if (gTeclado.segurando[tecla_cima] && gTeclado.segurando[tecla_esq])
	{
		dx = -velocidade / sqrt(2);
		dy = -velocidade / sqrt(2);
		sprite.setAnimacao(CIMA);
		codMovimento = 0;
	}
	else if (gTeclado.segurando[tecla_cima] && gTeclado.segurando[tecla_dir])
	{
		dx = velocidade / sqrt(2);
		dy = -velocidade / sqrt(2);
		sprite.setAnimacao(CIMA);
		codMovimento = 1;
	}
	else if (gTeclado.segurando[tecla_baixo] && gTeclado.segurando[tecla_esq])
	{
		dx = -velocidade / 2;
		dy = velocidade / 2;
		sprite.setAnimacao(BAIXO);
		codMovimento = 2;
	}
	else if (gTeclado.segurando[tecla_baixo] && gTeclado.segurando[tecla_dir])
	{
		dx = velocidade / 2;
		dy = velocidade / 2;
		sprite.setAnimacao(BAIXO);
		codMovimento = 3;
	}
	else if (gTeclado.segurando[tecla_cima])
	{
		dx = 0;
		dy = -velocidade;
		sprite.setAnimacao(CIMA);
		codMovimento = 4;
	}
	else if (gTeclado.segurando[tecla_baixo])
	{
		dx = 0;
		dy = velocidade / 2;
		sprite.setAnimacao(BAIXO);
		codMovimento = 5;
	}
	else if (gTeclado.segurando[tecla_esq])
	{
		dx = -velocidade;
		dy = 0;
		sprite.setAnimacao(ESQ);
		codMovimento = 6;
	}
	else if (gTeclado.segurando[tecla_dir])
	{
		dx = velocidade;
		dy = 0;
		sprite.setAnimacao(DIR);
		codMovimento = 7;
	}
	else if (!gTeclado.segurando[tecla_cima] && !gTeclado.segurando[tecla_baixo] && !gTeclado.segurando[tecla_esq] && !gTeclado.segurando[tecla_dir])
	{
		dx = 0;
		dy = 0;
		sprite.setAnimacao(CIMA);
		codMovimento = -1;
	}

	if (codMovimento != -1)
	{
		if (sprite.getFrame() == 0)
		{
			sprite.setFrame(1);
		}
		//fxPasso.tocar();
		sprite.avancarAnimacao();
	}
	else
	{
		sprite.avancarAnimacao();
	}

	if (((x + dx) >= 20 && (x + dx) <= gJanela.getLargura() - 20) && ((y + dy) >= 50 && (y + dy) <= gJanela.getAltura() - 207))
	{
		x += dx;
		y += dy;
	}

	decKmsOvos(tempo, segundoAnterior);
	rachouOvo(tempo);
	for (int i = 0; i < codsRachados.size(); i++)
	{
		int poderSorteado = rand() % (codsRachados[i] + 1);
		int pokemonSorteado = rand() % 150;
		while (tabelaDeEvolucoes[pokemonSorteado] > poderSorteado)
		{
			pokemonSorteado = rand() % 150;
		}
		//Log::logOvos(3, pokemonSorteado, poderSorteado, codsRachados[i]);
		pegouPokemon(pokemonSorteado);
		variarPontos(100);
	}
	codsRachados.erase(codsRachados.begin(), codsRachados.begin() + codsRachados.size());

	if (pokecoins == 5)
	{
		if (vidas < 5)
		{
			vidas++;
		}
		pokecoins = 0;
	}

	if (hp <= 0)
	{
		vidas--;
		hp = 100;
		vulneravel = false;
	}
	if (vidas == 0)
	{
		morto = true;
		hp = 0;

		x = -60;
		y = -60;
	}

	return codMovimento;
}

void Jogador::desfazerAtualizar()
{
	if (codMovimento == 0)
	{
		x += +velocidade / sqrt(2);
		y += +velocidade / sqrt(2);
	}
	else if (codMovimento == 1)
	{
		x += -velocidade / sqrt(2);
		y += +velocidade / sqrt(2);
	}
	else if (codMovimento == 2)
	{
		x += +velocidade / 2;
		y += -velocidade / 2;
	}
	else if (codMovimento == 3)
	{
		x += -velocidade / 2;
		y += -velocidade / 2;
	}
	else if (codMovimento == 4)
	{
		x += 0;
		y += velocidade;
	}
	else if (codMovimento == 5)
	{
		x += 0;
		y += -velocidade / 2;
	}
	else if (codMovimento == 6)
	{
		x += velocidade;
		y += 0;
	}
	else if (codMovimento == 7)
	{
		x += -velocidade;
		y += 0;
	}
	else if (codMovimento == -1)
	{
		x += 0;
		y += 0;
	}
}

void Jogador::desenhar()
{
	if (vulneravel)
	{
		sprite.desenhar(x, y);
	}
	else
	{
		int segundos = 10, vezes = 18;
		contInvulneravel = (contInvulneravel + 1) % (int)floor((60 * 3) / 18);
		if (contInvulneravel == 0)
		{
			visivel = !visivel;
			if (visivel == false && --contVezesPiscar == 0)
			{
				contVezesPiscar = 10;
				vulneravel = true;
			}
		}
		if (visivel)
		{
			sprite.desenhar(x, y);
		}
	}
}

int Jogador::getX()
{
	return x;
}

int Jogador::getY()
{
	return y;
}

void Jogador::setX(int x_)
{
	x = x_;
}

void Jogador::setY(int y_)
{
	y = y_;
}

int Jogador::getVelocidade()
{
	return velocidade;
}

int Jogador::getTipoDaPokebola()
{
	return tipoDaPokebola;
}

void Jogador::setTipoDaPokebola(int tipoDaPokebola_)
{
	tipoDaPokebola = tipoDaPokebola_;
}

Sprite & Jogador::getSprite()
{
	return sprite;
}

void Jogador::variarPontos(int dp)
{
	if ((pontos + dp) >= 0)
	{
		pontos += dp;
	}
	else
	{
		pontos = 0;
	}
}

Som Jogador::getSomCaptura()
{
	return captura;
}

Som Jogador::getSomAtacado()
{
	return atacado;
}

int Jogador::getPontos()
{
	return pontos;
}

void Jogador::setPontos(int pontos_)
{
	pontos = pontos_;
}

int Jogador::getVidas()
{
	return vidas;
}

void Jogador::setVidas(int vidas_)
{
	vidas = vidas_;
}

int Jogador::getHp()
{
	return hp;
}

void Jogador::setHp(int hp_)
{
	hp = hp_;
}

int * Jogador::getPokebolas()
{
	return pokebolas;
}

void Jogador::setPokebolas(int pokebolas_[3])
{
	for (int i = 0; i < 3; i++)
	{
		pokebolas[i] = pokebolas_[i];
	}
}

void Jogador::setPokebolas(int idx, int valor)
{
	pokebolas[idx] = std::min(valor, 10);
}

void Jogador::incPokebolas(int poder)
{
	(pokebolas[poder])++;
}

void Jogador::decPokebolas(int poder)
{
	(pokebolas[poder])--;
}

void Jogador::incPokecoins()
{
	pokecoins++;
}

void Jogador::decPokecoins()
{
	pokecoins--;
}

int Jogador::getPokecoins()
{
	return pokecoins;
}

void Jogador::setPokecoins(int pokecoins_)
{
	pokecoins = pokecoins_;
}

void Jogador::pegouVida()
{
	if (hp == 100 && vidas < 5)
	{
		vidas++;
	}
	else
	{
		hp = 100;
	}
}

void Jogador::pegouOvo(int tempo, int codKm)
{
	kmsOvos.push_back(100 * (codKm * (codKm + 2) + 2));
	codsKmsOvos.push_back(codKm);
	if (idxPrimeiroOvoCadaKm[codKm] == -1)
	{
		idxPrimeiroOvoCadaKm[codKm] = codsKmsOvos.size() - 1;
	}
	//Log::logOvos(0, codKm, tempo, codsRachados, idxPrimeiroOvoCadaKm, kmsOvos, codsKmsOvos);
}

void Jogador::rachouOvo(int tempo)
{
	for (int i = 0; i < kmsOvos.size(); i++)
	{
		if (kmsOvos[i] == 0)
		{
			int temp = codsKmsOvos[i];
			//Log::logOvos(1, temp, tempo, codsRachados, idxPrimeiroOvoCadaKm, kmsOvos, codsKmsOvos);
			codsRachados.push_back(codsKmsOvos[i]);
			idxPrimeiroOvoCadaKm[codsKmsOvos[i]] = -1;
			kmsOvos.erase(kmsOvos.begin() + i);
			codsKmsOvos.erase(codsKmsOvos.begin() + i);
			//Log::logOvos(1, temp, tempo, codsRachados, idxPrimeiroOvoCadaKm, kmsOvos, codsKmsOvos);
		}
	}
	for (int i = 0; i < 3; i++)
	{
		if (idxPrimeiroOvoCadaKm[i] == -1)
		{
			for (int j = 0; j < codsKmsOvos.size(); j++)
			{
				if (codsKmsOvos[j] == i)
				{
					idxPrimeiroOvoCadaKm[i] = j;
					break;
				}
			}
		}
		else if (idxPrimeiroOvoCadaKm[i] >= kmsOvos.size())
		{
			idxPrimeiroOvoCadaKm[i] = -1;
			for (int j = 0; j < codsKmsOvos.size(); j++)
			{
				if (codsKmsOvos[j] == i)
				{
					idxPrimeiroOvoCadaKm[i] = j;
					break;
				}
			}
		}
	}
	//Log::logOvos(2, 0, 0, codsRachados, idxPrimeiroOvoCadaKm, kmsOvos, codsKmsOvos);
}

EnumTecla Jogador::getFraca()
{
	return tecla_fraca;
}

EnumTecla Jogador::getMedia()
{
	return tecla_media;
}

EnumTecla Jogador::getForte()
{
	return tecla_forte;
}

void Jogador::variarHP(int dh)
{
	hp += dh;
	if (hp < 0)
	{
		hp = 0;
	}
	else if (hp > 100)
	{
		hp = 100;
	}
}

bool Jogador::getMorto()
{
	return morto;
}

void Jogador::setMorto(bool isMorto_)
{
	morto = isMorto_;
}

bool Jogador::getPodePegar()
{
	return podePegar;
}

void Jogador::setPodePegar(bool podePegar_)
{
	podePegar = podePegar_;
}

EnumTecla Jogador::getTeclaPegar()
{
	return tecla_pegar;
}

EnumTecla Jogador::getTeclaPausar()
{
	return tecla_pausar;
}

EnumTecla Jogador::getTeclaEsquerda()
{
	return tecla_esq;
}

EnumTecla Jogador::getTeclaDireita()
{
	return tecla_dir;
}

EnumTecla Jogador::getTeclaFraca()
{
	return tecla_fraca;
}

EnumTecla Jogador::getTeclaMedia()
{
	return tecla_media;
}

EnumTecla Jogador::getTeclaForte()
{
	return tecla_forte;
}

int* Jogador::getQntdsGinasios()
{
	return qntdsGinasios;
}

int Jogador::getQntdLetras()
{
	return qntdLetras;
}

int* Jogador::getQntdsOvos()
{
	return qntdsOvos;
}

void Jogador::incQntdOvos(int km)
{
	(qntdsOvos[km])++;
}

int Jogador::getQntdPokemons()
{
	int cont = 0;
	for (int i = 0; i < 150; i++)
	{
		if (pegouPokemons[i])
		{
			cont++;
		}
	}
	return cont;
}

bool* Jogador::getPegouLetroes()
{
	return pegouLetroes;
}

void Jogador::setPegouLetroes(int idx, bool valor)
{
	pegouLetroes[idx] = valor;
}

bool * Jogador::getPegouPokemons()
{
	return pegouPokemons;
}

void Jogador::setPegouPokemons(int idx, bool valor)
{
	pegouPokemons[idx] = valor;
}

void Jogador::pegouPokemon(int idx)
{
	pegouPokemons[idx] = true;
}

vector<int> Jogador::getKmsOvos()
{
	return kmsOvos;
}

void Jogador::setKmsOvos(vector<int> kmsOvos_)
{
	kmsOvos = kmsOvos_;
}

void Jogador::decKmsOvos(int tempo, int *segundoAnterior)
{
	if ((tempo - *segundoAnterior) == 1)
	{
		(*segundoAnterior)++;
		for (int i = 0; i < kmsOvos.size(); i++)
		{
			kmsOvos[i] -= velocidade;
			if (kmsOvos[i] < 0)
			{
				kmsOvos[i] = 0;
			}
		}
	}
}

vector<int> Jogador::getCodsKmsOvos()
{
	return codsKmsOvos;
}

void Jogador::setPrimeiroMovimento(bool primeiroMovimento_)
{
	primeiroMovimento = primeiroMovimento_;
}

void Jogador::setQntdsGinasios(int idx, int valor)
{
	qntdsGinasios[idx] = valor;
}

void Jogador::incGinasios(int idx)
{
	(qntdsGinasios[idx])++;
}

void Jogador::setQntdsOvos(int idx, int valor)
{
	qntdsOvos[idx] = valor;
}

void Jogador::setQntdLetras(int qntdLetras_)
{
	qntdLetras = qntdLetras_;
}

void Jogador::incQntdLetras(int idx)
{
	if (pegouLetroes[idx] == false)
	{
		qntdLetras++;
	}
}

//void Jogador::setQntdPokemons(int qntdPokemons_)
//{
//	qntdPokemons = qntdPokemons_;
//}

void Jogador::incQntdPokemons()
{
	qntdPokemons++;
}

void Jogador::incQntdPokestops()
{
	qntdPokestops++;
}

int Jogador::getQntdPokestops()
{
	return qntdPokestops;
}

int Jogador::getMovimentoAnterior()
{
	return movimentoAnterior;
}

void Jogador::setMovimentoAnterior(int movimentoAnterior_)
{
	movimentoAnterior = movimentoAnterior_;
}

int Jogador::getCodMovimento()
{
	return codMovimento;
}

void Jogador::setCodMovimento(int codMovimento_)
{
	codMovimento = codMovimento_;
}

void Jogador::resetarJogador()
{
	x = xInicial;
	y = yInicial;
	morto = false;
	pontos = 0;
	vidas = 3;
	hp = 100;
	for (int i = 0; i < 3; i++) pokebolas[i] = 0;
	pokecoins = 0;
	qntdPokestops = 0;
	kmsOvos.erase(kmsOvos.begin(), kmsOvos.begin() + kmsOvos.size());
	codsKmsOvos.erase(codsKmsOvos.begin(), codsKmsOvos.begin() + codsKmsOvos.size());
	codsRachados.erase(codsRachados.begin(), codsRachados.begin() + codsRachados.size());
	for (int i = 0; i < 3; i++) idxPrimeiroOvoCadaKm[i] = -1;
	primeiroMovimento = true;
	podePegar = true;
	qntdLetras = 0;
	qntdPokemons = 0;

	for (int j = 0; j < 5; j++)
		qntdsGinasios[j] = 0;
	for (int j = 0; j < 3; j++)
		qntdsOvos[j] = 0;
	for (int j = 0; j < 7; j++)
		pegouLetroes[j] = false;
	for (int j = 0; j < 150; j++)
		pegouPokemons[j] = false;

	vulneravel = true;
	visivel = true;
	contInvulneravel = 0;
}

bool Jogador::getVulneravel()
{
	return vulneravel;
}
