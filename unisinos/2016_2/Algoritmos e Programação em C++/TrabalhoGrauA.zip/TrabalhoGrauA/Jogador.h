#pragma once
#include "libUnicornio.h"
#include "log.h"

enum Sentido { BAIXO, DIR, ESQ, CIMA };

class Jogador
{
public:
	Jogador();
	~Jogador();
	void inicializar(int x_, int y_, int velocidade_, int player_);
	int atualizar(int tempo, int* segundoAnterior);
	void desfazerAtualizar();
	void desenhar();
	int getX();
	int getY();
	void setX(int x_);
	void setY(int y_);
	int getVelocidade();
	int getTipoDaPokebola();
	void setTipoDaPokebola(int tipoDaPokebola_);
	Sprite & getSprite();
	void variarPontos(int dp);
	Som getSomCaptura();
	Som getSomAtacado();
	int getPontos();
	void setPontos(int pontos_);
	int getVidas();
	void setVidas(int vidas_);
	int getHp();
	void setHp(int hp_);
	int* getPokebolas();
	void setPokebolas(int pokebolas_[3]);
	void setPokebolas(int idx, int valor);
	void incPokebolas(int poder);
	void decPokebolas(int poder);
	void incPokecoins();
	void decPokecoins();
	int getPokecoins();
	void setPokecoins(int pokecoins_);
	void pegouVida();
	void pegouOvo(int tempo, int km);
	void rachouOvo(int tempo);
	EnumTecla getFraca();
	EnumTecla getMedia();
	EnumTecla getForte();
	void variarHP(int dh);
	bool getMorto();
	void setMorto(bool isMorto_);
	bool getPodePegar();
	void setPodePegar(bool podePegar_);
	EnumTecla getTeclaPegar(), getTeclaPausar(), getTeclaEsquerda(), getTeclaDireita(), getTeclaFraca(), getTeclaMedia(), getTeclaForte();
	int* getQntdsGinasios();
	int* getQntdsOvos();
	void incQntdOvos(int km);
	int getQntdLetras(), getQntdPokemons();
	bool* getPegouLetroes();
	void setPegouLetroes(int idx, bool valor);
	bool* getPegouPokemons();
	void setPegouPokemons(int idx, bool valor);
	void pegouPokemon(int idx);
	vector<int> getKmsOvos();
	void setKmsOvos(vector<int> kmsOvos_);
	void decKmsOvos(int tempo, int *segundoAnterior);
	vector<int> getCodsKmsOvos();
	int idxPrimeiroOvoCadaKm[3];
	void setPrimeiroMovimento(bool primeiroMovimento_);
	void setQntdsGinasios(int idx, int valor);
	void incGinasios(int idx);
	void setQntdLetras(int qntdLetras_);
	void incQntdLetras(int idx);
	void setQntdsOvos(int idx, int valor);
	//void setQntdPokemons(int qntdPokemons_);
	void incQntdPokemons();
	void incQntdPokestops();
	int getQntdPokestops();
	int getMovimentoAnterior();
	void setMovimentoAnterior(int movimentoAnterior_);
	int getCodMovimento();
	void setCodMovimento(int codMovimento_);
	int movimentoAnterior, codMovimento;
	void resetarJogador();
	vector<int> kmsOvos, codsKmsOvos, codsRachados;
	bool getVulneravel();

private:
	Sprite sprite;
	int x, y, xAnterior, yAnterior, velocidade, xInicial, yInicial;
	float direcao;
	float dx, dy;
	bool primeiroMovimento;
	int player, tipoDaPokebola;
	EnumTecla tecla_cima, tecla_baixo, tecla_esq, tecla_dir;
	EnumTecla tecla_fraca, tecla_media, tecla_forte;
	EnumTecla tecla_pegar, tecla_pausar;
	int pontos, vidas, hp, pokebolas[3], pokecoins;
	Som captura, atacado;
	bool morto;
	bool podePegar;
	int qntdsGinasios[5], qntdsOvos[3];
	int qntdLetras, qntdPokemons, qntdPokestops;
	bool pegouLetroes[7];
	bool pegouPokemons[150];
	/*
	http://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_evolution_family
	http://www.giantbomb.com/profile/wakka/lists/the-150-original-pokemon/59579/
	*/
	int tabelaDeEvolucoes[10 * 15] = { 0,1,2,0,1,2,0,1,2,0,1,2,0,1,2,1,2,0,1,0,1,0,1,1,2,0,1,0,1,2,1,2,1,2,0,1,1,2,0,1,0,1,2,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,2,0,2,0,1,2,0,1,2,0,1,0,1,2,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,2,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,1,0,1,1,1,0,0,1,0,0,0,1,1,1,0,0,1,0,1,0,1,0,0,0,1,2,0,0,0,0,0,1,1,1,0,0 };
	bool vulneravel, visivel;
	int contVezesPiscar = 10, contInvulneravel;
};
