#pragma once
#include "libUnicornio.h"
#include "EquipeRocket.h"
#include "Gerenciador.h"
#include "Jogador.h"
#include "Pokebola.h"
#include "Pokemon.h"
#include "Pokestop.h"
#include "Vida.h"
#include <cstdlib>
#include <ctime>
#include <fstream>

enum Tela {tInicial, tJogo, tPausa, tCreditos, tInstrucoes, tInstrucoes2, tInstrucoes3, tInstrucoes4, tInstrucoes5, tInstrucoes6, tInstrucoes7, tInstrucoes8, tConfirmar, tSair, tGinasios, tLetras, tOvos, tPokedex, tRanking, tGameover, tNome };

class Jogo
{
public:
	Jogo();
	~Jogo();
	void inicializar();
	void finalizar();
	void executar();

private:
		string musicaAtual = "";
		BotaoSprite botoes[16], setas[8];
		Tela status, statusAnterior;
		Sprite fundos[6], poderes[3], hud, spriteVida, pb, pokebolasHUD[3], logo, painel, pokedex, pokecoinGirando, relogio, barra;
		Texto textos[3];
		int contadorDeFrames;
		bool musicaPausadaPorJogador;
		vector<Sprite> spritesDasPokebolasMostradas;
		vector<float[2]> posDasPokebolasMostradas;
		vector<int> tiposDasPokebolasMostradas;
		Texto placar;
		string textoPlacar;
		time_t start;
		double segundos, segundosQuandoPausou;
		int segundoAnterior;
		bool iniciarTempo;
		string novoNomeProRanking;
		string nomes[10] = { "" }, pontuacoes[10] = { "" };
		int codNovoNome, qntdNomesNoRanking, menorPontuacao;
		int playerPokedex = 0;
		Sprite imagens[8];
		int janelaInstrucoes = 0;

		Jogador jogadores[2];
		Pokebola pokebolas[2];
		Pokemon pokemons[10*15];
		Gerenciador gerenciador;

		void telaInicial();
		void telaJogo();
		void telaPausa();
		void telaCreditos();
		void telaInstrucoes();
		void telaConfirmar(Tela anterior, Tela seguinte);
		void telaGinasios();
		void telaLetras();
		void telaOvos();
		void telaPokedex();
		void telaRanking();
		void telaGameover();
		void telaNome();
		void desenharHUD();
		bool vaiSairDaTela(float x, float y, float velocidade, int codMovimento);
		bool vaiColidirComOutroJogador(Sprite spr1, float x1, float y1, Sprite spr2, float x2, float y2, float velocidade, int codMovimento);
		void lerRanking();
		void atualizarRanking();
		void escreverTexto();
};
