#include "Letrao.h"

Letrao::Letrao()
{
}

Letrao::~Letrao()
{
}

void Letrao::desenhar()
{
	sprite.desenhar(x, y);
}

void Letrao::atualizar()
{
	y += velocidade;
}

void Letrao::inicializar(int x_, int y_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	sprite.setVelocidadeAnimacao(0);
	sprite.setSpriteSheet("letras");
}

int Letrao::getX()
{
	return x;
}

int Letrao::getY()
{
	return y;
}

void Letrao::setY(int y_)
{
	y = y_;
}

Sprite & Letrao::getSprite()
{
	return sprite;
}
