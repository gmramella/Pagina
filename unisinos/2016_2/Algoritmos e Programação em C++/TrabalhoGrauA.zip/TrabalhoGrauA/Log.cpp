#include "Log.h"

Log::Log()
{
}

Log::~Log()
{
}

void Log::logOvos(int op, int codKm, int tempo, vector<int> codsRachados, int idxPrimeiroOvoCadaKm[3], vector<int> kmsOvos, vector<int> codsKmsOvos)
{
	string cr = "[";
	for (int i = 0; i < codsRachados.size(); i++)
	{
		cr += to_string(codsRachados[i]) + ",";
	}
	cr += "]";
	string ipock = "[";
	for (int i = 0; i < 3; i++)
	{
		ipock += to_string(idxPrimeiroOvoCadaKm[i]) + ",";
	}
	ipock += "]";
	string ko = "[";
	for (int i = 0; i < kmsOvos.size(); i++)
	{
		ko += to_string(kmsOvos[i]) + ",";
	}
	ko += "]";
	string cko = "[";
	for (int i = 0; i < codsKmsOvos.size(); i++)
	{
		cko += to_string(codsKmsOvos[i] + 1) + ",";
	}
	cko += "]";

	if (op == 0)
	{
		ofstream arqOut;
		arqOut.open("log.txt", ios::out | ios::app);
		if (arqOut.is_open())
		{

			arqOut << "Pegou ovo tipo " + to_string(codKm + 1) + " aos " + to_string(tempo) + ", codsRachados: " + cr + ", idxPrimeiroOvoCadaKm: " + ipock + ", kmsOvos: " + ko + ", codsKmsOvos: " + cko + "\n";
			arqOut.close();
		}
	}
	else if (op == 1)
	{
		ofstream arqOut;
		arqOut.open("log.txt", ios::out | ios::app);
		if (arqOut.is_open())
		{
			arqOut << "Rachou ovo tipo " + to_string(codKm + 1) + " aos " + to_string(tempo) + ", codsRachados: " + cr + ", idxPrimeiroOvoCadaKm: " + ipock + ", kmsOvos: " + ko + ", codsKmsOvos: " + cko + "\n";
			arqOut.close();
		}
	}
	else if (op == 2)
	{
		ofstream arqOut;
		arqOut.open("log.txt", ios::out | ios::app);
		if (arqOut.is_open())
		{
			arqOut << "idx atualizado, codsRachados: " + cr + ", idxPrimeiroOvoCadaKm: " + ipock + ", kmsOvos: " + ko + ", codsKmsOvos: " + cko + "\n";
			arqOut.close();
		}
	}
}

void Log::logOvos(int op, int pokemonSorteado, int poderSorteado, int codRachado)
{
	if (op == 3)
	{
		ofstream arqOut;
		arqOut.open("log.txt", ios::out | ios::app);
		if (arqOut.is_open())
		{
			arqOut << "Ganhou o pokemon [" + to_string((int)floor((pokemonSorteado / 15))) + "," + to_string(pokemonSorteado % 15) + "] de poder " + to_string(poderSorteado) + " de um ovo de poder " + to_string(codRachado) + "\n";
			arqOut.close();
		}
	}
}
