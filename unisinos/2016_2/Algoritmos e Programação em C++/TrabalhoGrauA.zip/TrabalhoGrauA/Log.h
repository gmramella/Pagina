#pragma once
#include "libUnicornio.h"
#include <vector>

class Log
{
public:
	Log();
	~Log();
	static void logOvos(int op, int codKm, int tempo, vector<int> codsRachados, int idxPrimeiroOvoCadaKm[3], vector<int> kmsOvos, vector<int> codsKmsOvos);
	static void logOvos(int op, int pokemonSorteado, int poderSorteado, int codRachado);
};
