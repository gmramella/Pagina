#include "Ovo.h"

Ovo::Ovo()
{
}

Ovo::~Ovo()
{
}

void Ovo::desenhar()
{
	sprite.desenhar(x, y);
	textoKm.desenhar(x, y  - 50);
}

void Ovo::atualizar()
{
	y += velocidade;
}

void Ovo::inicializar(int x_, int y_, int codKmNovoOvo_)
{
	x = x_;
	y = y_;
	codKmNovoOvo = codKmNovoOvo_;
	velocidade = 1;
	sprite.setSpriteSheet("ovos");
	sprite.setFrame(codKmNovoOvo);
	textoKm.setFonte("fonte2");
	textoKm.setCor((int)(codKmNovoOvo_ == 0) * 255, (int)(codKmNovoOvo_ == 1) * 255, (int)(codKmNovoOvo_ == 2) * 255);
	int km = codKmNovoOvo_ + pow(2, codKmNovoOvo_ + 1);
	textoKm.setString(to_string(km) + " km");
}

int Ovo::getX()
{
	return x;
}

int Ovo::getY()
{
	return y;
}

void Ovo::setY(int y_)
{
	y = y_;
}

Sprite & Ovo::getSprite()
{
	return sprite;
}

int Ovo::getCodKmNovoOvo()
{
	return codKmNovoOvo;
}

void Ovo::setCodKmNovoOvo(int codKmNovoOvo_)
{
	codKmNovoOvo = codKmNovoOvo_;
}
