#pragma once
#include "libUnicornio.h"

class Ovo
{
public:
	Ovo();
	~Ovo();
	void desenhar();
	void atualizar();
	void inicializar(int x_, int y_, int codKmNovoOvo_);
	int getX();
	int getY();
	void setY(int y_);
	Sprite & getSprite();
	int getCodKmNovoOvo();
	void setCodKmNovoOvo(int codKmNovoOvo_); 

private:
	Sprite sprite;
	Texto textoKm;
	int x, y, velocidade, codKmNovoOvo;
};
