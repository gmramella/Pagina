#include "Pokebola.h"

Pokebola::Pokebola()
{
}

Pokebola::~Pokebola()
{
}

void Pokebola::desenhar()
{
	sprite.desenhar(x, y);
}

void Pokebola::atualizar()
{
	y += velocidade;
}

void Pokebola::atualizar(int x_, int y_)
{
	x = x_;
	y = y_;
}

void Pokebola::inicializar(int x_, int y_)
{
	x = x_;
	y = y_;
	poder = 0;
}

void Pokebola::inicializar(int x_, int y_, int poder_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	poder = poder_;
}

Sprite & Pokebola::getSprite()
{
	return sprite;
}

void Pokebola::setPoder(int poder_)
{
	poder = poder_;
}

int Pokebola::getX()
{
	return x;
}

int Pokebola::getY()
{
	return y;
}

void Pokebola::setY(int y_)
{
	y = y_;
}
