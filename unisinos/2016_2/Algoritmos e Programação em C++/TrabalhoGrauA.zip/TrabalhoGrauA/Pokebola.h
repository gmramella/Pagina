#pragma once
#include "libUnicornio.h"

class Pokebola
{
public:
	Pokebola();
	~Pokebola();
	void desenhar();
	void atualizar();
	void atualizar(int x_, int y_);
	void inicializar(int x_, int y);
	void inicializar(int x_, int y, int poder);
	int getX();
	int getY();
	void setY(int y_);
	Sprite & getSprite();
	void setPoder(int poder_);

private:
	Sprite sprite;
	int x, y, velocidade;
	int poder;
};
