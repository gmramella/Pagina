#include "Pokecoin.h"

Pokecoin::Pokecoin()
{
}

Pokecoin::~Pokecoin()
{
}

void Pokecoin::desenhar()
{
	sprite.desenhar(x, y);
}

void Pokecoin::atualizar()
{
	y += velocidade;
}

void Pokecoin::inicializar(int x_, int y_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	sprite.setVelocidadeAnimacao(0);
	sprite.setSpriteSheet("pokecoin");
	sprite.setFrame(0);
}

int Pokecoin::getX()
{
	return x;
}

int Pokecoin::getY()
{
	return y;
}

void Pokecoin::setY(int y_)
{
	y = y_;
}

Sprite & Pokecoin::getSprite()
{
	return sprite;
}
