#include "Pokemon.h"

Pokemon::Pokemon()
{
}

Pokemon::~Pokemon()
{
}

void Pokemon::desenhar()
{
	spritePokemon.desenhar(x, y);
	spritePoder.desenhar(x, y - 50);
}

void Pokemon::atualizar()
{
	y += velocidade;
}

void Pokemon::inicializar(int x_, int y_, int qual, int poder_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	poder = poder_;

	if (!gRecursos.carregouSpriteSheet("pokemon" + to_string(qual + 1)))
	{
		gRecursos.carregarSpriteSheet("pokemon" + to_string(qual + 1), "assets/sprites/pokemons.png", 10, 15);
		spritePokemon.setSpriteSheet("pokemon" + to_string(qual + 1));
		spritePokemon.setVelocidadeAnimacao(0);
		spritePokemon.setAnimacao(qual / 15);
		spritePokemon.setFrame(qual % 15);
	}
	if (!gRecursos.carregouSpriteSheet("poder" + to_string(poder + 1)))
	{
		gRecursos.carregarSpriteSheet("poder" + to_string(poder + 1), "assets/sprites/poder" + to_string(poder + 1) + ".png");
	}
	spritePoder.setSpriteSheet("poder" + to_string(poder + 1));
}

int Pokemon::getX()
{
	return x;
}

int Pokemon::getY()
{
	return y;
}

void Pokemon::setY(int y_)
{
	y = y_;
}

Sprite & Pokemon::getSprite()
{
	return spritePokemon;
}

void Pokemon::setSprite(Sprite sprite_)
{
	spritePokemon = sprite_;
}

int Pokemon::getPoder()
{
	return poder;
}
