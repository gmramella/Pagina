#pragma once
#include "libUnicornio.h"

class Pokemon
{
public:
	Pokemon();
	~Pokemon();
	void desenhar();
	void atualizar();
	void inicializar(int x_, int y_, int qual, int poder_);
	int getX();
	int getY();
	void setY(int y_);
	Sprite & getSprite();
	void setSprite(Sprite sprite_);
	int getPoder();

private:
	Sprite spritePokemon, spritePoder;
	int x, y, velocidade;
	int poder;
};
