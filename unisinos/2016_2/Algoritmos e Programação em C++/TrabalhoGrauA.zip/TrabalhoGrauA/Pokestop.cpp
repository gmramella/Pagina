#include "Pokestop.h"

Pokestop::Pokestop()
{
}

Pokestop::~Pokestop()
{
}

void Pokestop::desenhar()
{
	sprite.desenhar(x, y);
}

void Pokestop::atualizar()
{
	sprite.avancarAnimacao();
	y += velocidade;
}

void Pokestop::inicializar(int x_, int y_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	sprite.setVelocidadeAnimacao(6);
	sprite.setSpriteSheet("pokestop");
	sprite.setFrame(0);
}

int Pokestop::getX()
{
	return x;
}

int Pokestop::getY()
{
	return y;
}

void Pokestop::setY(int y_)
{
	y = y_;
}

Sprite & Pokestop::getSprite()
{
	return sprite;
}
