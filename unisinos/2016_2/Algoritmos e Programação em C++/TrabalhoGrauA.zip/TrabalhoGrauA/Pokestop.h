#pragma once
#include "libUnicornio.h"

class Pokestop
{
public:
	Pokestop();
	~Pokestop();
	void desenhar();
	void atualizar();
	void inicializar(int x_, int y_);
	int getX();
	int getY();
	void setY(int y_);
	Sprite & getSprite();

private:
	Sprite sprite;
	int x, y, velocidade;
};
