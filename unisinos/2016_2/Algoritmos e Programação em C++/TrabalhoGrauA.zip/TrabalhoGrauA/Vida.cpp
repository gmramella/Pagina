#include "Vida.h"

Vida::Vida()
{
}

Vida::~Vida()
{
}

void Vida::desenhar()
{
	sprite.desenhar(x, y);
}

void Vida::atualizar()
{
	y += velocidade;
	sprite.avancarAnimacao();
}

void Vida::inicializar(int x_, int y_)
{
	x = x_;
	y = y_;
	velocidade = 1;
	sprite.setVelocidadeAnimacao(10);
	sprite.setSpriteSheet("vida");
	sprite.setFrame(0);
}

int Vida::getX()
{
	return x;
}

int Vida::getY()
{
	return y;
}

void Vida::setY(int y_)
{
	y = y_;
}

Sprite & Vida::getSprite()
{
	return sprite;
}
