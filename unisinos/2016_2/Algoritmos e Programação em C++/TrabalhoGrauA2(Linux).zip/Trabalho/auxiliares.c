#include "defines.h"

#include <stdio.h>

int encontradosNxMLugaresAPartirDeUmAssento(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int fileira, int coluna, int quantasFileiras, int quantasColunas) { // Função auxiliar para verificar se os n x m assentos a partir de um específico estão livres
	int i, j;
	int cont = 0;
	for (i=fileira; i<fileira+quantasFileiras; i++) {
		for (j=coluna; j<coluna+quantasColunas; j++) {
			if (mapaDoTeatro[i][j] == (char)255) {
				cont++;
			}
		}
	}
	return (cont == (quantasFileiras * quantasColunas));
}

char forcarTecla1Em2(char teclas[2], char* pergunta, char* erro) { // Função para forçar o usuário a digitar uma tecla determinada
	char resposta;
	limparTela();
	printf("%s (%c/%c)? ", pergunta, teclas[0], teclas[1]);
	scanf("%c", &resposta);
	limparBuffer();
	while (tolower(resposta) != teclas[0] && tolower(resposta) != teclas[1]) {
		limparTela();
		printf("%s\r\n", erro);
		printf("%s (%c/%c)? ", pergunta, teclas[0], teclas[1]);
		scanf("%c", &resposta);
		limparBuffer();
	}
	return tolower(resposta);
}

int verificarSeEstaNointervaloDouble(double extremos[2], double resposta, int intervalo) { // Função para verificar se um valor está dentro ou fora de um intervalo dependendo da condição imposta pelo terceiro parâmetro (int intervalo)
	switch (intervalo) {
		case  0: return (resposta < extremos[0]);
		case  1: return (resposta <= extremos[0]);
		case  2: return (resposta == extremos[0]);
		case  3: return (resposta >= extremos[0]);
		case  4: return (resposta > extremos[0]);
		case  5: return (resposta < extremos[1]);
		case  6: return (resposta <= extremos[1]);
		case  7: return (resposta == extremos[1]);
		case  8: return (resposta >= extremos[1]);
		case  9: return (resposta > extremos[1]);

		case 10: return ((resposta < extremos[0]) && (resposta < extremos[1]));
		case 11: return ((resposta < extremos[0]) && (resposta <= extremos[1]));
		case 12: return ((resposta < extremos[0]) && (resposta == extremos[1]));
		case 13: return ((resposta < extremos[0]) && (resposta >= extremos[1]));
		case 14: return ((resposta < extremos[0]) && (resposta > extremos[1]));
		case 15: return ((resposta <= extremos[0]) && (resposta < extremos[1]));
		case 16: return ((resposta <= extremos[0]) && (resposta <= extremos[1]));
		case 17: return ((resposta <= extremos[0]) && (resposta == extremos[1]));
		case 18: return ((resposta <= extremos[0]) && (resposta >= extremos[1]));
		case 19: return ((resposta <= extremos[0]) && (resposta > extremos[1]));
		case 20: return ((resposta == extremos[0]) && (resposta < extremos[1]));
		case 21: return ((resposta == extremos[0]) && (resposta <= extremos[1]));
		case 22: return ((resposta == extremos[0]) && (resposta == extremos[1]));
		case 23: return ((resposta == extremos[0]) && (resposta >= extremos[1]));
		case 24: return ((resposta == extremos[0]) && (resposta > extremos[1]));
		case 25: return ((resposta >= extremos[0]) && (resposta < extremos[1]));
		case 26: return ((resposta >= extremos[0]) && (resposta <= extremos[1]));
		case 27: return ((resposta >= extremos[0]) && (resposta == extremos[1]));
		case 28: return ((resposta >= extremos[0]) && (resposta >= extremos[1]));
		case 29: return ((resposta >= extremos[0]) && (resposta > extremos[1]));
		case 30: return ((resposta > extremos[0]) && (resposta < extremos[1]));
		case 31: return ((resposta > extremos[0]) && (resposta <= extremos[1]));
		case 32: return ((resposta > extremos[0]) && (resposta == extremos[1]));
		case 33: return ((resposta > extremos[0]) && (resposta >= extremos[1]));
		case 34: return ((resposta > extremos[0]) && (resposta > extremos[1]));

		case 35: return ((resposta < extremos[0]) || (resposta < extremos[1]));
		case 36: return ((resposta < extremos[0]) || (resposta <= extremos[1]));
		case 37: return ((resposta < extremos[0]) || (resposta == extremos[1]));
		case 38: return ((resposta < extremos[0]) || (resposta >= extremos[1]));
		case 39: return ((resposta < extremos[0]) || (resposta > extremos[1]));
		case 40: return ((resposta <= extremos[0]) || (resposta < extremos[1]));
		case 41: return ((resposta <= extremos[0]) || (resposta <= extremos[1]));
		case 42: return ((resposta <= extremos[0]) || (resposta == extremos[1]));
		case 43: return ((resposta <= extremos[0]) || (resposta >= extremos[1]));
		case 44: return ((resposta <= extremos[0]) || (resposta > extremos[1]));
		case 45: return ((resposta == extremos[0]) || (resposta < extremos[1]));
		case 46: return ((resposta == extremos[0]) || (resposta <= extremos[1]));
		case 47: return ((resposta == extremos[0]) || (resposta == extremos[1]));
		case 48: return ((resposta == extremos[0]) || (resposta >= extremos[1]));
		case 49: return ((resposta == extremos[0]) || (resposta > extremos[1]));
		case 50: return ((resposta >= extremos[0]) || (resposta < extremos[1]));
		case 51: return ((resposta >= extremos[0]) || (resposta <= extremos[1]));
		case 52: return ((resposta >= extremos[0]) || (resposta == extremos[1]));
		case 53: return ((resposta >= extremos[0]) || (resposta >= extremos[1]));
		case 54: return ((resposta >= extremos[0]) || (resposta > extremos[1]));
		case 55: return ((resposta > extremos[0]) || (resposta < extremos[1]));
		case 56: return ((resposta > extremos[0]) || (resposta <= extremos[1]));
		case 57: return ((resposta > extremos[0]) || (resposta == extremos[1]));
		case 58: return ((resposta > extremos[0]) || (resposta >= extremos[1]));
		case 59: return ((resposta > extremos[0]) || (resposta > extremos[1]));
	}
}

int verificarSeEstaNointervaloInt(int extremos[2], int resposta, int intervalo) { // Função para verificar se um valor está dentro ou fora de um intervalo dependendo da condição imposta pelo terceiro parâmetro (int intervalo)
	return verificarSeEstaNointervaloDouble((double*)extremos, (double)resposta, intervalo);
}

int forcarNumeroEmIntervaloDouble(double extremos[2], char* mensagem, char* erro, int intervalo) { // Função para forçar o usuário a digitar um valor determinado
	double resposta;
	limparTela();
	printf("%s (%lf-%lf): ", mensagem, extremos[0], extremos[1]);
	scanf("%lf", &resposta);
	limparBuffer();
	while (!verificarSeEstaNointervaloDouble(extremos, resposta, intervalo)) {
		limparTela();
		printf("%s\r\n", erro);
		printf("%s (%lf-%lf): ", mensagem, extremos[0], extremos[1]);
		scanf("%lf", &resposta);
		limparBuffer();
	}
	return resposta;
}

int forcarNumeroEmIntervaloInt(int extremos[2], char* mensagem, char* erro, int intervalo) { // Função para forçar o usuário a digitar um valor determinado
	int resposta;
	limparTela();
	printf("%s (%d-%d): ", mensagem, extremos[0], extremos[1]);
	scanf("%d", &resposta);
	limparBuffer();
	while (!verificarSeEstaNointervaloInt(extremos, resposta, intervalo)) {
		limparTela();
		printf("%s\r\n", erro);
		printf("%s (%d-%d): ", mensagem, extremos[0], extremos[1]);
		scanf("%d", &resposta);
		limparBuffer();
	}
	return resposta;
}

double inicializarPorcentagem(double parte, double total) { // Função que inicializa uma porcentagem com 0 ou com seu valor, porque esta variável depende do valor da variável passada como segundo parâmetro da função (double total) e se ela for 0, dará erro porque não existe divisão por 0
	return (total != 0) ? (100 * parte / total) : 0;
}

void inicializarVetor(int tamanho, int vetor[tamanho], int valor) { // Função que inicializa um vetor com todos os seus elementos contendo um mesmo valor
	int i;
	for(i=0; i<tamanho; i++) {
		vetor[i] = valor;
	}
}

int somatorioDeVetor(int tamanho, int vetor[tamanho]) { // Função que retorna a soma de todos os elementos de um vetor
	int soma = 0, i;
	for(i=0; i<tamanho; i++) {
		soma += vetor[i];
	}
	return soma;
}
