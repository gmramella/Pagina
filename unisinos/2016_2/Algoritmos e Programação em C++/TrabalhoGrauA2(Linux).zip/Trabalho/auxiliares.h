int encontradosNxMLugaresAPartirDeUmAssento(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int fileira, int coluna, int quantasFileiras, int quantasColunas);

char forcarTecla1Em2(char teclas[2], char* pergunta, char* erro);

int verificarSeEstaNointervaloDouble(double extremos[2], double resposta, int intervalo);

int verificarSeEstaNointervaloInt(int extremos[2], int resposta, int intervalo);

int forcarNumeroEmIntervaloDouble(double extremos[2], char* mensagem, char* erro, int intervalo);

int forcarNumeroEmIntervaloInt(int extremos[2], char* mensagem, char* erro, int intervalo);

double inicializarPorcentagem(double parte, double total);

void inicializarVetor(int tamanho, int vetor[tamanho], int valor);

int somatorioDeVetor(int tamanho, int vetor[tamanho]);
