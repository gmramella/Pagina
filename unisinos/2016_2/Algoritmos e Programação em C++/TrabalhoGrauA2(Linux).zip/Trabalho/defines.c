#include <stdio.h>

#ifdef _WIN32 // O computador que compilar o programa é windows
	#include <conio.h>
	void pausa() { // Função para pausar o prompt do windows que está rodando o programa
		getch();
	}
	void limparTela() { // Função para limpar o prompt do windows que está rodando o programa
		system("cls");
	}
#elif defined __unix__ // O computador que compilar o programa é linux
	void pausa() { // Função para pausar o terminal do linux que está rodando o programa
		system("read x");
	}
	void limparTela() { // Função para limpar o terminal do linux que está rodando o programa
		system("clear");
	}
#elif defined __APPLE__ // O computador que compilar o programa é mac
	void pausa() { // Função para pausar o terminal do mac que está rodando o programa
		//system("read x"); // Não sei qual o comando para pausar o terminal em um mac
	}
	void limparTela() { // Função para limpar o terminal do mac que está rodando o programa
		//system("clear"); // Não sei qual o comando para limpar o terminal em um mac
	}
#endif

void limparBuffer() { // Função para limpar o buffer depois que ler um valor que o usuário digitar
	getc(stdin);
}
