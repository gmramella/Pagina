#ifndef MASCARA_LIVRE
	#define MASCARA_LIVRE 255
#endif

#ifndef MASCARA_SEXO
	#define MASCARA_SEXO 128
#endif

#ifndef MASCARA_IDADE
	#define MASCARA_IDADE 127
#endif

#ifndef HOMEM
	#define HOMEM (char)0
#endif

#ifndef MULHER
	#define MULHER (char)0
#endif

// Arquivo com as definições de constantes usadas para:
// 	manipular a matriz de caracteres que contém os dados dos assentos do teatro
// 		A máscara 255 = 11111111 é usada para indicar que um assento está livre
// 		A máscara 128 = 10000000 é usada para pegar o sexo da pessoa usando a operação binária AND
// 		A máscara 127 = 01111111 é usada para pegar a idade da pessoa usando a operação binária AND
// 		Por causa da limitação do tamanho de um char, só é possível armazenar valores entre 0 e 255, como sexo feminino é 1, não é permitido pessoas com 127 anos
// 		porque uma mulher de 127 anos seria representada por 255 = 11111111, por isso o programa só permite idades entre 0 e 126
//	identificar o sexo da pessoa que está em um assento
//		0 é homem
//		1 é mulher

void limparBuffer();
