#include "auxiliares.h"
#include "defines.h"

#include <stdio.h>
#include <math.h>

void imprimirMenu() { // Tela do menu principal
	printf("0. Ajuda\r\n");
	printf("1. Consultar situação de um assento\r\n");
	printf("2. Consultar disponibilidade de n assentos\r\n");
	printf("3. Consultar disponibilidade de n x m assentos\r\n");
	printf("4. Fazer reserva de n assentos\r\n");
	printf("5. Fazer reserva de n x m assentos\r\n");
	printf("6. Liberar reserva de n assentos\r\n");
	printf("7. Liberar reserva de n x m assentos\r\n");
	printf("8. Mostrar mapa do teatro e informações atualizadas\r\n");
	printf("9. Encerrar programa\r\n");
}

void desenharGrafico(double porcentagem, int qntdSimbolos) { // Função para desenhar gráfico de porcentagem
	printf("|");
	int cont = 0, i;
	while (porcentagem > 0) {
		if ((porcentagem - 100/qntdSimbolos) >= 0) {
			printf("=");
		}
		else {
			printf("-");
		}
		porcentagem -= 100/qntdSimbolos;
		cont++;
	}
	for (i=cont; i<qntdSimbolos; i++) {
		printf(".");
	}
	printf("|");
}

void imprimirTela1(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]) { // Tela 1 das informações do teatro
	limparTela();
	int i, j;
	printf("Mapa de ocupação do teatro: (\"X\" = reservado e \".\" = liberado)\r\n");
	for (i = 0; i < qntdDeFileiras; i++) {
		printf("\t%02d", i+1);
	}
	printf("\r\n");
	int qntdReservados = 0, qntdLiberados = 0;
	for (i = 0; i < qntdDeColunas; i++) {
		printf("%02d", i+1);
		for (j = 0; j < qntdDeFileiras; j++) {
			if (mapaDoTeatro[i][j] == (char)255) {
				printf("\t %c", '.');
				qntdLiberados++;
			}
			else {
				printf("\t %c", 'X');
				qntdReservados++;
			}
		}
		printf("\r\n");
	}
	printf("\r\n");
	
	double porcentagemReservados = inicializarPorcentagem((double)qntdReservados, (qntdDeFileiras * qntdDeColunas));
	double porcentagemLiberados = inicializarPorcentagem((double)qntdLiberados, (qntdDeFileiras * qntdDeColunas));
	int qntdSimbolos = 10;
	printf("Quantidade total de assentos do teatro, divididos entre liberados e reservados:\r\n");
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	printf("Reservados\t\t\t: %03d\t- %.1lf%%\t", qntdReservados, porcentagemReservados);
	if(porcentagemReservados < 100) {printf("\t");}
	desenharGrafico(porcentagemReservados, qntdSimbolos);
	printf("\r\n");
	printf("Liberados\t\t\t: %03d\t- %.1lf%%\t", qntdLiberados, porcentagemLiberados);
	if(porcentagemLiberados < 100) {printf("\t");}
	desenharGrafico(porcentagemLiberados, qntdSimbolos);
	printf("\r\n");
	printf("Total\t\t\t\t: %03d\t- %.1lf%%\t|", qntdDeFileiras * qntdDeColunas, 100.0);
	for (i = 0; i < 100/qntdSimbolos; i++) {
		printf("=");
	}
	printf("|\r\n");
}

void imprimirTela2(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDePagantesHomens, int qntdDePagantesMulheres) { // Tela 2 das informações do teatro
	limparTela();
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	int i, j;
	double porcentagemDePagantesHomens = inicializarPorcentagem(qntdDePagantesHomens, (qntdDePagantesHomens + qntdDePagantesMulheres));
	double porcentagemDePagantesMulheres = inicializarPorcentagem(qntdDePagantesMulheres, (qntdDePagantesHomens + qntdDePagantesMulheres));
	int qntdDePagantesHomensAtual = 0, qntdDePagantesMulheresAtual = 0;
	for(i=0;i<qntdDeFileiras;i++) {
		for(j=0;j<qntdDeColunas;j++) {
			if (mapaDoTeatro[i][j] != (char)255) {
				(mapaDoTeatro[i][j] & MASCARA_SEXO) ? (qntdDePagantesMulheresAtual++) : (qntdDePagantesHomensAtual++);
			}
		}
	}
	double porcentagemDePagantesHomensAtual = inicializarPorcentagem(qntdDePagantesHomensAtual, (qntdDePagantesHomensAtual + qntdDePagantesMulheresAtual));
	double porcentagemDePagantesMulheresAtual = inicializarPorcentagem(qntdDePagantesMulheresAtual, (qntdDePagantesHomensAtual + qntdDePagantesMulheresAtual));
	printf("Publico masculino atual\t\t: ");
	printf("%03d\t- ", qntdDePagantesHomensAtual);
	if (porcentagemDePagantesHomensAtual == 100.0) {
		printf("%.1lf%%\t", porcentagemDePagantesHomensAtual);
	}
	else {
		printf("%.1lf%%\t\t", porcentagemDePagantesHomensAtual);
	}
	int qntdSimbolos = 10;
	desenharGrafico(porcentagemDePagantesHomensAtual, qntdSimbolos);
	printf("\r\n");
	printf("Publico feminino atual\t\t: ");
	printf("%03d\t- ", qntdDePagantesMulheresAtual);
	if (porcentagemDePagantesMulheresAtual == 100.0) {
		printf("%.1lf%%\t", porcentagemDePagantesMulheresAtual);
	}
	else {
		printf("%.1lf%%\t\t", porcentagemDePagantesMulheresAtual);
	}
	desenharGrafico(porcentagemDePagantesMulheresAtual, qntdSimbolos);
	printf("\r\n");
	printf("Publico masculino total\t\t: ");
	printf("%03d\t- ", qntdDePagantesHomens);
	if (porcentagemDePagantesHomens == 100.0) {
		printf("%.1lf%%\t", porcentagemDePagantesHomens);
	}
	else {
		printf("%.1lf%%\t\t", porcentagemDePagantesHomens);
	}
	desenharGrafico(porcentagemDePagantesHomens, qntdSimbolos);
	printf("\r\n");
	printf("Publico feminino total\t\t: ");
	printf("%03d\t- ", qntdDePagantesMulheres);
	if (porcentagemDePagantesMulheres == 100.0) {
		printf("%.1lf%%\t", porcentagemDePagantesMulheres);
	}
	else {
		printf("%.1lf%%\t\t", porcentagemDePagantesMulheres);
	}
	desenharGrafico(porcentagemDePagantesMulheres, qntdSimbolos);
	printf("\r\n");
}

void imprimirTela3(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDeFaixasDeIdade) { // Tela 3 das informações do teatro
	limparTela();
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	int i, j, cont = 0, qntdSimbolos = 10;
	int qntdDePagantesPorFaixaDeIdadeAtual[qntdDeFaixasDeIdade];
	for(i=0;i<qntdDeFaixasDeIdade;i++) {
		qntdDePagantesPorFaixaDeIdadeAtual[i] = 0;
	}
	for(i=0;i<qntdDeFileiras;i++) {
		for(j=0;j<qntdDeColunas;j++) {
			if (mapaDoTeatro[i][j] != (char)255) {
				qntdDePagantesPorFaixaDeIdadeAtual[(int)(mapaDoTeatro[i][j] & MASCARA_IDADE) / (int)ceil(126 / qntdDeFaixasDeIdade)]++;
			}
		}
	}
	int totalDePagantesPorFaixaDeIdadeAtual = somatorioDeVetor(qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdadeAtual);
	double porcentagemDePagantesPorFaixaDeIdadeAtual[qntdDeFaixasDeIdade];
	for (i=0; i<qntdDeFaixasDeIdade; i++) {
		porcentagemDePagantesPorFaixaDeIdadeAtual[i] = inicializarPorcentagem(qntdDePagantesPorFaixaDeIdadeAtual[i], totalDePagantesPorFaixaDeIdadeAtual);
	}
	for (i=0; i<qntdDeFaixasDeIdade;i++) {
		printf("%03d-%03d atual\t\t\t: ", (int)ceil(126 / qntdDeFaixasDeIdade)*i, (int)ceil(126 / qntdDeFaixasDeIdade)*i+9);
		printf("%03d\t- ", qntdDePagantesPorFaixaDeIdadeAtual[i]);
		if (porcentagemDePagantesPorFaixaDeIdadeAtual[i] != 100.0) {
			printf("%03.1lf%%\t\t", porcentagemDePagantesPorFaixaDeIdadeAtual[i]);
		}
		else {
			printf("%03.1lf%%\t", porcentagemDePagantesPorFaixaDeIdadeAtual[i]);
		}
		desenharGrafico(porcentagemDePagantesPorFaixaDeIdadeAtual[i], qntdSimbolos);
	printf("\r\n");
	}
	printf("        todos\t\t\t: ");
	printf("%03d\t- ", totalDePagantesPorFaixaDeIdadeAtual);
	printf("%03.1lf%%\t|", 100.0);
	for(j=0;j<100/qntdSimbolos;j++) {
		printf("=");
	}
	printf("|\r\n");
}

void imprimirTela4(int qntdDeFaixasDeIdade, int qntdDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade]) { // Tela 4 das informações do teatro
	limparTela();
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	int i, j, cont = 0, qntdSimbolos = 10;
	int totalDePagantesPorFaixaDeIdade = somatorioDeVetor(qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade);
	double porcentagemDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade];
	for (i=0; i<qntdDeFaixasDeIdade; i++) {
		porcentagemDePagantesPorFaixaDeIdade[i] = inicializarPorcentagem(qntdDePagantesPorFaixaDeIdade[i], totalDePagantesPorFaixaDeIdade);
	}
	for (i=0; i<qntdDeFaixasDeIdade;i++) {
		printf("%03d-%03d total\t\t\t: ", (int)ceil(126 / qntdDeFaixasDeIdade)*i, (int)ceil(126 / qntdDeFaixasDeIdade)*i+9);
		printf("%03d\t- ", qntdDePagantesPorFaixaDeIdade[i]);
		if (porcentagemDePagantesPorFaixaDeIdade[i] != 100.0) {
			printf("%03.1lf%%\t\t", porcentagemDePagantesPorFaixaDeIdade[i]);
		}
		else {
			printf("%03.1lf%%\t", porcentagemDePagantesPorFaixaDeIdade[i]);
		}
		desenharGrafico(porcentagemDePagantesPorFaixaDeIdade[i], qntdSimbolos);
		printf("\r\n");
	}
	printf("        todos\t\t\t: ");
	printf("%03d\t- ", totalDePagantesPorFaixaDeIdade);
	printf("%03.1lf%%\t|", 100.0);
	for(j=0;j<100/qntdSimbolos;j++) {
		printf("=");
	}
	printf("|\r\n");
}

void imprimirTela5(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]) { // Tela 5 das informações do teatro
	limparTela();
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	int i, j, cont = 0, qntdSimbolos = 10;
	int qntdDePagantesInteiraAtual = 0, qntdDePagantesMeiaMenoresAtual = 0, qntdDePagantesMeiaIdososAtual = 0;
	for(i=0;i<qntdDeFileiras;i++) {
		for(j=0;j<qntdDeColunas;j++) {
			if (mapaDoTeatro[i][j] != (char)255) {
				switch((int)mapaDoTeatro[i][j] & MASCARA_IDADE) {
					case 0 ... 17:
						qntdDePagantesMeiaMenoresAtual++;
						break;
					case 18 ... 59:
						qntdDePagantesInteiraAtual++;
						break;
					case 60 ... 126:
						qntdDePagantesMeiaIdososAtual++;
						break;
				}
			}
		}
	}
	double porcentagemDePagantesInteiraAtual = inicializarPorcentagem(qntdDePagantesInteiraAtual, (qntdDePagantesInteiraAtual + qntdDePagantesMeiaMenoresAtual + qntdDePagantesMeiaIdososAtual));
	double porcentagemDePagantesMenoresAtual = inicializarPorcentagem(qntdDePagantesInteiraAtual, (qntdDePagantesMeiaMenoresAtual + qntdDePagantesMeiaMenoresAtual + qntdDePagantesMeiaIdososAtual));
	double porcentagemDePagantesIdososAtual = inicializarPorcentagem(qntdDePagantesInteiraAtual, (qntdDePagantesMeiaIdososAtual + qntdDePagantesMeiaMenoresAtual + qntdDePagantesMeiaIdososAtual));
	printf("Pagantes inteira atual\t\t: ");
	printf("%03d\t- ", qntdDePagantesInteiraAtual);
	if (porcentagemDePagantesInteiraAtual < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesInteiraAtual);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesInteiraAtual);
	}
	desenharGrafico(porcentagemDePagantesInteiraAtual, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesInteiraAtual * valorDoIngresso);
	printf("Pagantes meia menores atual\t: ");
	printf("%03d\t- ", qntdDePagantesMeiaMenoresAtual);
	if (porcentagemDePagantesMenoresAtual < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesMenoresAtual);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesMenoresAtual);
	}
	desenharGrafico(porcentagemDePagantesMenoresAtual, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesInteiraAtual * valorDoIngresso / 2);
	printf("Pagantes meia idosos atual\t: ");
	printf("%03d\t- ", qntdDePagantesMeiaIdososAtual);
	if (porcentagemDePagantesIdososAtual < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesIdososAtual);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesIdososAtual);
	}
	desenharGrafico(porcentagemDePagantesIdososAtual, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesInteiraAtual * valorDoIngresso / 2);
	printf("Pagantes atual\t\t\t: ");
	printf("%03d\t- ", qntdDePagantesInteiraAtual + qntdDePagantesMeiaMenoresAtual + qntdDePagantesMeiaIdososAtual);
	printf("%.1lf%%\t|", 100.0);
	for (i = 0; i < 100/qntdSimbolos; i++) {
		printf("=");
	}
	printf("| - R$ %04.2lf\r\n", valorDoIngresso*((qntdDePagantesInteiraAtual) + (qntdDePagantesInteiraAtual / 2) + (qntdDePagantesInteiraAtual / 2)));
}

void imprimirTela6(double valorDoIngresso, int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos) { // Tela 6 das informações do teatro
	limparTela();
	printf("\t\t\t\t\t\t\t|1234567890|\r\n");
	int i, cont = 0, qntdSimbolos = 10;
	double porcentagemDePagantesInteira = inicializarPorcentagem(qntdDePagantesInteira, (qntdDePagantesInteira + qntdDePagantesMeiaMenores + qntdDePagantesMeiaIdosos));
	double porcentagemDePagantesMenores = inicializarPorcentagem(qntdDePagantesMeiaMenores, (qntdDePagantesInteira + qntdDePagantesMeiaMenores + qntdDePagantesMeiaIdosos));
	double porcentagemDePagantesIdosos = inicializarPorcentagem(qntdDePagantesMeiaIdosos, (qntdDePagantesInteira + qntdDePagantesMeiaMenores + qntdDePagantesMeiaIdosos));
	printf("Pagantes inteira total\t\t: ");
	printf("%03d\t- ", qntdDePagantesInteira);
	if (porcentagemDePagantesInteira < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesInteira);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesInteira);
	}
	desenharGrafico(porcentagemDePagantesInteira, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesInteira * valorDoIngresso);
	printf("Pagantes meia menores total\t: ");
	printf("%03d\t- ", qntdDePagantesMeiaMenores);
	if (porcentagemDePagantesMenores < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesMenores);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesMenores);
	}
	desenharGrafico(porcentagemDePagantesMenores, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesMeiaMenores * valorDoIngresso / 2);
	printf("Pagantes meia idosos total\t: ");
	printf("%03d\t- ", qntdDePagantesMeiaIdosos);
	if (porcentagemDePagantesIdosos < 100.0) {
		printf("%.1lf%%\t\t", porcentagemDePagantesIdosos);		
	}
	else {
		printf("%.1lf%%\t", porcentagemDePagantesIdosos);
	}
	desenharGrafico(porcentagemDePagantesIdosos, qntdSimbolos);
	printf(" - R$ %04.2lf\r\n", qntdDePagantesMeiaIdosos * valorDoIngresso / 2);
	printf("Pagantes total\t\t\t: ");
	printf("%03d\t- ", qntdDePagantesInteira + qntdDePagantesMeiaMenores + qntdDePagantesMeiaIdosos);
	printf("%.1lf%%\t|", 100.0);
	for (i = 0; i < 100/qntdSimbolos; i++) {
		printf("=");
	}
	printf("| - R$ %04.2lf\r\n", valorDoIngresso*((qntdDePagantesInteira) + (qntdDePagantesInteira / 2) + (qntdDePagantesInteira / 2)));
}

void imprimirMapaDoTeatro(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDePagantesHomens, int qntdDePagantesMulheres, int qntdDeFaixasDeIdade, int qntdDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade], int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos) { // Função que gerencia a seqüência de exibição de telas que contêm as informações do teatro
	imprimirTela1(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
	pausa();
	imprimirTela2(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres);
	pausa();
	imprimirTela3(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDeFaixasDeIdade);
	pausa();
	imprimirTela4(qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade);
	pausa();
	imprimirTela5(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
	pausa();
	imprimirTela6(valorDoIngresso, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
	pausa();
}

void imprimirAjuda() { // Tela do menu de ajuda, que descreve o funcionamento do programa
	limparTela();
	printf("Manual de uso do programa. Pressione ENTER para continuar.\r\n");
	pausa();
	limparTela();
	printf("Depois de informar o valor do ingresso e a quantidade de fileiras e colunas, é exibido um menu com várias opções.\r\n");
	printf("Você deve digitar o número referente à ação que deseja realizar.\r\n");
	pausa();
	limparTela();
	printf("A opção 0 leva a este manual de ajuda.\r\n");
	pausa();
	limparTela();
	printf("A opção 1 leva a uma tela para consultar se um assento está livre ou reservado.\r\n");
	printf("Você deverá informar o número da fileira e em seguida o número da coluna.\r\n");
	printf("A informação do assento na fileira e coluna informadas será mostrada.\r\n");
	printf("Caso esteja livre, a mensagem \"Assento livre\" será exibida.\r\n");
	printf("Caso contrário uma mensagem que exibe sexo e idade da pessoa ocupando o assento será exibida.\r\n");
	pausa();
	limparTela();
	printf("A opção 2 leva a uma tela para consultar se uma seqüência de assentos em uma mesma fileira está livre ou reservada.\r\n");
	printf("Você deverá informar quantos assentos deseja consultar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer verificar a disponibilidade dos assentos a partir de um assento inicial ou não.\r\n");
	printf("Se sim, você deverá informar a fileira e a coluna do primeiro assento e o programa informará se os assentos devidos estão livres ou não.\r\n");
	printf("Se não, o programa mostrará o primeiro assento onde a seqüência está livre ou informa que não há tantos assentos livres.\r\n");
	pausa();
	limparTela();
	printf("A opção 3 leva a uma tela para consultar se uma seqüência de assentos em uma ou mais fileiras está livre ou reservada.\r\n");
	printf("Você deverá informar quantas fileiras e colunas deseja consultar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer verificar a disponibilidade dos assentos a partir de um assento inicial ou não.\r\n");
	printf("Se sim, você deverá informar a fileira e a coluna do primeiro assento e o programa informará se os assentos devidos estão livres ou não.\r\n");
	printf("Se não, o programa mostrará o primeiro assento onde tantas fileiras e colunas estão livres ou informa que não há tantos assentos livres.\r\n");
	pausa();
	limparTela();
	printf("A opção 4 leva a uma tela para reservar assentos em uma fileira.\r\n");
	printf("Você deverá informar quantos assentos deseja reservar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer reservar os assentos a partir de um assento inicial ou não.\r\n");
	printf("Em caso positivo, você deverá informar a fileira e a coluna do assento inicial.\r\n");
	printf("Se tiver tantos lugares livres, o programa continuará, se não, avisará que não há tantos lugares livres.\r\n");
	printf("Se tiver, você deverá informar o sexo e a idade para cada assento reservado.\r\n");
	printf("Antes de voltar ao menu principal, você verá as informações atualizadas do teatro.\r\n");
	pausa();
	limparTela();
	printf("A opção 5 leva a uma tela para reservar assentos em uma ou mais fileiras.\r\n");
	printf("Você deverá informar quantas fileiras e colunas deseja reservar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer reservar os assentos a partir de um assento inicial ou não.\r\n");
	printf("Em caso positivo, você deverá informar a fileira e a coluna do assento inicial.\r\n");
	printf("Se tiver tantos lugares livres, o programa continuará, se não, avisará que não há tantos lugares livres.\r\n");
	printf("Se tiver, você deverá informar o sexo e a idade para cada assento reservado.\r\n");
	printf("Antes de voltar ao menu principal, você verá as informações atualizadas do teatro.\r\n");
	pausa();
	limparTela();
	printf("A opção 6 leva a uma tela para liberar assentos em uma fileira.\r\n");
	printf("Você deverá informar quantos assentos deseja liberar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer liberar os assentos a partir de um assento inicial ou não.\r\n");
	printf("Em caso positivo, você deverá informar a fileira e a coluna do assento inicial.\r\n");
	printf("Se tiver tantos lugares reservados, o programa continuará, se não, avisará que não há tantos lugares reservados.\r\n");
	printf("Antes de voltar ao menu principal, você verá as informações atualizadas do teatro.\r\n");
	pausa();
	limparTela();
	printf("A opção 7 leva a uma tela para liberar assentos em uma ou mais fileiras.\r\n");
	printf("Você deverá informar quantas fileiras e colunas deseja liberar.\r\n");
	printf("Observe que o programa limitará os valores que você poderá informar, dependendo do tamanho do teatro, definido no início da execução do programa.\r\n");
	printf("Em seguida, você deverá informar se quer liberar os assentos a partir de um assento inicial ou não.\r\n");
	printf("Em caso positivo, você deverá informar a fileira e a coluna do assento inicial.\r\n");
	printf("Se tiver tantos lugares reservados, o programa continuará, se não, avisará que não há tantos lugares reservados.\r\n");
	printf("Antes de voltar ao menu principal, você verá as informações atualizadas do teatro.\r\n");
	pausa();
	limparTela();
	printf("A opção 8 leva a uma seqüência de telas que exibem a situação atual do teatro.\r\n");
	printf("A primeira tela mostra os assentos do teatro onde é possível ver se estão livres ou reservados.\r\n");
	printf("Na mesma tela é possível ver a porcentagem de assentos livres e reservados com um gráfico representando estes valores.\r\n");
	printf("Após apertar a tecla ENTER, você será levado à segunda tela.\r\n");
	printf("A segunda tela mostra a quantidade e porcentagem de homens e mulheres com assentos reservados no momento e durante toda a execução do programa.\r\n\r\n");
	printf("Aperte a tecla ENTER para ir à terceira tela.\r\n");
	printf("A terceira tela mostra a quantidade e porcentagem de pessoas com assentos reservados no momento, divididas em faixas de idade.\r\n\r\n");
	printf("Aperte a tecla ENTER para seguir.\r\n");
	printf("A quarta tela mostra a quantidade e porcentagem de pessoas com assentos reservados durante toda a execução do programa, divididas em faixas de idade.\r\n\r\n");
	printf("Aperte a tecla ENTER para continuar.\r\n");
	printf("A quinta e a sexta telas mostras a quantidade e porcentagem de pessoas com assentos reservados no momento e durante toda a execução do programa, divididas pelo valor que pagaram pelo ingresso.\r\n");
	printf("Crianças e adolescentes com idades entre 0 e 17 anos pagam metade do valor do ingresso, bem como pessoas com 60 anos ou mais. Os demais pagam o valor inteiro.\r\n");
	pausa();
	limparTela();
	printf("A opção 9 leva a uma tela onde você deverá confirmar se quer mesmo sair do programa.\r\n");
	printf("Você deverá responder sim ou não com a letra inicial de uma das duas palavras (s ou n).\r\n");
	printf("A letra pode ser minúscula ou maiúscula.\r\n");
	printf("Se você informar s ou S, o programa terminará.\r\n");
	printf("Se você informar n ou N, será novamente exibido o menu com as várias opções.\r\n");
	pausa();
}
