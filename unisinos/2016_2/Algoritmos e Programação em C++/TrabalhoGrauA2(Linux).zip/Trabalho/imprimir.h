void imprimirMenu();

void desenharGrafico(double porcentagem, int qntdSimbolos);

void imprimirTela1(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]);

void imprimirTela2(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDePagantesHomens, int qntdDePagantesMulheres);

void imprimirTela3(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDeFaixasDeIdade);

void imprimirTela4(int qntdDeFaixasDeIdade, int qntdDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade]);

void imprimirTela5(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]);

void imprimirTela6(double valorDoIngresso, int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos);

void imprimirMapaDoTeatro(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas], int qntdDePagantesHomens, int qntdDePagantesMulheres, int qntdDeFaixasDeIdade, int qntdDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade], int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos);

void imprimirAjuda();
