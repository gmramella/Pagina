#include <stdio.h>
#include <math.h>

void liberarTodosAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]) { // Função para deixar todos assentos livres
	int i,j;
	for (i=0; i<qntdDeFileiras; i++) {
		for (j=0; j<qntdDeColunas; j++) {
			mapaDoTeatro[i][j] = (char)255;
		}
	}
}

void liberarReservaDeNAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]) { // Função para deixar n assentos livres em uma fileira
	int quantos;
	limparTela();
	printf("Deseja liberar quantos assentos (1-%d)? ", qntdDeColunas);
	scanf("%d", &quantos);
	limparBuffer();
	while(quantos < 0 || quantos > qntdDeColunas) {
		limparTela();
		printf("Valor invalido\r\n");
		printf("Deseja liberar quantos assentos (1-%d)? ", qntdDeColunas);
		scanf("%d", &quantos);
		limparBuffer();
	}
	if (quantos == 0) {
		return;
	}
	int fileira, coluna;
	limparTela();
	printf("Fileira (1-%d): ", qntdDeFileiras);
	scanf("%d", &fileira);
	limparBuffer();
	while (fileira < 0 || fileira > qntdDeFileiras) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Fileira (1-%d): ", qntdDeFileiras);
		scanf("%d", &fileira);
		limparBuffer();
	}
	if (fileira == 0) {
		return;
	}
	fileira--;
	limparTela();
	printf("Coluna (1-%d): ", qntdDeColunas - quantos + 1);
	scanf("%d", &coluna);
	limparBuffer();
	while (coluna < 0 || coluna > qntdDeColunas - quantos + 1) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Coluna (1-%d): ", qntdDeColunas - quantos + 1);
		scanf("%d", &coluna);
		limparBuffer();
	}
	if (coluna == 0) {
		return;
	}
	coluna--;
	int i, cont = 0;
	for(i=coluna; i<coluna + quantos; i++) {
		if (mapaDoTeatro[fileira][i] != (char)255) {
			cont++;
		}
		else {
			break;
		}
	}
	limparTela();
	if (cont == quantos) {
		for(i=coluna; i<coluna + quantos; i++) {
			mapaDoTeatro[fileira][i] = (char)255;
		}
		if (quantos > 1) {
			printf("Foram liberados %d lugares na fileira %d a partir do assento %d\r\n", quantos, fileira+1, coluna+1);
		}
		else {
			printf("Foi liberado %d lugar na fileira %d e coluna %d\r\n", quantos, fileira+1, coluna+1);
		}
	}
	else {
		if (quantos > 1) {
			printf("Não foi possível liberar %d lugares na fileira %d a partir do assento %d porque pelo menos um já está livre\r\n", quantos, fileira+1, coluna+1);
		}
		else {
			printf("Não foi possível liberar o assento na fileira %d e coluna %d porque ele já está livre\r\n", fileira+1, coluna+1);
		}
	}
	pausa();
}

void liberarReservaDeNxMAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]) { // Função para deixar n x m assentos livres em uma ou mais fileiras
	int quantasFileiras, quantasColunas;
	limparTela();
	printf("Deseja liberar quantas fileiras (1-%d)? ", qntdDeFileiras);
	scanf("%d", &quantasFileiras);
	limparBuffer();
	while(quantasFileiras < 0 || quantasFileiras > qntdDeFileiras) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Deseja liberar quantas fileiras (1-%d)? ", qntdDeFileiras);
		scanf("%d", &quantasFileiras);
		limparBuffer();
	}
	if (quantasFileiras == 0) {
		return;
	}
	limparTela();
	printf("Deseja liberar quantas colunas (1-%d)? ", qntdDeColunas);
	scanf("%d", &quantasColunas);
	limparBuffer();
	while(quantasColunas < 0 || quantasColunas > qntdDeColunas) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Deseja liberar quantas colunas (1-%d)? ", qntdDeColunas);
		scanf("%d", &quantasColunas);
		limparBuffer();
	}
	if (quantasColunas == 0) {
		return;
	}
	int fileira, coluna;
	limparTela();
	printf("Fileira (1-%d): ", qntdDeFileiras - quantasFileiras + 1);
	scanf("%d", &fileira);
	limparBuffer();
	while (fileira < 0 || fileira > qntdDeFileiras - quantasFileiras + 1) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Fileira (1-%d): ", qntdDeFileiras - quantasFileiras + 1);
		scanf("%d", &fileira);
		limparBuffer();
	}
	if (fileira == 0) {
		return;
	}
	fileira--;
	limparTela();
	printf("Coluna (1-%d): ", qntdDeColunas - quantasColunas + 1);
	scanf("%d", &coluna);
	limparBuffer();
	while (coluna < 0 || coluna > qntdDeColunas - quantasColunas + 1) {
		limparTela();
		printf("Valor inválido\r\n");
		printf("Coluna (1-%d): ", qntdDeColunas - quantasColunas + 1);
		scanf("%d", &coluna);
		limparBuffer();
	}
	if (coluna == 0) {
		return;
	}
	coluna--;
	int i, j, cont = 0;
	for(i=fileira; i<fileira+quantasFileiras; i++) {
		for(j=coluna; j<coluna+quantasColunas; j++) {
			if (mapaDoTeatro[i][j] != (char)255) {
				cont++;
			}
			else {
				break;
			}
		}
	}
	limparTela();
	if (cont == (quantasFileiras * quantasColunas)) {
		for(i=fileira; i<fileira+quantasFileiras; i++) {
			for(j=coluna; j<coluna+quantasColunas; j++) {
				mapaDoTeatro[i][j] = (char)255;
			}
		}
		if ((quantasFileiras * quantasColunas) > 1) {
			printf("Foram liberados %d lugares nas fileiras %d a %d do assento %d ao %d\r\n", (quantasFileiras * quantasColunas), fileira+1, fileira+quantasFileiras, coluna+1, coluna+quantasColunas);
		}
		else {
			printf("Foi liberado %d lugar na fileira %d e coluna %d\r\n", (quantasFileiras * quantasColunas), fileira+1, coluna+1);
		}
	}
	else {
		if ((quantasFileiras * quantasColunas) > 1) {
			printf("Não foi possível liberar %d lugares nas fileiras %d a %d e colunas %d a %d porque pelo menos um já está livre\r\n", (quantasFileiras * quantasColunas), fileira+1, fileira+quantasFileiras, coluna+1, coluna+quantasColunas);
		}
		else {
			printf("Não foi possível liberar o assento na fileira %d e coluna %d porque ele já está livre\r\n", fileira+1, coluna+1);
		}
	}
	pausa();
}
