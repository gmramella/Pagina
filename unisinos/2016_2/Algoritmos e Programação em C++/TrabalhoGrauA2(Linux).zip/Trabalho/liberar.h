void liberarTodosAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]);

void liberarReservaDeNAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]);

void liberarReservaDeNxMAssentos(int qntdDeFileiras, int qntdDeColunas, char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]);
