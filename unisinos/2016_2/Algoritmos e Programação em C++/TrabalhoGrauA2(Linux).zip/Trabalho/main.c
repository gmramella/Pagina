#include "auxiliares.h"
#include "imprimir.h"
#include "consultar.h"
#include "reservar.h"
#include "liberar.h"

#include <stdio.h>
#include <locale.h>
#include <math.h>

int main() {
	setlocale(LC_ALL, "Portuguese"); // para escrever texto em português

	double valorDoIngresso;
	limparTela();
	printf("Valor do ingresso: ");
	scanf("%lf", &valorDoIngresso);
	limparBuffer();
	while (valorDoIngresso < 0.0) { // laço que força o preço do ingresso a ser não negativo
		limparTela();
		printf("Valor do ingresso deve ser positivo\r\n");
		printf("Valor do ingresso: ");
		scanf("%lf", &valorDoIngresso);
		limparBuffer();
	}

	int qntdDeFileiras;
	limparTela();
	printf("Quantidade de fileiras: ");
	scanf("%d", &qntdDeFileiras);
	limparBuffer();
	while (qntdDeFileiras <= 0) { // laço que força o número de fileiras a ser maior que 0
		limparTela();
		printf("Quantidade de fileiras deve ser maior que zero\r\n");
		printf("Quantidade de fileiras: ");
		scanf("%d", &qntdDeFileiras);
		limparBuffer();
	}

	int qntdDeColunas;
	limparTela();
	printf("Quantidade de colunas: ");
	scanf("%d", &qntdDeColunas);
	limparBuffer();
	while (qntdDeColunas <= 0) { // laço que força o número de colunas a ser maior que 0
		limparTela();
		printf("Quantidade de colunas deve ser maior que zero\r\n");
		printf("Quantidade de colunas: ");
		printf("Coluna: ");
		scanf("%d", &qntdDeColunas);
		limparBuffer();
	}

	char mapaDoTeatro[qntdDeFileiras][qntdDeColunas]; // matriz que armazena os assentos do teatro, informando se estão livres ou então sexo e idade do ocupante
	liberarTodosAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro); // função que limpa lixo da memória colocando o valor 255 em todos os assentos

	int qntdDePagantesHomens = 0, qntdDePagantesMulheres = 0; // variáveis que são incrementadas sempre que alguém reserva um assento, dependendo do sexo

	int tamanhoDasFaixasDeIdade = 10; // variável de configuração para que as idades sejam exibidas em faixas dessa largura (0-9 anos, 10-19 anos, ...)
	int qntdDeFaixasDeIdade = ceil(126 / tamanhoDasFaixasDeIdade); // variável de configuração que indica quantas faixas existem
	int qntdDePagantesPorFaixaDeIdade[qntdDeFaixasDeIdade]; // variável que é incrementada sempre que alguém reserva um assento, dependendo da idade
	inicializarVetor(qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, 0);

	int qntdDePagantesInteira = 0, qntdDePagantesMeiaMenores = 0, qntdDePagantesMeiaIdosos = 0; // variáveis que são incrementadas sempre que alguém reserva um assento, dependendo da idade

	int sair = 0;
	do { // laço principal do programa que só acaba se usuário desejar encerrar programa
		int opcao;
		limparTela();
		imprimirMenu();
		scanf("%d", &opcao);
		limparBuffer();
		while (opcao < 0 || opcao > 9) { // laço que força usuário a digitar um valor entre 0 e 9, porém se digitar uma letra, vai executar a última opção escolhida (BUG)
			limparTela();
			printf("Opção inválida\r\n");
			imprimirMenu();
			scanf("%d", &opcao);
			limparBuffer();
		}
		char teclasSimNao[2] = {'s', 'n'}; // variável usada no switch a seguir na opção de encerrar
		switch (opcao) {
			case 0:
				imprimirAjuda();
				break;
			case 1:
				consultarSituacaoDeAssento(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
				break;
			case 2:
				consultarDisponibilidadeDeNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
				break;
			case 3:
				consultarDisponibilidadeDeNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
				break;
			case 4:
				reservarNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, &qntdDePagantesHomens, &qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, &qntdDePagantesInteira, &qntdDePagantesMeiaMenores, &qntdDePagantesMeiaIdosos);
				break;
			case 5:
				reservarNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, &qntdDePagantesHomens, &qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, &qntdDePagantesInteira, &qntdDePagantesMeiaMenores, &qntdDePagantesMeiaIdosos);
				imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
				break;
			case 6:
				liberarReservaDeNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
				imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
				break;
			case 7:
				liberarReservaDeNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
				imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
				break;
			case 8:
				imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
				break;
			case 9:
				sair = (forcarTecla1Em2(teclasSimNao, "Deseja realmente sair", "Opção inválida") == 's');
				break;
		}
	} while (!sair);

	limparTela(); // Em ambientes Unix, limpa a tela antes de retornar ao terminal (o mesmo acontece se executar o programa a partir do prompt)
	return 0;
}
