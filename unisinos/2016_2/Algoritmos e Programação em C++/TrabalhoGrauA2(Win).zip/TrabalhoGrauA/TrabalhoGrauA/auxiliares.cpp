#define _CRT_SECURE_NO_WARNINGS

#include "defines.h"
#include <vector>
#include <ctype.h>

using namespace std;

void inicializarVetor(vector<int> vetor, int valor) { // Fun��o que inicializa um vetor com todos os seus elementos contendo um mesmo valor
	size_t i;
	for (i = 0; i < vetor.size(); i++) {
		vetor[i] = valor;
	}
}

int encontradosNxMLugaresAPartirDeUmAssento(vector<vector<char>> mapaDoTeatro, int fileira, int coluna, int quantasFileiras, int quantasColunas) { // Fun��o auxiliar para verificar se os n x m assentos a partir de um espec�fico est�o livres
	int i, j;
	int cont = 0;
	for (i = fileira; i<fileira + quantasFileiras; i++) {
		for (j = coluna; j<coluna + quantasColunas; j++) {
			if (mapaDoTeatro[i][j] == (char)255) {
				cont++;
			}
		}
	}
	return (cont == (quantasFileiras * quantasColunas));
}

double inicializarPorcentagem(double parte, double total) { // Fun��o que inicializa uma porcentagem com 0 ou com seu valor, porque esta vari�vel depende do valor da vari�vel passada como segundo par�metro da fun��o (double total) e se ela for 0, dar� erro porque n�o existe divis�o por 0
	return (total != 0) ? (100 * parte / total) : 0;
}

int somatorioDeVetor(int tamanho, vector<int> vetor) { // Fun��o que retorna a soma de todos os elementos de um vetor
	size_t i;
	int soma = 0;
	for (i = 0; i < vetor.size(); i++) {
		soma += vetor[i];
	}
	return soma;
}

char forcarTecla1Em2(char teclas[2], char* pergunta, char* erro) { // Fun��o para for�ar o usu�rio a digitar uma tecla determinada
	char resposta;
	limparTela();
	printf("%s (%c/%c)? ", pergunta, teclas[0], teclas[1]);
	scanf("%c", &resposta);
	limparBuffer();
	while (tolower(resposta) != teclas[0] && tolower(resposta) != teclas[1]) {
		limparTela();
		printf("%s\r\n", erro);
		printf("%s (%c/%c)? ", pergunta, teclas[0], teclas[1]);
		scanf("%c", &resposta);
		limparBuffer();
	}
	return tolower(resposta);
}
