#pragma once

#include "defines.h"
#include <vector>
#include <ctype.h>

using namespace std;

void inicializarVetor(vector<int> vetor, int valor);

int encontradosNxMLugaresAPartirDeUmAssento(vector<vector<char>> mapaDoTeatro, int fileira, int coluna, int quantasFileiras, int quantasColunas);

double inicializarPorcentagem(double parte, double total);

int somatorioDeVetor(int tamanho, vector<int> vetor);

char forcarTecla1Em2(char teclas[2], char* pergunta, char* erro);
