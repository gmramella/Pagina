#pragma once

#include "auxiliares.h"
#include <stdio.h>
#include <vector>



void consultarSituacaoDeAssento(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);

void consultarDisponibilidadeDeNAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);

void consultarDisponibilidadeDeNxMAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);
