#include <stdlib.h>
#include <stdio.h>

#ifdef _WIN32 // O computador que compilar o programa � windows
	#include <conio.h>
	void pausa() { // Fun��o para pausar o prompt do windows que est� rodando o programa
		_getch();
	}
	void limparTela() { // Fun��o para limpar o prompt do windows que est� rodando o programa
		system("cls");
	}
	#elif defined __unix__ // O computador que compilar o programa � linux
	void pausa() { // Fun��o para pausar o terminal do linux que est� rodando o programa
		system("read x");
	}
	void limparTela() { // Fun��o para limpar o terminal do linux que est� rodando o programa
		system("clear");
	}
	#elif defined __APPLE__ // O computador que compilar o programa � mac
	void pausa() { // Fun��o para pausar o terminal do mac que est� rodando o programa
				   //system("read x"); // N�o sei qual o comando para pausar o terminal em um mac
	}
	void limparTela() { // Fun��o para limpar o terminal do mac que est� rodando o programa
						//system("clear"); // N�o sei qual o comando para limpar o terminal em um mac
	}
#endif

void limparBuffer() { // Fun��o para limpar o buffer depois que ler um valor que o usu�rio digitar
	getc(stdin);
}
