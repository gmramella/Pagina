#pragma once

#ifndef MASCARA_LIVRE
	#define MASCARA_LIVRE 255
#endif

#ifndef MASCARA_SEXO
	#define MASCARA_SEXO 128
#endif

#ifndef MASCARA_IDADE
	#define MASCARA_IDADE 127
#endif

#ifndef HOMEM
	#define HOMEM (char)0
#endif

#ifndef MULHER
	#define MULHER (char)128
#endif

void pausa();
void limparTela();
void limparBuffer();
