#pragma once

#include "defines.h"
#include "auxiliares.h"
#include <stdio.h>
#include <vector>



void imprimirMenu();

void imprimirAjuda();

void desenharGrafico(double porcentagem, int qntdSimbolos);

void imprimirTela1(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);

void imprimirTela2(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int qntdDePagantesHomens, int qntdDePagantesMulheres);

void imprimirTela3(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int qntdDeFaixasDeIdade);

void imprimirTela4(int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade);

void imprimirTela5(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);

void imprimirTela6(double valorDoIngresso, int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos);

void imprimirMapaDoTeatro(double valorDoIngresso, int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int qntdDePagantesHomens, int qntdDePagantesMulheres, int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade, int qntdDePagantesInteira, int qntdDePagantesMeiaMenores, int qntdDePagantesMeiaIdosos);
