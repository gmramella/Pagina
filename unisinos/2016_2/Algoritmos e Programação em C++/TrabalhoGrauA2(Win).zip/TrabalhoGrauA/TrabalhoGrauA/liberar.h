#pragma once

#include "auxiliares.h"
#include <stdio.h>
#include <vector>



void liberarTodosAssentos(vector<vector<char>> mapaDoTeatro);

void liberarReservaDeNAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);

void liberarReservaDeNxMAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro);
