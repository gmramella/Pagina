#define _CRT_SECURE_NO_WARNINGS

#include "defines.h"
#include "liberar.h"
#include "auxiliares.h"
#include "imprimir.h"
#include "consultar.h"
#include "reservar.h"

#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <vector>
#include <conio.h>
#include <ctype.h>

using namespace std;

int main() {
	setlocale(LC_ALL, "Portuguese"); // para escrever texto em portugu�s

	double valorDoIngresso;
	limparTela();
	printf("Valor do ingresso: ");
	scanf("%lf", &valorDoIngresso);
	limparBuffer();
	while (valorDoIngresso < 0.0) { // la�o que for�a o pre�o do ingresso a ser n�o negativo
		limparTela();
		printf("Valor do ingresso deve ser positivo\r\n");
		printf("Valor do ingresso: ");
		scanf("%lf", &valorDoIngresso);
		limparBuffer();
	}

	int qntdDeFileiras;
	limparTela();
	printf("Quantidade de fileiras: ");
	scanf("%d", &qntdDeFileiras);
	limparBuffer();
	while (qntdDeFileiras <= 0) { // la�o que for�a o n�mero de fileiras a ser maior que 0
		limparTela();
		printf("Quantidade de fileiras deve ser maior que zero\r\n");
		printf("Quantidade de fileiras: ");
		scanf("%d", &qntdDeFileiras);
		limparBuffer();
	}

	int qntdDeColunas;
	limparTela();
	printf("Quantidade de colunas: ");
	scanf("%d", &qntdDeColunas);
	limparBuffer();
	while (qntdDeColunas <= 0) { // la�o que for�a o n�mero de colunas a ser maior que 0
		limparTela();
		printf("Quantidade de colunas deve ser maior que zero\r\n");
		printf("Quantidade de colunas: ");
		printf("Coluna: ");
		scanf("%d", &qntdDeColunas);
		limparBuffer();
	}
	
	int i;
	vector<vector<char>> mapaDoTeatro; // matriz que armazena os assentos do teatro, informando se est�o livres ou ent�o sexo e idade do ocupante
	mapaDoTeatro.resize(qntdDeFileiras);
	for (i = 0; i < qntdDeFileiras; i++) {
		mapaDoTeatro[i].resize(qntdDeColunas);
	}
	liberarTodosAssentos(mapaDoTeatro); // fun��o que limpa lixo da mem�ria colocando o valor 255 em todos os assentos
	
	int qntdDePagantesHomens = 0, qntdDePagantesMulheres = 0; // vari�veis que s�o incrementadas sempre que algu�m reserva um assento, dependendo do sexo
	
	int tamanhoDasFaixasDeIdade = 10; // vari�vel de configura��o para que as idades sejam exibidas em faixas dessa largura (0-9 anos, 10-19 anos, ...)
	int qntdDeFaixasDeIdade = (int)ceil(126 / tamanhoDasFaixasDeIdade); // vari�vel de configura��o que indica quantas faixas existem
	vector<int> qntdDePagantesPorFaixaDeIdade; // vari�vel que � incrementada sempre que algu�m reserva um assento, dependendo da idade
	inicializarVetor(qntdDePagantesPorFaixaDeIdade, 0);

	int qntdDePagantesInteira = 0, qntdDePagantesMeiaMenores = 0, qntdDePagantesMeiaIdosos = 0; // vari�veis que s�o incrementadas sempre que algu�m reserva um assento, dependendo da idade
	
	int sair = 0;
	do { // la�o principal do programa que s� acaba se usu�rio desejar encerrar programa
		int opcao;
		limparTela();
		imprimirMenu();
		scanf("%d", &opcao);
		limparBuffer();
		while (opcao < 0 || opcao > 9) { // la�o que for�a usu�rio a digitar um valor entre 0 e 9, por�m se digitar uma letra, vai executar a �ltima op��o escolhida (BUG)
			limparTela();
			printf("Op��o inv�lida\r\n");
			imprimirMenu();
			scanf("%d", &opcao);
			limparBuffer();
		}
		char teclasSimNao[2] = { 's', 'n' }; // vari�vel usada no switch a seguir na op��o de encerrar
		switch (opcao) {
		case 0:
			imprimirAjuda();
			break;
		case 1:
			consultarSituacaoDeAssento(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
			break;
		case 2:
			consultarDisponibilidadeDeNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
			break;
		case 3:
			consultarDisponibilidadeDeNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
			break;
		case 4:
			reservarNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, &qntdDePagantesHomens, &qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, &qntdDePagantesInteira, &qntdDePagantesMeiaMenores, &qntdDePagantesMeiaIdosos);
			break;
		case 5:
			reservarNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro, &qntdDePagantesHomens, &qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, &qntdDePagantesInteira, &qntdDePagantesMeiaMenores, &qntdDePagantesMeiaIdosos);
			imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
			break;
		case 6:
			liberarReservaDeNAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
			imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
			break;
		case 7:
			liberarReservaDeNxMAssentos(qntdDeFileiras, qntdDeColunas, mapaDoTeatro);
			imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
			break;
		case 8:
			imprimirMapaDoTeatro(valorDoIngresso, qntdDeFileiras, qntdDeColunas, mapaDoTeatro, qntdDePagantesHomens, qntdDePagantesMulheres, qntdDeFaixasDeIdade, qntdDePagantesPorFaixaDeIdade, qntdDePagantesInteira, qntdDePagantesMeiaMenores, qntdDePagantesMeiaIdosos);
			break;
		case 9:
			sair = (forcarTecla1Em2(teclasSimNao, "Deseja realmente sair", "Op��o inv�lida") == 's');
			break;
		}
	} while (!sair);

	limparTela(); // Em ambientes Unix, limpa a tela antes de retornar ao terminal (o mesmo acontece se executar o programa a partir do prompt)
	return 0;
}
