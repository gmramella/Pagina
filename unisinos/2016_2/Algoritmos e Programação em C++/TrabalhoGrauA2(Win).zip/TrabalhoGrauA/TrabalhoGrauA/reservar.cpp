#define _CRT_SECURE_NO_WARNINGS

#include "auxiliares.h"
#include <vector>

using namespace std;

void reservarNAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int* qntdDePagantesHomens, int* qntdDePagantesMulheres, int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade, int* qntdDePagantesInteira, int* qntdDePagantesMeiaMenores, int* qntdDePagantesMeiaIdosos) { // Fun��o para deixar n assentos reservados em uma fileira
	int quantos;
	char especifico;
	limparTela();
	printf("Deseja reservar quantos assentos (1-%d)? ", qntdDeColunas);
	scanf("%d", &quantos);
	limparBuffer();
	while (quantos < 0 || quantos > qntdDeColunas) {
		limparTela();
		printf("Valor inv�lido\r\n");
		printf("Deseja reservar quantos assentos (1-%d)? ", qntdDeColunas);
		scanf("%d", &quantos);
		limparBuffer();
	}
	if (quantos == 0) {
		return;
	}
	limparTela();
	printf("Deseja reservar a partir de um assento espec�fico (s/n)? ");
	scanf("%c", &especifico);
	limparBuffer();
	while (toupper(especifico) != 'S' && toupper(especifico) != 'N') { // la�o que for�a usu�rio a digitar s ou n
		limparTela();
		printf("Op��o inv�lida\r\n");
		printf("Deseja reservar a partir de um assento espec�fico (s/n)? ");
		scanf("%c", &especifico);
		limparBuffer();
	}
	if (toupper(especifico) == 'S') {
		int fileira, coluna;
		limparTela();
		printf("Fileira (1-%d): ", qntdDeFileiras);
		scanf("%d", &fileira);
		limparBuffer();
		while (fileira < 0 || fileira > qntdDeFileiras) {
			limparTela();
			printf("Valor inv�lido\r\n");
			printf("Fileira (1-%d): ", qntdDeFileiras);
			scanf("%d", &fileira);
			limparBuffer();
		}
		if (fileira == 0) {
			return;
		}
		fileira--;
		limparTela();
		printf("Coluna (1-%d): ", qntdDeColunas - quantos + 1);
		scanf("%d", &coluna);
		limparBuffer();
		while (coluna < 0 || coluna > qntdDeColunas - quantos + 1) {
			limparTela();
			printf("Valor inv�lido\r\n");
			printf("Coluna (1-%d): ", qntdDeColunas - quantos + 1);
			scanf("%d", &coluna);
			limparBuffer();
		}
		if (coluna == 0) {
			return;
		}
		coluna--;
		int i, cont = 0, encontrado = 0;
		for (i = coluna; i<qntdDeColunas; i++) {
			if (mapaDoTeatro[fileira][i] == (char)255) {
				cont++;
				if (cont == quantos) {
					encontrado = 1;
					break;
				}
			}
			else {
				cont = 0;
			}
		}
		limparTela();
		if (encontrado) {
			for (i = coluna; i<coluna + quantos; i++) {
				char sexo;
				int idade;
				int mascara;
				limparTela();
				printf("Sexo (m/f): ");
				scanf("%c", &sexo);
				limparBuffer();
				while (toupper(sexo) != 'M' && toupper(sexo) != 'F') { // la�o que for�a usu�rio a digitar m ou f
					limparTela();
					printf("Op��o inv�lida\r\n");
					printf("Sexo (m/f): ");
					scanf("%c", &sexo);
					limparBuffer();
				}
				limparTela();
				printf("Idade (0-126): ");
				scanf("%d", &idade);
				limparBuffer();
				while (idade < 0 || idade > 126) { // la�o que for�a usu�rio a digitar idade certa
					limparTela();
					printf("Op��o inv�lida\r\n");
					printf("Idade (0-126): ");
					scanf("%d", &idade);
					limparBuffer();
				}
				mascara = 128 * (toupper(sexo) == 'F');
				mascara += idade;
				mapaDoTeatro[fileira][i] = (char)mascara;

				if (toupper(sexo) == 'M') {
					(*qntdDePagantesHomens)++;
				}
				else {
					(*qntdDePagantesMulheres)++;
				}
				qntdDePagantesPorFaixaDeIdade[(idade / (int)ceil(126 / qntdDeFaixasDeIdade))]++;
				if (0 <= idade && idade <= 17) {
					(*qntdDePagantesMeiaMenores)++;
				}
				else if (18 <= idade && idade <= 59) {
					(*qntdDePagantesInteira)++;
				}
				else {
					(*qntdDePagantesMeiaIdosos)++;
				}
			}
			limparTela();
			if (quantos > 1) {
				printf("Reserva de %d lugares efetuada na fileira %d a partir do assento %d\r\n", quantos, fileira + 1, coluna + 1);
			}
			else {
				printf("Reserva de %d lugar efetuada na fileira %d e coluna %d\r\n", quantos, fileira + 1, coluna + 1);
			}
		}
		else {
			limparTela();
			if (quantos > 1) {
				printf("Nao foram encontrados %d lugares a partir do assento informado\r\n", quantos);
			}
			else {
				printf("N�o h� assentos livres\r\n");
			}
		}
	}
	else {
		int i, j, cont = 0, encontrado = 0;
		for (i = 0; i<qntdDeFileiras; i++) {
			for (j = 0; j<qntdDeColunas; j++) {
				if (mapaDoTeatro[i][j] == (char)255) {
					cont++;
					if (cont == quantos) {
						encontrado = 1;
						break;
					}
				}
				else {
					cont = 0;
				}
			}
			if (encontrado) {
				break;
			}
			cont = 0;
		}
		limparTela();
		if (encontrado) {
			int k;
			for (k = j - quantos + 1; k<j + 1; k++) {
				char sexo;
				int idade;
				int mascara;
				limparTela();
				printf("Sexo (m/f): ");
				scanf("%c", &sexo);
				limparBuffer();
				while (toupper(sexo) != 'M' && toupper(sexo) != 'F') { // la�o que for�a usu�rio a digitar m ou f
					limparTela();
					printf("Op��o inv�lida\r\n");
					printf("Sexo (m/f): ");
					scanf("%c", &sexo);
					limparBuffer();
				}
				limparTela();
				printf("Idade (0-126): ");
				scanf("%d", &idade);
				limparBuffer();
				while (idade < 0 || idade > 126) { // la�o que for�a usu�rio a digitar idade certa
					limparTela();
					printf("Op��o inv�lida\r\n");
					printf("Idade (0-126): ");
					scanf("%d", &idade);
					limparBuffer();
				}
				mascara = 128 * (toupper(sexo) == 'F');
				mascara += idade;
				mapaDoTeatro[i][k] = (char)mascara;

				if (toupper(sexo) == 'M') {
					(*qntdDePagantesHomens)++;
				}
				else {
					(*qntdDePagantesMulheres)++;
				}
				qntdDePagantesPorFaixaDeIdade[(idade / (int)ceil(126 / qntdDeFaixasDeIdade))]++;
				if (0 <= idade && idade <= 17) {
					(*qntdDePagantesMeiaMenores)++;
				}
				else if (18 <= idade && idade <= 59) {
					(*qntdDePagantesInteira)++;
				}
				else {
					(*qntdDePagantesMeiaIdosos)++;
				}
			}
			limparTela();
			if (quantos > 1) {
				printf("Foram reservados %d lugares na fileira %d a partir do assento %d\r\n", quantos, i + 1, j + 1 - quantos + 1);
			}
			else {
				printf("Foi reservado %d lugar na fileira %d e coluna %d\r\n", quantos, i + 1, j + 1 - quantos + 1);
			}
		}
		else {
			limparTela();
			if (quantos > 1) {
				printf("N�o foram encontrados %d lugares em nenhuma fileira\r\n", quantos);
			}
			else {
				printf("N�o h� assentos livres\r\n");
			}
		}
	}
	pausa();
}

void reservarNxMAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int* qntdDePagantesHomens, int* qntdDePagantesMulheres, int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade, int* qntdDePagantesInteira, int* qntdDePagantesMeiaMenores, int* qntdDePagantesMeiaIdosos) { // Fun��o para deixar n x m assentos livres em uma ou mais fileiras
	int quantasFileiras, quantasColunas;
	char especifico;
	limparTela();
	printf("Deseja reservar quantas fileiras (1-%d)? ", qntdDeFileiras);
	scanf("%d", &quantasFileiras);
	limparBuffer();
	while (quantasFileiras < 0 || quantasFileiras > qntdDeFileiras) {
		limparTela();
		printf("Valor inv�lido\r\n");
		printf("Deseja reservar quantas fileiras (1-%d)? ", qntdDeFileiras);
		scanf("%d", &quantasFileiras);
		limparBuffer();
	}
	if (quantasFileiras == 0) {
		return;
	}
	limparTela();
	printf("Deseja reservar quantas colunas (1-%d)? ", qntdDeColunas);
	scanf("%d", &quantasColunas);
	limparBuffer();
	while (quantasColunas < 0 || quantasColunas > qntdDeColunas) {
		limparTela();
		printf("Valor inv�lido\r\n");
		printf("Deseja reservar quantas colunas (1-%d)? ", qntdDeColunas);
		scanf("%d", &quantasColunas);
		limparBuffer();
	}
	if (quantasColunas == 0) {
		return;
	}
	limparTela();
	printf("Deseja reservar a partir de um assento espec�fico (s/n)? ");
	scanf("%c", &especifico);
	limparBuffer();
	while (toupper(especifico) != 'S' && toupper(especifico) != 'N') { // la�o que for�a usu�rio a digitar s ou n
		limparTela();
		printf("Op��o inv�lida\r\n");
		printf("Deseja reservar a partir de um assento espec�fico (s/n)? ");
		scanf("%c", &especifico);
		limparBuffer();
	}
	if (toupper(especifico) == 'S') {
		int fileira, coluna;
		limparTela();
		printf("Fileira (1-%d): ", qntdDeFileiras - quantasFileiras + 1);
		scanf("%d", &fileira);
		limparBuffer();
		while (fileira < 0 || fileira > qntdDeFileiras - quantasFileiras + 1) {
			limparTela();
			printf("Valor inv�lido\r\n");
			printf("Fileira (1-%d): ", qntdDeFileiras - quantasFileiras + 1);
			scanf("%d", &fileira);
			limparBuffer();
		}
		if (fileira == 0) {
			return;
		}
		fileira--;
		limparTela();
		printf("Coluna (1-%d): ", qntdDeColunas - quantasColunas + 1);
		scanf("%d", &coluna);
		limparBuffer();
		while (coluna < 0 || coluna > qntdDeColunas - quantasColunas + 1) {
			limparTela();
			printf("Valor inv�lido\r\n");
			printf("Coluna (1-%d): ", qntdDeColunas - quantasColunas + 1);
			scanf("%d", &coluna);
			limparBuffer();
		}
		if (coluna == 0) {
			return;
		}
		coluna--;
		int i, j, cont = 0;
		for (i = fileira; i<fileira + quantasFileiras; i++) {
			for (j = coluna; j<coluna + quantasColunas; j++) {
				if (mapaDoTeatro[i][j] == (char)255) {
					cont++;
				}
				else {
					break;
				}
			}
		}
		limparTela();
		if (cont == (quantasFileiras * quantasColunas)) {
			for (i = fileira; i<fileira + quantasFileiras; i++) {
				for (j = coluna; j<coluna + quantasColunas; j++) {
					char sexo;
					int idade;
					int mascara;
					limparTela();
					printf("Sexo (m/f): ");
					scanf("%c", &sexo);
					limparBuffer();
					while (toupper(sexo) != 'M' && toupper(sexo) != 'F') { // la�o que for�a usu�rio a digitar m ou f
						limparTela();
						printf("Op��o inv�lida\r\n");
						printf("Sexo (m/f): ");
						scanf("%c", &sexo);
						limparBuffer();
					}
					limparTela();
					printf("Idade (0-126): ");
					scanf("%d", &idade);
					limparBuffer();
					while (idade < 0 || idade > 126) { // la�o que for�a usu�rio a digitar idade certa
						limparTela();
						printf("Op��o inv�lida\r\n");
						printf("Idade (0-126): ");
						scanf("%d", &idade);
						limparBuffer();
					}
					mascara = 128 * (toupper(sexo) == 'F');
					mascara += idade;
					mapaDoTeatro[i][j] = (char)mascara;

					if (toupper(sexo) == 'M') {
						(*qntdDePagantesHomens)++;
					}
					else {
						(*qntdDePagantesMulheres)++;
					}
					qntdDePagantesPorFaixaDeIdade[(idade / (int)ceil(126 / qntdDeFaixasDeIdade))]++;
					if (0 <= idade && idade <= 17) {
						(*qntdDePagantesMeiaMenores)++;
					}
					else if (18 <= idade && idade <= 59) {
						(*qntdDePagantesInteira)++;
					}
					else {
						(*qntdDePagantesMeiaIdosos)++;
					}
				}
			}
			if ((quantasFileiras * quantasColunas) > 1) {
				printf("Foram reservados %d lugares nas fileiras %d a %d do assento %d ao %d\r\n", (quantasFileiras * quantasColunas), fileira + 1, fileira + quantasFileiras, coluna + 1, coluna + quantasColunas);
			}
			else {
				printf("Foi reservado %d lugar na fileira %d e coluna %d\r\n", (quantasFileiras * quantasColunas), fileira + 1, coluna + 1);
			}
		}
		else {
			if ((quantasFileiras * quantasColunas) > 1) {
				printf("N�o foi poss�vel reservar %d lugares nas fileiras %d a %d e colunas %d a %d porque pelo menos um j� est� reservado\r\n", (quantasFileiras * quantasColunas), fileira + 1, fileira + quantasFileiras, coluna + 1, coluna + quantasColunas);
			}
			else {
				printf("N�o foi poss�vel reservar o assento na fileira %d e coluna %d porque ele j� est� reservado\r\n", fileira + 1, coluna + 1);
			}
		}
	}
	else {
		int i, j;
		int encontrado = 0;
		for (i = 0; i <= qntdDeFileiras - quantasFileiras; i++) {
			for (j = 0; j <= qntdDeColunas - quantasColunas; j++) {
				if (encontradosNxMLugaresAPartirDeUmAssento(mapaDoTeatro, i, j, quantasFileiras, quantasColunas)) {
					encontrado = 1;
					break;
				}
			}
			if (encontrado == 1) {
				break;
			}
		}
		limparTela();
		if (encontrado == 1) {
			int k, l;
			for (k = i; k<i + quantasFileiras; k++) {
				for (l = j; l<j + quantasColunas; l++) {
					char sexo;
					int idade;
					int mascara;
					limparTela();
					printf("Sexo (m/f): ");
					scanf("%c", &sexo);
					limparBuffer();
					while (toupper(sexo) != 'M' && toupper(sexo) != 'F') { // la�o que for�a usu�rio a digitar m ou f
						limparTela();
						printf("Op��o inv�lida\r\n");
						printf("Sexo (m/f): ");
						scanf("%c", &sexo);
						limparBuffer();
					}
					limparTela();
					printf("Idade (0-126): ");
					scanf("%d", &idade);
					limparBuffer();
					while (idade < 0 || idade > 126) { // la�o que for�a usu�rio a digitar idade certa
						limparTela();
						printf("Op��o inv�lida\r\n");
						printf("Idade (0-126): ");
						scanf("%d", &idade);
						limparBuffer();
					}
					mascara = 128 * (toupper(sexo) == 'F');
					mascara += idade;
					mapaDoTeatro[k][l] = (char)mascara;

					if (toupper(sexo) == 'M') {
						(*qntdDePagantesHomens)++;
					}
					else {
						(*qntdDePagantesMulheres)++;
					}
					qntdDePagantesPorFaixaDeIdade[(idade / (int)ceil(126 / qntdDeFaixasDeIdade))]++;
					if (0 <= idade && idade <= 17) {
						(*qntdDePagantesMeiaMenores)++;
					}
					else if (18 <= idade && idade <= 59) {
						(*qntdDePagantesInteira)++;
					}
					else {
						(*qntdDePagantesMeiaIdosos)++;
					}
				}
			}
			if ((quantasFileiras * quantasColunas) > 1) {
				printf("Foram reservados %d lugares nas fileiras %d a %d do assento %d ao %d\r\n", (quantasFileiras * quantasColunas), i + 1, i + quantasFileiras, j + 1, j + quantasColunas);
			}
			else {
				printf("O assento na fileira %d e coluna %d foi reservado\r\n", i + 1, j + 1);
			}
		}
		else {
			if ((quantasFileiras * quantasColunas) > 1) {
				printf("N�o foram encontrados %d lugares livres\r\n", (quantasFileiras * quantasColunas));
			}
			else {
				printf("N�o h� lugares livres\r\n");
			}
		}
	}
	pausa();
}
