#pragma once

#include "auxiliares.h"
#include <vector>

using namespace std;

void reservarNAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int* qntdDePagantesHomens, int* qntdDePagantesMulheres, int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade, int* qntdDePagantesInteira, int* qntdDePagantesMeiaMenores, int* qntdDePagantesMeiaIdosos);

void reservarNxMAssentos(int qntdDeFileiras, int qntdDeColunas, vector<vector<char>> mapaDoTeatro, int* qntdDePagantesHomens, int* qntdDePagantesMulheres, int qntdDeFaixasDeIdade, vector<int> qntdDePagantesPorFaixaDeIdade, int* qntdDePagantesInteira, int* qntdDePagantesMeiaMenores, int* qntdDePagantesMeiaIdosos);
